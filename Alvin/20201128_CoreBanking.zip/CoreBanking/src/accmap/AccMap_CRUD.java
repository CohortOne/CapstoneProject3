package accmap;

import java.util.Scanner;

public class AccMap_CRUD {

    public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }

    public static int DisplayOptions(String displayMenu) throws Exception {
        System.out.print(displayMenu);

        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }

    public static void printHeader() throws Exception {
        System.out.println(" =================================================="
                + "============================================================"
                + "================");

    }

    public static void printFooter() {
        System.out.println(" =================================================="
                + "============================================================"
                + "================");
    }

    public static int findMapByNric() throws Exception {
        printHeader();
        System.out.print(" \tEnter the Nric to Find :: ");
        String nric_String = myObj.next();
        int nric = Integer.parseInt(nric_String);

        printHeader();
        System.out.println("ID \tNric \tAcc_ID \tStatus");
        printFooter();
        AccMapDAO.accMapRow(nric).stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int ListMap() throws Exception {
        //printHeader();
        System.out.println("id \tNRIC \tAcc_ID \tStatus");
        //printFooter();
        AccMapDAO.ListMap().stream().forEach(System.out::println);
        //printFooter();
        return 1;
    }

    public static int insMap() throws Exception {
        System.out.print(" \n\t NRIC (only digits) \t : ");
        String nric_String = myObj.next();
        int nric = Integer.parseInt(nric_String);
        // Check if nric is in Customer database first
        if (custinfo.CustDAO.noCustNric(nric)) {
            System.out.println("no NRIC in DB!");
            return 0;
        }

        System.out.print(" \n\t Account ID \t : ");
        String accid_String = myObj.next();
        int accid = Integer.parseInt(accid_String);
        // no repeat of accNo
        if (AccMapDAO.noMapAccNo(accid)) {
            System.out.println("no acc_id in DB!");
            AccMapDAO.insertMap(new AccMap(nric, accid, (byte) 1));
            return 1;
        }


        return 0;
    }

    public static void CustAccMap() throws Exception {
        String MapMenu = ("\n *************************************************"
                + "******************************************** "
                + "\n\t Customer Account Mapping CRUD menu ::: "
                + "\n\t----------------------------------"
                + "\n *********************************************************"
                + "************************************ "
                + "\n\tFollowing are the options :: "
                + "\n\t\t1 >> Insert Customer Account link "
                + "\n\t\t4 >> List all rows "
                + "\n\t\t6 >> Find Map by Nric"
                + "\n\t\t7 >> Display Nric and AccountNo "
                + "\n\t\t0 >> Exit "
                + "\n *********************************************************"
                + "************************************ "
                // Create a Scanner object
                + "\nEnter a numer to carry out the operation  :   ");

        while (true) {
            int optionVal = DisplayOptions(MapMenu);

            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {

                case 1:
                    System.out.println("Insert Customer Account link  ");
                    //printFooter();
                    insMap();
                    break;

                case 4:
                    System.out.println("List all rows ");
                    //printFooter();
                    ListMap();
                    break;
                case 6:
                    System.out.println("Find map by nric ");
                    //printFooter();
                    findMapByNric();
                    break;
                case 7:
                    System.out.println("Display Nric with AccountNo");
                    //printFooter();
                    //findMapByNric();
                    break;
                case 0:
                    System.out.println("Exit");
                    printFooter();
                    Thread.sleep(4000);
                    System.exit(0);
                    break;
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    //printFooter();
                    Thread.sleep(4000);
                    break;
            }

            System.out.print(" Press any key to continue.....");
            toContinue();
        }
    }

    public static void main(String[] args) throws Exception {

        CustAccMap();
    }

}
