///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package accmap;
//
//import corebanking.sqlConnect;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;
//import savingacc.*;
//
///**
// *
// * @author antw
// */
//public class test {
//
//    public static void myArrayL() {
//        int data1 = 0;
//        List<AccMap> myAL = new ArrayList<>();
//    }
//
//    public static void main(String[] args) throws Exception {
//        int nric = 1234567;
//        List<AccMap> s = AccMapDAO.accMapRow(nric);
//        s.stream().forEach(System.out::println);
//        for (AccMap a : s) {
//            int Accid = a.getAccid();
//            System.out.println(
//                    "\tid:\t" + a.getId()
//                    + "\n\tNric:\t" + a.getNric()
//                    + "\n\tAccID\t" + Accid
//                    + "\n\tAccNo\t" + SavingAccDao.getAccnoByID(Accid)
//            );
//        }
//////                SavingAcc s = SavingAccDao.accInfo(1);
////        System.out.println(s);
////        System.out.println("Account No: " + s.getAccNo());
//        int Accid = 2;
////        String SAccid = SavingAccDao.accInfo(Accid).getAccNo();
////        System.out.println("Account No " + SAccid);
//        //System.out.println(SavingAccDao.accInfo(Accid).getAccNo());
//        String Test2 = SavingAccDao.getAccnoByID(Accid) ;
//        System.out.println(Test2);
//
//    }
//
//    public static String getAccnoByID(int idSA) throws Exception {
//        Statement stmt = sqlConnect.init();
//        String accSNo = null;
//        String qStmt = "Select accNo from coreBanking.SA where idSA = " + idSA + ";";
//        ResultSet rs = stmt.executeQuery(qStmt);
//        while (rs.next()) {
//            accSNo = (new String(rs.getString("accNo")));
//        }
//        return accSNo;
//    }
//}