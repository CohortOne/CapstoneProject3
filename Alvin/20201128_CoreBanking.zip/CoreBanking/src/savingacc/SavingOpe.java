package savingacc;

import corebanking.CoreBanking;
import java.util.Scanner;
import txhistory.FxTHist;
import txhistory.HistDAO;
import txhistory.TxHist;
import util.LogUtil;

public class SavingOpe {

    public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }

    public static String accNo;

    public static int DisplayOptions(String accNo) throws Exception {
        //LogUtil.doInfoLog(" Info Message From SavingOpe.DisplayOptions )");
        System.out.println("\n ************************************************"
                + "********************************************* ");
        System.out.println("\n\tOperations for accNo: " + accNo);
        System.out.println(" \t----------------------------------");
        System.out.println("\n ************************************************"
                + "********************************************* ");

        System.out.println("\tFollowing are the options :: ");
        //System.out.println(" \n\t\t1 >> Create New Account ");
        System.out.println("\n\t2 >> Check Balance");
        System.out.println("\n\t3 >> Deposit");
        System.out.println("\n\t4 >> Withdrawal");
        System.out.println("\n\t5 >> Transaction History (FX mode)");
        //System.out.println(" \n\t\t3 >> Find Accounts by Cust Name ");
        //System.out.println(" \n\t\t9 >> List ALL data (by Account no.)");
        System.out.println("\n\t9 >> Return to main ");
        System.out.println("\n\t0 >> Exit ");
        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" Enter a numer to carry out the operation  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }

    public static void printHeader() throws Exception {
        //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" ============================================================================================== ");

    }

    public static void printFooter() {
        System.out.println(" ============================================================================================== ");
    }

    public static void Main(SavingAcc currArray) throws Exception {

        //DisplayOptions(accNo);
        String accNo = currArray.getAccNo();

        while (true) {
            int optionVal = DisplayOptions(accNo);

            System.out.print("\t Option Selected : \t\t");
            switch (optionVal) {

                case 1:
                    System.out.println("Create New Account  ");
                    //printFooter();
                    Saving_CRUD.inSAacc();
                    break;

                case 2:
                    System.out.println("Check Balance  ");
                    //SavingAccDao.getList(accNo).stream().forEach(System.out::println);
                    balanceByAccNo(currArray);
                    break;
                case 3:
                    System.out.println("Deposit  ");
                    depositAmt(currArray);
                    break;
                case 4:
                    System.out.println("Withdrawal  ");
                    withdrawalAmt(currArray);
                    break;
                case 5:
                    System.out.println("Transaction History  ");
                    printHist(currArray);
                    break;
                case 6:
                    System.out.println("List all Acc No  ");
                    Saving_CRUD.listAllAcc();
                    break;
                case 9:
                    System.out.println("Return");
                    printFooter();
                    CoreBanking.BankOpe();
                case 0:
                    System.out.println("Exit");
                    printFooter();
                    //Thread.sleep(4000);
                    System.exit(0);
                    break;
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    //printFooter();
                    Thread.sleep(4000);
                    break;
            }

            System.out.print("\nPress any key to continue.....");
            toContinue();
        }
    }

    public static int balanceByAccNo(SavingAcc s) throws Exception {
        LogUtil.doInfoLog(" Info Message From >> SavingOpe.balanceByAccNo()");
        printHeader();
        System.out.println("\n\tAccount :\t" + s.getAccNo()
                + "\n\tBalance :\t" + s.getBalance());
        return 0;
        //Select balance from coreBanking.SA INNER JOIN coreBanking.accmap
        //on coreBanking.accmap.accid = coreBanking.SA.idSA;
    }

    private static int depositAmt(SavingAcc s) throws Exception {
        LogUtil.doInfoLog(" Info Message From >> SavingOpe.depositAmt()");
        printHeader();
        //System.out.println("\n\t:: Transaction - Deposit :: ");
        double currBal = s.getBalance();
        System.out.println("\n\tCurrent balance\t: " + currBal);
        System.out.print("\n\tAmount to be deposit: ");
        int getAmt = myObj.nextInt();

        System.out.print("\n\tConfirm [y/n][Y/N]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {

            System.out.println("\n\tInitiating amount to deposit ::");
            printHeader();

            s.setBalance(currBal + getAmt);
            SavingAccDao.updateAcc(s);
            int txcode = 11; // Saving Deposit for history
            txhistory.HistDAO.insTxNow(s.getIdSA(), txcode, getAmt); // for history

            System.out.println("\n\tNew balance \t : " + s.getBalance());

            printFooter();
        }

        return 0;
    }

    private static int withdrawalAmt(SavingAcc s) throws Exception {
        LogUtil.doInfoLog(" Info Message From >> SavingOpe.withdrawalAmt()");
        printHeader();
        //System.out.println("\n\t:: Transaction - Deposit :: ");
        double currBal = s.getBalance();
        System.out.println("\n\tCurrent balance\t: " + currBal);
        System.out.print("\n\tAmount to be withdraw: ");
        int getAmt = myObj.nextInt();

        System.out.print("\n\tConfirm [y/n][Y/N]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {

            System.out.println("\n\tInitiating amount to withdraw ::");
            printHeader();

            getAmt = 0 - getAmt; // negative conversion
            s.setBalance(currBal + getAmt);
            SavingAccDao.updateAcc(s);
            int txcode = 15; // "Saving Withdrwal"
            txhistory.HistDAO.insTxNow(s.getIdSA(), txcode, getAmt); // for history
            System.out.println("\n\tNew balance \t : " + s.getBalance());

            printFooter();
        }

        return 0;
    }

    private static int printHist(SavingAcc s) throws Exception {
        printHeader();
        /*just print out the row */
        System.out.println("\n\tTransaction History for \t: " + s.getAccNo());
        int Accid = s.getIdSA();
        System.out.println("\n\tDATE \t\t\tCODE \tDESCRIPTION \tAMOUNT");
        txhistory.HistDAO.getHistByAccid(Accid).stream().forEach(ea
                -> System.out.println(ea.toStringV3()));
        printFooter();

        TxHist.glovalVarInt = Accid; // Global variable for FX
        FxTHist.launchFtHist(Accid); // FX SceneBuild
        return 1;
    }

    public static void main(String[] args) throws Exception {


        int acc_id = 1;

        SavingAcc currArray = SavingAccDao.accRow(acc_id);
        Main(currArray);

        //System.exit(0); // do not put this!
    }
}
