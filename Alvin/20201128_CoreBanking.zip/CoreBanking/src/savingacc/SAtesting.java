/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package savingacc;

import java.time.LocalDate;
import static java.time.LocalDate.now;
//import static savingacc.SavingOpe.accNo;

public class SAtesting {

    public static int listByAccNo() throws Exception {
        //printHeader();
        System.out.print(" \tEnter the AccountNo (xxx-xxx-xxx-x):");
        String accNo = "098-765-432-1";	//String accNo = myObj.next();

        //printHeader();
        System.out.println(
                "\nID  \tAccNo \t\tbalance \tintRate \taccOpenDate "
                + "\taccClosedDate \tminBal");
        SavingAccDao.getList(accNo).stream().forEach(System.out::println);
        return 0;

    }

    public static void main(String[] args) throws Exception {
//        //accNo = "112-666-777-8";
//        String accNo = "123-456-789-0";
//        //SavingAccDao.getInfo(accNo).stream().forEach(System.out::println);
//        listByAccNo();
//        System.out.println("Balance: " + SavingAccDao.getList(accNo));

        //SavingAccDao.listSA().stream().forEach(System.out::println);       
//        double intRate = 0.0752342424;
//        String s = String.format("%.3f", intRate);
//        System.out.println("s = " + s);
        // Need to change idSA & AccNo
        int accid = SavingAccDao.getNextID(); // get next ID
        String AccNo = "112-666-777-9";
        double balance = 3000;
        double intRate = 0.075;
        LocalDate accOpenDate = now();
        //LocalDate accOpenDate = LocalDate.parse("2000-10-02");
        LocalDate accClosedDate = null; // not necessayr
        double minBal = 200;

        int nxtID = SavingAccDao.getNextID();

        System.out.println("==== S A Testing : Insert ====== ");

        SavingAccDao.insertSAacc(new SavingAcc(nxtID, AccNo, balance,
                intRate, accOpenDate, accClosedDate, minBal));

        SavingAcc row = SavingAccDao.accRow(accid);

        System.out.println("==== S A Testing : Deposit ====== ");
        double amt = 200;
        row.setBalance(row.getBalance() + amt);
        SavingAccDao.updateAcc(row);
        int txcode = 11; // Saving Deposit for history
        txhistory.HistDAO.insTxNow(row.getIdSA(), txcode, amt); // for history

        System.out.println("==== S A Testing : Delete ====== ");
        SavingAccDao.delAcc(row);

        System.out.println("==== S A Testing : History ====== ");
        Saving_CRUD.printRowHist(row);

    }
}
/*
        System.out.println(loadEmp().stream().collect(Collectors.counting()));

        System.out.println(loadEmp()
                .stream()
                .map(e -> e.getlName())
                .collect(Collectors.toList()));
 */

 /*
                Stream.of("Monday", "Tuesday", "Wednesday", "Thursday")
                .filter(s -> s.startsWith("T"))
                .forEach(s -> System.out.println("Matching Days: " + s));
 */
