/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package txhistory;

import corebanking.sqlConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * 1. need to add FX-11 into project properties 2. VBM Option > --module-path
 * /Users/antw/javafx/javafx-sdk-11.0.2/lib --add-modules
 * javafx.controls,javafx.fxml,javafx.media
 *
 * @author antw
 */
public class FxTHist extends Application {

    public static void main(String[] args) throws Exception {
//        printH();
        launch();
        //System.exit(0); // never put this
    }

    public static void launchFtHist(int accid) {
        System.out.println("launchFtHist(int accid) " + accid);
                launch();
    }
    // default
    @Override
    public void start(Stage stage) throws Exception {

        stage.setTitle(" FX TRANSACTION REPORT ");

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FxTHist.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

//    // convert ArrayList to ObservableList
//    public static ObservableList<TxHist> otest(int Accid) throws Exception {
//        List<TxHist> rs = getHByAccid(Accid);
//        ObservableList<TxHist> ors = FXCollections.observableArrayList();
//        for (TxHist row : rs) {
//            ors.add(row);
////            System.out.println("Row" + row.toStringV3());
//        }
//        return ors;
//    }

//    // from HistDAO
//    public static List<TxHist> getHByAccid(int accid) throws Exception {
//        Connection conn = sqlConnect.initConn();
//        List<TxHist> histList = new ArrayList<>();
//        String qStmt = "Select * from coreBanking.history INNER JOIN coreBanking.txcode "
//                + "on coreBanking.history.txcode = coreBanking.txcode.code where accid = ? ";
//
//        PreparedStatement pStmt = conn.prepareStatement(qStmt);
//        pStmt.setInt(1, accid);
//
//        ResultSet rs = pStmt.executeQuery();
//        while (rs.next()) {
//            histList.add(new TxHist(
//                    //rs.getInt("accid"),
//                    rs.getObject("txdate", LocalDateTime.class),
//                    rs.getInt("txcode"),
//                    rs.getDouble("txamt"),
//                    rs.getString("desc")
//            ));
//        }
//        return histList;
//    }
//
//    // from SavingOpe
//    private static int printH() throws Exception {
//        /*just print out the rows */
//        int Accid = 9;
//        System.out.println("\n\tTransaction History for \t: " + 9);
//
//        System.out.println("\n\tDATE \t\t\tCODE \tDESCRIPTION \tAMOUNT");
//        getHByAccid(Accid).stream().forEach(ea
//                -> System.out.println(ea.toStringV3()));
//
//        return 1;
//    }

}
/*
was
-Djava.util.logging.config.file=/Users/antw/ntuc/cohortProj/CoreBanking/log_v3.properties --module-path /Users/antw/javafx/javafx-sdk-11.0.2/lib --add-modules javafx.controls,javafx.fxml,javafx.media

 */
