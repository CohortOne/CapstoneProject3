
package mainprog;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;


public class LocaleEx {
    
    public static Scanner myObj = new Scanner(System.in);   
    
    
    public static String selectLanguage(){
        ResourceBundle langSelection = inputLang(MainPage.currentLanguage);
        System.out.println(" \n\t\t" + langSelection.getObject("langchangemain") + " : ");
        System.out.println(" \n\t\t1. "+ langSelection.getObject("english") + " \n\t\t2. " + langSelection.getObject("chinese"));
        System.out.print(" \n\t\t"+ langSelection.getObject("preferredLang") +" : ");
        int userChoice = myObj.nextInt();        
        switch (userChoice){
            case 1:
                System.out.println("\t\t English is Selected ");                
                MainPage.currentLanguage = "en_US";
                break;
            case 2:
                System.out.println("\t\t 选择中文 ");                
                MainPage.currentLanguage = "zh_CN";
                break;
            default:
                break;
        }
        return MainPage.currentLanguage;
    }
    
    public static ResourceBundle inputLang(String selectedLang){
                
        Locale locale = new Locale(selectedLang);
        
        ResourceBundle msgs = ResourceBundle.getBundle("bundles.Msg_Bundle", locale);
        
        return msgs;
    }   
}
