/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainprog;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Scanner;
import java.util.regex.Pattern;
import static mainprog.MainPage.myObj;

/**
 *
 * @author KCHUA
 */
public class testinglocaldatetime {
    
    public static int test = 1;

    public static void main(String[] args) {
        LocalDateTime lt = LocalDateTime.now();
        String localt = lt.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM));
//        System.out.println(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
//                .format(lt));
    DateTimeFormatter formatter 
            = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        System.out.println(LocalDateTime.parse("2020-11-20T11:14:20.11"));
        System.out.println(lt);
        
//        acctType types[] = acctType.values();
//        for(acctType type: types){
//            System.out.println(type.selection+ ". " + type);
//        }
//        Scanner myObj = new Scanner(System.in);
//        System.out.print(" Key in the selection  :   ");
//        int accTypeNo = myObj.nextInt();
//        String accType = acctType.getSelection(accTypeNo).toString();
//        System.out.println(accType);
        
        acctType i = acctType.valueOf("Debit_Account");
        System.out.println(i.getType());
        Environment sitUrl = Environment.valueOf("SIT"); 
        System.out.println(sitUrl.getUrl());
        
        System.out.println(test);
        change();
        System.out.println(test);
        System.out.println(change());

    }
    
    public static int change(){
        test = 5;
        return test;
    }
    
    public enum acctType {
        Debit_Account(1), Fixed_Deposit(2), Credit_Card(3);
        private int selection;
        
        
        
        public int getType(){
            return selection;
        }
        acctType(int selection) {
            this.selection = selection;
        }
        
        public static acctType getSelection(int selection){
            for (acctType type: acctType.values()){
                if (type.selection == selection){
                    return type;
                }
            }
            return null;
        }
    }
    
    public static String verifyUIN(String UIN){
        boolean wrongVeri = true;              
        while (wrongVeri){
            if (!Pattern.matches("(?i)^[STFG]\\d{7}[A-Z]$", UIN)){
            System.out.println("Invalid NRIC format.");            
            } 
            System.out.println(" \n\t\t        Please reenter NRIC");
            String reUIN = myObj.next();
            if(Pattern.matches("(?i)^[STFG]\\d{7}[A-Z]$", reUIN)){
                wrongVeri = false;
                UIN = reUIN;
            }
        }
        System.out.println(UIN);
        return UIN;
    }
    
    public enum Environment 
{
    PROD("https://prod.domain.com:1088/"), 
    SIT("https://sit.domain.com:2019/"), 
    CIT("https://cit.domain.com:8080/"), 
    DEV("https://dev.domain.com:21323/");
 
    private String url;
 
    Environment(String envUrl) {
        this.url = envUrl;
    }
 
    public String getUrl() {
        return url;
    }
}

}
