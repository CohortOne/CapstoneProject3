
package mainprog;


import customeracc.Account_CRUD;
import static customeracc.Account_CRUD.*;
import customerdetails.Customer_CRUD;
import static customerdetails.Customer_CRUD.*;
import debitsavingsacc.DebitAcc_CRUD;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.regex.Pattern;


public class MainPage {
    
    public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;
    public static boolean wrongVeri = true;
    public static String currentLanguage = "en_US";
    public static ResourceBundle mainPage;
    
    //Verification methods  
    public static String verifyName(String name){
        mainPage = LocaleEx.inputLang(currentLanguage);
        wrongVeri = true;
        while (wrongVeri){
            if (!Pattern.matches("^(?![ .]+$)[a-zA-Z .]*$", name)){
                System.out.println(" \n\t\t        " + mainPage.getObject("invalidFormat"));
                System.out.print(" \n\t\t        " + mainPage.getObject("reEnter") + "  :  ");
                String reName = myObj.next();
                if (Pattern.matches("^(?![ .]+$)[a-zA-Z .]*$", reName)){
                    wrongVeri = false;
                    name = reName;
                }  
            }else {
                wrongVeri = false;
            }
                  
        }
        return name;
    }
            
    public static String verifyUIN(String UIN){
        mainPage = LocaleEx.inputLang(currentLanguage);
        wrongVeri = true;
        while (wrongVeri){
            if (!Pattern.matches("(?i)^[STFG]\\d{7}[A-Z]$", UIN)){
                System.out.println(" \n\t\t        " + mainPage.getObject("invalidFormat"));
                System.out.print(" \n\t\t        " + mainPage.getObject("reEnter") + "  :  ");
                String reUIN = myObj.next();
                if(Pattern.matches("(?i)^[STFG]\\d{7}[A-Z]$", reUIN)){
                    wrongVeri = false;
                    UIN = reUIN;
                }
            }else {
                wrongVeri = false;
            } 
            
        }        
        return UIN;
    }
    
    public static String verifyEmail(String email){
        mainPage = LocaleEx.inputLang(currentLanguage);
        wrongVeri = true;
        while (wrongVeri){
            if (!Pattern.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", email)){
                System.out.println(" \n\t\t        " + mainPage.getObject("invalidFormat"));
                System.out.print(" \n\t\t        " + mainPage.getObject("reEnter") + "  :  ");
                String reEmail = myObj.next();
                if (Pattern.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", reEmail)){
                    wrongVeri = false;
                    email = reEmail;
                }
            }else {
                wrongVeri = false;
            }
            
        }
        return email;
    }
    
    public static String verifyContactNo(String contactNo){
        mainPage = LocaleEx.inputLang(currentLanguage);
        wrongVeri = true;
        while (wrongVeri){
            if (!Pattern.matches("[689]{1}[0-9]{7}", contactNo)){
                System.out.println(" \n\t\t        " + mainPage.getObject("invalidFormat"));
                System.out.print(" \n\t\t        " + mainPage.getObject("reEnter") + "  :  ");
                String reContact = myObj.next();
                if (Pattern.matches("[689]{1}[0-9]{7}", reContact)){
                    wrongVeri = false;
                    contactNo = reContact;
                }
            }else {
                wrongVeri = false;
            }
            
        }
        return contactNo;
    }
    
    public static String verifyCVV(String cvv){
        mainPage = LocaleEx.inputLang(currentLanguage);
        wrongVeri = true;
        while (wrongVeri){
            if (!Pattern.matches("[0-9]{3}", cvv)){
                System.out.println(" \n\t\t        " + mainPage.getObject("invalidFormat"));
                System.out.print(" \n\t\t        " + mainPage.getObject("reEnter") + "  :  ");
                String reCVV = myObj.next();
                if (Pattern.matches("[0-9]{3}", reCVV)){
                    wrongVeri = false;
                    cvv = reCVV;
                }
            }else {
                wrongVeri = false;
            }
            
        }
        return cvv;
    }
    
    public static String verifyCardPin(String pin){
        mainPage = LocaleEx.inputLang(currentLanguage);
        wrongVeri = true;
        while (wrongVeri){
            if (!Pattern.matches("[0-9]{6}", pin)){
                System.out.println(" \n\t\t        " + mainPage.getObject("invalidFormat"));
                System.out.print(" \n\t\t        " + mainPage.getObject("reEnter") + "  :  ");
                String rePin = myObj.next();
                if (Pattern.matches("[0-9]{6}", rePin)){
                    wrongVeri = false;
                    pin = rePin;
                }
            }else {
                wrongVeri = false;
            }
            
        }
        return pin;
    }
        
    //Program Beautifier
    public static String padRight(String inputString, int length) {
        if (inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(inputString);
        while (sb.length() < length) {
            sb.append(' ');
        }
        
        return sb.toString();
    }
    
    public static void toContinue() {
        myObj.next();
    }

    public static String printPretty() {
        String s = "\n  |";
        for (int i = 0; i <= iteration; i++) {
            s += "---";
        }

        return s + " >> ";
    }

    public static void printHeader() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" ================================================================================================================================================================================");

    }

    public static void printFooter() {
        System.out.println(" ================================================================================================================================================================================");
    }
    
    
    //DisplayOptions methods
    public static int DisplayOptions() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        mainPage = LocaleEx.inputLang(currentLanguage);
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t "+ mainPage.getObject("mainTitle")+ " ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \t"+ mainPage.getObject("optionsAvailable")+ " :: ");
        System.out.println(" \n\t\t1 >>  "+ mainPage.getObject("custCRUD"));
        System.out.println(" \n\t\t2 >>  "+ mainPage.getObject("accCRUD"));
        System.out.println(" \n\t\t3 >>  "+ mainPage.getObject("changeLang"));
//        System.out.println(" \n\t\t4 >> List Customers "); 
//        System.out.println(" \n\t\t5 >> Sort Customers List ");
//        System.out.println(" \n\t\t6 >> Find Customer By ");
        System.out.println(" \n\t\t0 >>  "+ mainPage.getObject("exit"));

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(mainPage.getObject("selection") + ":   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
    
    public static void mainMenu() throws Exception{
        LoggingUtil.loadLogConfig();
        int mainPageOptionVal = DisplayOptions();
        mainPage = LocaleEx.inputLang(currentLanguage);
        printHeader();
        System.out.print("\t\t "+ mainPage.getObject("optionselected") + " : \t\t");
        switch (mainPageOptionVal) {

            case 1:
                Customer_CRUD.customerOperations();
                break;
            case 2:
                Account_CRUD.acctOperations();
                break;
            case 3:
                LocaleEx.selectLanguage();
                break;                 
            case 0:
                System.out.println("Exit");
                printFooter();
                Thread.sleep(2000);
                System.exit(0);
                break;
            default:
                //printHeader();
                System.out.println(" \n\n \t\t #### "+ mainPage.getObject("invalid") +" ####");
                printFooter();
                Thread.sleep(2000);
                break;
        }
    }
    //Main method
    public static void main(String[] args) throws Exception {        
        while (true) {
            mainMenu();
            mainPage = LocaleEx.inputLang(currentLanguage);
            printFooter();            
            System.out.print(mainPage.getObject("continue"));
            toContinue();
        }

    }
}
