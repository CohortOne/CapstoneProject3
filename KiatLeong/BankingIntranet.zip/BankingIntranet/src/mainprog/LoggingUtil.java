
package mainprog;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;

public class LoggingUtil {    

    private static final Logger LOGGER = Logger.getLogger(LoggingUtil.class.getName());
    
    

    
    public static void doInfoLog(String s){        
        LOGGER.info(s);
    }
    
    public static void doErrorLog(String s){
        
    }
    
    public static void doWarnLog(String s){
        LOGGER.warning(s);    
    }
    
    public static void doSevereLog(String s){
    
    }
    
    public static void doExceptionLog(String s){
    
    }
    
    public static void loadLogConfig() {
        try {
            LOGGER.setUseParentHandlers(false);
            //FileHandler file name with max size and number of log files limit
            Handler fileHandler = new FileHandler("D:\\NetBeans\\NetBeansProjects\\BankingIntranet\\logfiles\\logger%u.%g.log", 20000, 5);
            fileHandler.setFormatter(new SimpleFormatter());
            //setting custom filter for FileHandler
            LOGGER.addHandler(fileHandler);            
            
        } catch (SecurityException | IOException e) {
            e.printStackTrace();
        }
    }
}
