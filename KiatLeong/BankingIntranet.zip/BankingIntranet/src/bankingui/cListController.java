/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingui;

import customerdetails.Customer;
import customerdetails.CustomerDAO;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author chand
 */
public class cListController implements Initializable {

    @FXML
    private TableView<Customer> cListTbl;
    @FXML
    private TableColumn<Customer, String> custUin;
    @FXML
    private TableColumn<Customer, String> custName;
    @FXML
    private TableColumn<Customer, String> custAddr;
    @FXML
    private TableColumn<Customer, String> contactNo;
    @FXML
    private TableColumn<Customer, String> email;
    @FXML
    private TableColumn<Customer, String> citizenship;
    @FXML
    private TableColumn<Customer, Boolean> Active;
    @FXML
    private TableColumn<Customer, LocalDateTime> lastUpdated;
    @FXML
    private TableColumn<Customer, LocalDateTime> creationDT;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    public  void init() {
         try {
            ObservableList <Customer> custList = CustomerDAO.listCustomerInApp();
            cListTbl.setStyle("-fx-alignment: CENTER-LEFT;");
//            customerUin.setCellValueFactory(new PropertyValueFactory<Customer, String>("customerUin"));
            custUin.setCellValueFactory(new PropertyValueFactory<Customer, String>("custUin"));
            custName.setCellValueFactory(new PropertyValueFactory<Customer, String>("CustomerName"));
            custAddr.setCellValueFactory(new PropertyValueFactory<Customer, String>("CustomerAddr"));
            contactNo.setCellValueFactory(new PropertyValueFactory<Customer, String>("CustomerContactNo"));
            email.setCellValueFactory(new PropertyValueFactory<Customer, String>("CustomerEmailAddr"));
//            citizenship.setCellValueFactory(new PropertyValueFactory<Customer, String>("CustomerResidentStatus"));
            Active.setCellValueFactory(new PropertyValueFactory<Customer, Boolean>("CustomerStatus"));            
            lastUpdated.setCellValueFactory(new PropertyValueFactory<Customer, LocalDateTime>("LastUpdateDateTime"));
            creationDT.setCellValueFactory(new PropertyValueFactory<Customer, LocalDateTime>("CreationDateTime"));
           
          cListTbl.setItems(custList);    
        }catch(Exception e){
            System.out.println(" Exception in CustomerListFXML Controller " + e.getMessage());
            e.printStackTrace();
        }
         
    }    

    
}
