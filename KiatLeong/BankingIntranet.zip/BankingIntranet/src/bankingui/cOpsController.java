/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingui;

import customerdetails.Customer;
import customerdetails.CustomerDAO;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author chand
 */
public class cOpsController implements Initializable {

    private static int status = 0;
    private Customer cust;

    @FXML
    private TextField customerUin;
    @FXML
    private TextField custName;
    @FXML
    private TextField custAddr;
    @FXML
    private TextField contactNo;
    @FXML
    private TextField email;
    @FXML
    private TextField citizenship;
//    public void custResidency(){
//        residency = new ChoiceBox();
//        residency.getItems().add("Singaporean");
//        residency.getItems().add("PR");
//        residency.getItems().add("Foreigner");
//    }

    @FXML
    private Pane dataPane;
    @FXML
    private CheckBox Active;
    @FXML
    private Button submitBtn;
    @FXML
    private Button fetchDetails;
    @FXML
    private Button cancelBtn;
    
    private LocalDateTime lastUpdated;
    private LocalDateTime creationDT;

    public void handleTab2ButtonBar() {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void onCancel(ActionEvent event) {
        reset();
    }

    private void reset() {
        disableAll();
    }

    @FXML
    private void onSubmit(ActionEvent event) throws Exception {
        if (status == 1) {
            lastUpdated = LocalDateTime.now();
            creationDT = lastUpdated;
            cust = new Customer(customerUin.getText(), custName.getText(), custAddr.getText(), 
                    Integer.parseInt(contactNo.getText()), email.getText(), citizenship.getText(),
                    ((Active.isSelected()) ? (byte) 1 : (byte) 0), lastUpdated, creationDT);
            CustomerDAO.insertCustomer(cust);
            cust = null;
            submitBtn.setDisable(true);
            showDialog(" Insert Operation", " Success ");
            reset();
            custName.setPromptText(" ");
            email.setPromptText(" ");
            contactNo.setPromptText(" ");
            custAddr.setPromptText(" ");
        } else if (status == 3) {
            cust.setCustomerAddr(custAddr.getText());
            cust.setCustomerEmailAddr(email.getText());
            cust.setCustomerStatus((Active.isSelected()) ? (byte) 1 : (byte) 0);
            cust.setCustomerContactNo(Integer.parseInt(contactNo.getText()));
            if (CustomerDAO.updateCustomer(cust)) {
                showDialog(" Status ", " Update Success ");
            }
            status = 0;
            disableAll();
            reset();
        } else if (status ==4){
             if (CustomerDAO.delCustomer(cust.getCustUin())) { 
                showDialog(" Status Msg !!!", " Delete Success ");
            }
        }
    }

    private void showDialog(String title, String msg) {
        Dialog<String> dialog = new Dialog<String>();
        dialog.setTitle(title);
        ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
        dialog.setContentText(msg);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }

    @FXML
    private void onInsert(ActionEvent event) {
        status = 1;
        disableAll();
        submitBtn.setText(" Insert Customer ");
        cancelBtn.setText(" Cancel / Reset ");        
        custName.setPromptText(" Enter Customer Name");
        email.setPromptText(" Enter Email Address");
        contactNo.setPromptText(" Phone No ... ");
        custAddr.setPromptText(" Enter Address ");
        customerUin.setPromptText(" Enter NRIC/FIN ");
        citizenship.setPromptText(" Enter your Citizenship. ");
        enableAll();
    }

    @FXML
    private void onUpdate(ActionEvent event) {
        status = 2;
        disableAll();
        enableAll();
        fetchDetails.setDisable(false);
        customerUin.setDisable(false);
        customerUin.setEditable(true);
        customerUin.setPromptText("Enter CustID here...");
    }

    @FXML
    private void onDelete(ActionEvent event) {
        status = 4;
        disableAll();
         enableAll();
        fetchDetails.setDisable(false);
        customerUin.setDisable(false);
        customerUin.setEditable(true);
        customerUin.setPromptText("Enter CustID here...");
    }

    @FXML
    private void onReset(ActionEvent event) {
        status = 0;
        disableAll();
    }

    @FXML
    private void fetchDetails(ActionEvent event) throws Exception {
        if(status == 2)
            status = 3;         
        enableAll();
        cust = CustomerDAO.getCustomer(customerUin.getText());
        if (cust == null) {
            showDialog(" Fetch Customer Details ", " Customer Not Found");
            onUpdate(event);
            return;
        }
        custName.setText(cust.getCustomerName());
        custAddr.setText(cust.getCustomerAddr());
        contactNo.setText(Integer.toString(cust.getCustomerContactNo()));
        citizenship.setText(cust.getCustomerResidentStatus());
        email.setText(cust.getCustomerEmailAddr());
        Active.setSelected(cust.getCustomerStatus()== 1 ? true : false);
    }

    private void disableAll() {
        cancelBtn.setDisable(true);
        submitBtn.setDisable(true);
        custName.setDisable(true);
        custAddr.setDisable(true);
        Active.setDisable(true);
        contactNo.setDisable(true);
        email.setDisable(true);
        customerUin.setDisable(true);
        citizenship.setDisable(true);
        cancelBtn.setDisable(true);
        submitBtn.setDisable(true);
        submitBtn.setText(" Submit ");
        cancelBtn.setText(" Cancel");
        resetAll();
    }
    
    private void resetAll(){
        customerUin.setText("");
        custName.setText("");
        custAddr.setText("");
        citizenship.setText("");
        contactNo.setText("");
        email.setText("");
        Active.setSelected(false);
    }

    private void enableAll() {

        dataPane.setDisable(false);
        if (status == 1) {
            cancelBtn.setDisable(false);
            submitBtn.setDisable(false);
            customerUin.setDisable(false);
            custName.setDisable(false);
            custAddr.setDisable(false);
            citizenship.setDisable(false);
            Active.setDisable(false);
            contactNo.setDisable(false);
            email.setDisable(false);
        } else if (status == 2) {
            submitBtn.setText(" Update Customer ");
            submitBtn.setDisable(true);
            cancelBtn.setText(" Cancel / Reset ");
            cancelBtn.setDisable(true);
            email.setDisable(true);
            contactNo.setDisable(true);
            custAddr.setDisable(true);
            Active.setDisable(true);
            customerUin.setDisable(false);
            custName.setDisable(true);
            cancelBtn.setDisable(true);
            submitBtn.setDisable(true);
        } else if (status == 3) {
            submitBtn.setDisable(false);
            cancelBtn.setDisable(false);
            email.setDisable(false);
            contactNo.setDisable(false);
            custAddr.setDisable(false);
            Active.setDisable(false);
            customerUin.setDisable(true);
            citizenship.setDisable(true);
            custName.setDisable(true);
        } else if (status == 4){
            submitBtn.setText(" Delete Customer ");
            submitBtn.setDisable(false);
            cancelBtn.setText(" Cancel / Reset ");
            cancelBtn.setDisable(false);
            Active.setDisable(true);
            email.setDisable(true);
            contactNo.setDisable(true);
            custAddr.setDisable(true);
            citizenship.setDisable(true);            
            customerUin.setDisable(true);
            custName.setDisable(true);
        }else {
            cancelBtn.setDisable(true);
            submitBtn.setDisable(true);
            submitBtn.setText(" Submit ");
            cancelBtn.setText(" Cancel");
        }
    }
}
