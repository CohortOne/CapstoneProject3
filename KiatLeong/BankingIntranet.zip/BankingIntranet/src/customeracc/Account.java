package customeracc;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Account {
    
    private String AccType;
    private int AccNo;
    private String CustomerUIN;
    private String CVV;
    private String CardPin;
    private LocalDateTime LastUpdateDateTime;
    private LocalDateTime CreationDateTime;
    
    public enum acctType { //https://stackoverflow.com/questions/14319232/get-enum-name-from-enum-value/14319528
        Debit_Account(1), Fixed_Deposit(2), Credit_Card(3);
        public int selection;
        
        acctType(int selection) {
            this.selection = selection;
        }
        public static acctType getSelection(int selection){
            for (acctType type: acctType.values()){
                if (type.selection == selection){
                    return type;
                }
            }
            return null;
        }
    }

    public Account(String AccType, int AccNo, String CustomerUIN, String CVV, String CardPin, LocalDateTime LastUpdateDateTime, LocalDateTime CreationDateTime) {
        this.AccType = AccType;
        this.AccNo = AccNo;
        this.CustomerUIN = CustomerUIN;
        this.CVV = CVV;
        this.CardPin = CardPin;
        this.LastUpdateDateTime = LastUpdateDateTime;
        this.CreationDateTime = CreationDateTime;
    }

    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }

    public int getAccNo() {
        return AccNo;
    }

    public void setAccNo(int AccNo) {
        this.AccNo = AccNo;
    }

    public String getCustomerUIN() {
        return CustomerUIN;
    }

    public void setCustomerUIN(String CustomerUIN) {
        this.CustomerUIN = CustomerUIN;
    }

    public String getCVV() {
        return CVV;
    }

    public void setCVV(String CVV) {
        this.CVV = CVV;
    }

    public String getCardPin() {
        return CardPin;
    }

    public void setCardPin(String CardPin) {
        this.CardPin = CardPin;
    }

    public LocalDateTime getLastUpdateDateTime() {
        return LastUpdateDateTime;
    }

    public void setLastUpdateDateTime(LocalDateTime LastUpdateDateTime) {
        this.LastUpdateDateTime = LastUpdateDateTime;
    }

    public LocalDateTime getCreationDateTime() {
        return CreationDateTime;
    }

    public void setCreationDateTime(LocalDateTime CreationDateTime) {
        this.CreationDateTime = CreationDateTime;
    }

    @Override
    public String toString() {
        return "\t" + AccType + "\t " + AccNo + "\t " + CustomerUIN + "\t " + CVV + "\t " 
                + CardPin + "       "  
                + DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
                .format(LastUpdateDateTime) + "    " + DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
                .format(CreationDateTime);
    }
    
}
