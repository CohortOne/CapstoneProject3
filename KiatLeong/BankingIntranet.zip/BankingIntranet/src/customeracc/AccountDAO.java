
package customeracc;


import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import mainprog.LocaleEx;
import mainprog.MainPage;


public class AccountDAO {
    public static ResourceBundle accDAO;
    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }

    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
    public static int getNextAccNo(String accType) {
        int nxtAccNo = 0;
        if (accType.equals("Debit_Account")){
            nxtAccNo = 100000;
        }
        if (accType.equals("Fixed_Deposit")){
            nxtAccNo = 200000;
        }
        if (accType.equals("Credit_Card")){
            nxtAccNo = 300000;
        }
        try {
            Statement stmt = AccountDAO.init();
            String nxAccNo = "select max(AccNo) from bank.customeraccdetails where AccType = '" + accType + "';";
            ResultSet rs = stmt.executeQuery(nxAccNo);
            rs.next();
            nxtAccNo = ((rs.getInt(1)>nxtAccNo)?rs.getInt(1):nxtAccNo) + 1;            
        } catch (Exception e) {
            System.out.println(" Exception from CustomerDAO :: " + e.getMessage());
            e.printStackTrace();
        }
        return nxtAccNo;
    }

    public static boolean checkUIN(String UIN) throws Exception {
        accDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = AccountDAO.init();

        String insStmt = "Select count(*) from customerdetails where customerUIN = '" + UIN + "';";

        ResultSet rs = stmt.executeQuery(insStmt);

        if (rs.next() && rs.getInt(1)==1) {
            System.out.println(" \n\t\t         " + accDAO.getObject("accUINexist"));
        } else {
            System.out.println(" \n\t\t         " + accDAO.getObject("accUINnoExist"));
            return true;
        }

        return false;
    }
    
    public static boolean checkAccType(String accType, String UIN) throws Exception {
        accDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = AccountDAO.init();

        String insStmt = "Select count(*) from customeraccdetails where customerUIN = '" + UIN + "' AND accType = '" + accType + "';";

        ResultSet rs = stmt.executeQuery(insStmt);

        if (rs.next() && rs.getInt(1)==1) {
            System.out.println(" \n\t\t         " + accDAO.getObject("accExist"));
        } else {
            System.out.println(" \n\t\t         " + accDAO.getObject("accNoExist"));
            return false;
        }

        return true;
    }
    
    public static boolean insertAccount(Account a) throws Exception {
        accDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = AccountDAO.init();

        String insStmt = "insert into customeraccdetails (accType, accNo, customerUIN, CVV, CardPin, LastUpdateDateTime, creationDateTime) "
                + " values(\"" + a.getAccType()
                + "\"," + a.getAccNo()+ ",\"" + a.getCustomerUIN()+ "\"," + a.getCVV()+ "," + a.getCardPin()
                + ",\"" + a.getLastUpdateDateTime() + "\"," + "\"" + a.getCreationDateTime() + "\"" + ");"; 

        int result = stmt.executeUpdate(insStmt);

        if (result > 0) {
            System.out.println(accDAO.getObject("accCreateS"));            
        } else {
            System.out.println(accDAO.getObject("accCreateF"));
        }

        return true;
    }
    
    public static boolean insertAccdetails(Account a, double startBal) throws Exception {
        accDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = AccountDAO.init();

        String insStmt = "insert into debitaccdetails (accType, accNo, accBal, LastUpdateDateTime) "
                + " values(\"" + a.getAccType()
                + "\"," + a.getAccNo()+ "," + startBal + ",\"" + a.getLastUpdateDateTime() + "\"" + ");";

        int result = stmt.executeUpdate(insStmt);

        if (result > 0) {
            System.out.println(a.getAccType() + " " + a.getAccNo() + " " + accDAO.getObject("accDetailsPrefix") + " " + startBal);
        } else {
            System.out.println(" Insert Fail ");
        }

        return true;
    }
    
    public static boolean delAccount(String accNo) throws Exception {
        Statement stmt = AccountDAO.init();
        String delStmt = "delete from bank.customeraccdetails where AccNo = '" + accNo + "';";

        int result = stmt.executeUpdate(delStmt);
        if (result > 0) {
            System.out.println(" Delete Success ");
        } else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }

    public static List<Account> listAccount() throws Exception {
        Statement stmt = AccountDAO.init();
        List<Account> accList = new ArrayList<>();
        String qStmt = "Select * from Bank.customeraccdetails;";

        ResultSet rs = stmt.executeQuery(qStmt);        
        while (rs.next()) {
            accList.add(new Account(rs.getString("AccType"), rs.getInt("AccNo"), rs.getString("customerUIN"), rs.getString("CVV"), rs.getString("CardPin"),
                    rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return accList;
    }
    
    public static Account getAccount(int accNo) throws Exception {
        Statement stmt = AccountDAO.init();
        Account acct = null;
        String qStmt = "Select * from Bank.customeraccdetails where AccNo = '" + accNo + "';";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            acct = new Account(rs.getString("AccType"), rs.getInt("AccNo"), rs.getString("customerUIN"), rs.getString("CVV"), rs.getString("CardPin"),
                    rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class));
        }
        return acct;
    }

    public static List<Account> getAccount(String select, int choice) throws Exception {
        Connection conn = AccountDAO.initConn();
        List<Account> accList = new ArrayList<>();
        String qStmt = null;
        if (choice == 1)
            qStmt = "Select * from Bank.customeraccdetails where AccNo = ? ";
        if (choice == 2)
            qStmt = "Select * from Bank.customeraccdetails where customerUIN = ? ";        

        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, select);
        ResultSet rs = pStmt.executeQuery();
        while (rs.next()) {
            accList.add(new Account(rs.getString("AccType"), rs.getInt("AccNo"), rs.getString("customerUIN"), rs.getString("CVV"), rs.getString("CardPin"),
                    rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return accList;
    }
    
    public static boolean updateAccount(Account a) throws Exception {
        Statement stmt = AccountDAO.init();
        String updStmt = "Update Bank.Customeraccdetails set customerUIN = '" + a.getCustomerUIN() + "', CardPin = '"
                + a.getCardPin() + "', LastUpdateDateTime = '" + LocalDateTime.now() + "' where AccNo= '" + a.getAccNo() + "';";

        if (stmt.executeUpdate(updStmt) > 0) {
            System.out.println(" Update Success ");
        } else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
    public static List<Account> sortAccountsList(int userChoice) throws Exception {
        accDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Connection conn = AccountDAO.initConn();
        List<Account> accList = new ArrayList<>();
        String qStmt = null;
        
        switch (userChoice) {
            case 1:
                qStmt = "CALL GetAccountsByUIN()";
                break;
            case 2:
                qStmt = "CALL GetAccountsByLastUpdated()";
                break;
            case 3:
                qStmt = "CALL GetAccountsByAccType()";
                break;
            default:
                System.out.println(" \n\n \t\t #### " + accDAO.getObject("invalid") + " ####");
                return accList;                
        }
        
        CallableStatement cstmt = (CallableStatement) conn.prepareCall(qStmt);        
        ResultSet rs = cstmt.executeQuery();        
        while (rs.next()) {
            Account a = new Account(rs.getString("AccType"), rs.getInt("AccNo"), rs.getString("customerUIN"), rs.getString("CVV"), rs.getString("CardPin"),
                    rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class));
            accList.add(a);
        }
        return accList;
        
    }
}
