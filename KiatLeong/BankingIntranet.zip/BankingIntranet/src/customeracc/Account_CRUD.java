
package customeracc;

import debitsavingsacc.DebitAcc;
import debitsavingsacc.DebitAccDAO;
import debitsavingsacc.DebitAcc_CRUD;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import java.util.Scanner;
import mainprog.LocaleEx;
import mainprog.MainPage;
import static mainprog.MainPage.printFooter;
import static mainprog.MainPage.printHeader;


public class Account_CRUD {
    
    public static Scanner myObj = new Scanner(System.in); 
    public static ResourceBundle accCRUD;
    //Account methods
    public static int listAccounts() throws Exception {
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println("\t" + accCRUD.getObject("accType") + "  \t " + accCRUD.getObject("accNo") + "  " + accCRUD.getObject("UIN") + 
                "    " + accCRUD.getObject("cvv") + "  \t" + accCRUD.getObject("cardPin") + "\t" + accCRUD.getObject("lastupdate") + 
                "             " + accCRUD.getObject("createdDT"));
        printFooter();
        AccountDAO.listAccount().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int listAccountsByChoice() throws Exception {
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println(accCRUD.getObject("selectAccSort") + " ::\n\t\t 1 >> " + accCRUD.getObject("UIN") + "\n\t\t 2 >> " + accCRUD.getObject("lastupdate") 
                + "\n\t\t 3 >> " + accCRUD.getObject("accType"));
        System.out.print(accCRUD.getObject("selection") + "  :   ");
        int userChoice = myObj.nextInt();
        System.out.println("\n ********************************************************************************************* ");
        printHeader();
        System.out.println("\t" + accCRUD.getObject("accType") + "  \t " + accCRUD.getObject("accNo") + "  " + accCRUD.getObject("UIN") + 
                "    " + accCRUD.getObject("cvv") + "  \t" + accCRUD.getObject("cardPin") + "\t" + accCRUD.getObject("lastupdate") + 
                "             " + accCRUD.getObject("createdDT"));
        printFooter();
        AccountDAO.sortAccountsList(userChoice).stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int findAccountBy() throws Exception {
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println(accCRUD.getObject("findAccBy") + " ::\n\t\t 1 >> " + accCRUD.getObject("accNo") + "\n\t\t 2 >> " + accCRUD.getObject("UIN") + "\n\t\t ");
        System.out.print(accCRUD.getObject("selection") + "  :   ");
        int userChoice = myObj.nextInt();
        System.out.println("\n ********************************************************************************************* ");
        switch (userChoice) {
            case 1:
                printHeader();
                System.out.print(" \t" + accCRUD.getObject("enterAccNo" + accCRUD.getObject("find")) + " :: ");
                String accNo = myObj.useDelimiter("\n").next();
                printHeader();
                System.out.println("\t" + accCRUD.getObject("accType") + "  \t " + accCRUD.getObject("accNo") + "  " + accCRUD.getObject("UIN") + 
                "    " + accCRUD.getObject("cvv") + "  \t" + accCRUD.getObject("cardPin") + "\t" + accCRUD.getObject("lastupdate") + 
                "             " + accCRUD.getObject("createdDT"));
                printFooter();
                AccountDAO.getAccount(accNo, 1).stream().forEach(System.out::println);
                printFooter();
                break;
            case 2:
                printHeader();
                System.out.print(" \t" + accCRUD.getObject("enterUIN")+ accCRUD.getObject("find") + " :: ");
                String nric = myObj.next();
                printHeader();
                System.out.println("\t" + accCRUD.getObject("accType") + "  \t " + accCRUD.getObject("accNo") + "  " + accCRUD.getObject("UIN") + 
                "    " + accCRUD.getObject("cvv") + "  \t" + accCRUD.getObject("cardPin") + "\t" + accCRUD.getObject("lastupdate") + 
                "             " + accCRUD.getObject("createdDT"));
                printFooter();
                AccountDAO.getAccount(nric, 2).stream().forEach(System.out::println);
                printFooter();
                break;
            default:
                System.out.println(" \n\n \t\t #### " + accCRUD.getObject("invalid") + " ####");
                return 1;
        }
        return 1;
        
    }

    public static int delAccount() throws Exception {
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        listAccounts();
        System.out.print(" \t" + accCRUD.getObject("enterAccNoDel") + " :: ");
        String accNo = myObj.next();
        System.out.print(" \t" + accCRUD.getObject("confirmation") + " [y/n][Y/N]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(accCRUD.getObject("initAccDel") + " ::" + accNo);
            printHeader();
            AccountDAO.delAccount(accNo);
            printFooter();
        }
        return 1;
    }

    public static int updAccounts() throws Exception {
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        listAccounts();
        System.out.print(" \t" + accCRUD.getObject("enterAccNo") + accCRUD.getObject("update") + " :: ");
        int accNo = myObj.nextInt();
        System.out.print(" \t  " + accCRUD.getObject("updateconf") + " [Y/N][y/n]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(accCRUD.getObject("initupdate") + " " + accCRUD.getObject("accNo") + "  ::" + accNo);
            printHeader();
            Account a = AccountDAO.getAccount(accNo);
            System.out.println(accCRUD.getObject("selectedAcc") + "  ::: ");
            System.out.println(a);
            printFooter();

            System.out.println(" \n\t\t   " + accCRUD.getObject("UIN") + " of " + accCRUD.getObject("selectedAcc") + "   \t : " + a.getCustomerUIN());
            System.out.print(" \n\t\t   " + accCRUD.getObject("confUIN") + " [y/n]: :");
            String resp1 = myObj.next();
            if (resp1.equalsIgnoreCase("y")) {
                System.out.print(" \n\t\t   " + accCRUD.getObject("newUIN") + " " + accCRUD.getObject("selectedAcc") + "       \t : ");
                String newUIN = myObj.next();
                newUIN = MainPage.verifyUIN(newUIN);
                if (AccountDAO.checkUIN(newUIN))
                    return 1;
                a.setCustomerUIN(newUIN);
            }

            System.out.println(" \n\t\t   " + accCRUD.getObject("currentCardPin") + "   \t : " + a.getCardPin());
            System.out.print(" \n\t\t   " + accCRUD.getObject("confCardPin") + " [y/n]: :");
            String resp2 = myObj.next();
            if (resp2.equalsIgnoreCase("y")) {
                System.out.print(" \n\t\t   " + accCRUD.getObject("newCardPin") + "       \t : ");
                String newPin = myObj.next();
                newPin = MainPage.verifyCardPin(newPin);
                a.setCardPin(newPin);
            }            

            AccountDAO.updateAccount(a);
            printFooter();
        }
        return 1;
    }

    public static int insAccount() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" \t" + accCRUD.getObject("insertnewdetails") + "  :: ");
        printFooter();
        System.out.print(" \n\t\t        " + accCRUD.getObject("UIN") + "    \t : ");
        String UIN = myObj.next();        
        UIN = MainPage.verifyUIN(UIN);
        if (AccountDAO.checkUIN(UIN))
            return 1;
        System.out.println(" \n\t\t        " + accCRUD.getObject("select") + " " + accCRUD.getObject("accType") + "  : ");
        Account.acctType types[] = Account.acctType.values();
        for(Account.acctType type: types){
            System.out.println(" \n\t\t        "+type.selection+ ". " + type);
        }
        System.out.print(" \n\t\t         " + accCRUD.getObject("keyinselection") + "  :   ");
        int accTypeNo = myObj.nextInt();
        String accType = Account.acctType.getSelection(accTypeNo).toString();
        if (AccountDAO.checkAccType(accType, UIN))
            return 1;
        System.out.print(" \n\t\t         " + accCRUD.getObject("amtOpenAcc") + "  :   ");
        double accStartBal = myObj.nextDouble();
        if(accType.equals("Debit_Account") && accStartBal < DebitAccDAO.getMinBalance()){
            System.out.println(" \n\t\t        " + accCRUD.getObject("insuffAmt") + DebitAccDAO.getMinBalance());
            System.out.print(" \n\t\t         " + accCRUD.getObject("amtOpenAcc") + "  :   ");
            accStartBal = myObj.nextDouble();
        }
        System.out.print(" \n\t\t        " + accCRUD.getObject("cvv") + "  \t : ");
        String CVV = myObj.next();
        CVV = MainPage.verifyCVV(CVV);
        System.out.print(" \n\t\t        " + accCRUD.getObject("cardPin") + "  \t : ");
        String cardPin = myObj.next();
        cardPin = MainPage.verifyCardPin(cardPin);            
        int accNo = AccountDAO.getNextAccNo(accType);
        LocalDateTime createTime = LocalDateTime.now();
        LocalDateTime lastUpdate = createTime;       
        

        printHeader();        
        if (AccountDAO.insertAccount(new Account(accType, accNo, UIN, CVV, cardPin, lastUpdate, createTime))
                && AccountDAO.insertAccdetails(new Account(accType, accNo, UIN, CVV, cardPin, lastUpdate, createTime), accStartBal)) {
            printFooter();
        }
        return 1;
    }
    
    public static int DisplayOptionsCustAcc() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t " + accCRUD.getObject("accCRUD")+ " ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \t" + accCRUD.getObject("optionsAvailable") + " :: ");
        System.out.println(" \n\t\t1 >> " + accCRUD.getObject("insertNewAcc"));
        System.out.println(" \n\t\t2 >> " + accCRUD.getObject("updAcc"));
        System.out.println(" \n\t\t3 >> " + accCRUD.getObject("delAcc"));
        System.out.println(" \n\t\t4 >> " + accCRUD.getObject("listAcc")); 
        System.out.println(" \n\t\t5 >> " + accCRUD.getObject("sortAcc"));
        System.out.println(" \n\t\t6 >> " + accCRUD.getObject("findAccBy"));
        System.out.println(" \n\t\t7 >> " + accCRUD.getObject("accOperations"));
        System.out.println(" \n\t\t9 >> " + accCRUD.getObject("back"));
        System.out.println(" \n\t\t0 >> " + accCRUD.getObject("exit"));

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" " + accCRUD.getObject("selection") + "  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
    
    public static void acctOperations() throws Exception{
        accCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(accCRUD.getObject("accCRUD"));
        int secondOption = DisplayOptionsCustAcc();
        printHeader();
        System.out.print("\t\t " + accCRUD.getObject("optionselected") + " : \t\t");
                    
        switch (secondOption) {

            case 1:
                System.out.println(accCRUD.getObject("insertNewAcc") + " ::: ");
                printFooter();
                insAccount();
                break;
            case 2:
                System.out.println(accCRUD.getObject("updAcc") + " ::: ");
                updAccounts();
                break;
            case 3:
                System.out.println(accCRUD.getObject("delAcc") + " ::: ");
                delAccount();
                break;
            case 4:
                System.out.println(accCRUD.getObject("listAcc") + " ::: ");
                listAccounts();
                break;
            case 5:
                System.out.println(accCRUD.getObject("sortAcc") + " ::: ");
                listAccountsByChoice();
                break;
            case 6:
                System.out.println(accCRUD.getObject("findAccBy") + " ::: ");
                findAccountBy();
                break;
            case 7:
                System.out.println(accCRUD.getObject("accOperations") + " ::: ");
                DebitAcc_CRUD.selectAccType();
                break;
            case 9:
                System.out.println(accCRUD.getObject("back") + " ::: ");
                MainPage.mainMenu();
                break;    
            case 0:
                System.out.println(accCRUD.getObject("exit"));
                printFooter();
                Thread.sleep(2000);
                System.exit(0);
                break;
            default:
                //printHeader();
                System.out.println(" \n\n \t\t #### " + accCRUD.getObject("invalid") + " ####");
                printFooter();
                Thread.sleep(2000);
                break;
        }
    }
}
