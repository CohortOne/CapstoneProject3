package customerdetails;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import mainprog.MainPage;


public class Customer {
    
    private String custUin;
    private String CustomerName;
    private String CustomerAddr;
    private int CustomerContactNo;
    private String CustomerEmailAddr;
    private String CustomerResidentStatus;
    private byte CustomerStatus;
    private LocalDateTime LastUpdateDateTime;
    private LocalDateTime CreationDateTime;
    
    public enum citizenship { //https://stackoverflow.com/questions/14319232/get-enum-name-from-enum-value/14319528
        Singaporean(1), PR(2), Foreigner(3);
        public int selection;
        
        citizenship(int selection) {
            this.selection = selection;
        }
        public static citizenship getSelection(int selection){
            for (citizenship type: citizenship.values()){
                if (type.selection == selection){
                    return type;
                }
            }
            return null;
        }
    }

    public Customer(String CustomerUIN, String CustomerName, String CustomerAddr, int CustomerContactNo, String CustomerEmailAddr, String CustomerResidentStatus, byte CustomerStatus, LocalDateTime LastUpdateDateTime, LocalDateTime CreationDateTime) {
        this.custUin = CustomerUIN;
        this.CustomerName = CustomerName;
        this.CustomerAddr = CustomerAddr;
        this.CustomerContactNo = CustomerContactNo;
        this.CustomerEmailAddr = CustomerEmailAddr;
        this.CustomerResidentStatus = CustomerResidentStatus;
        this.CustomerStatus = CustomerStatus;
        this.LastUpdateDateTime = LastUpdateDateTime;
        this.CreationDateTime = CreationDateTime;
    }    

    public LocalDateTime getLastUpdateDateTime() {
        return LastUpdateDateTime;
    }

    public void setLastUpdateDateTime(LocalDateTime LastUpdateDateTime) {
        this.LastUpdateDateTime = LastUpdateDateTime;
    }

    public LocalDateTime getCreationDateTime() {
        return CreationDateTime;
    }

    public void setCreationDateTime(LocalDateTime CreationDateTime) {
        this.CreationDateTime = CreationDateTime;
    }

    public String getCustUin() {
        return custUin;
    }

    public void setCustUin(String custUin) {
        this.custUin = custUin;
    }
       
    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public String getCustomerAddr() {
        return CustomerAddr;
    }

    public void setCustomerAddr(String CustomerAddr) {
        this.CustomerAddr = CustomerAddr;
    }

    public int getCustomerContactNo() {
        return CustomerContactNo;
    }

    public void setCustomerContactNo(int CustomerContactNo) {
        this.CustomerContactNo = CustomerContactNo;
    }

    public String getCustomerEmailAddr() {
        return CustomerEmailAddr;
    }

    public void setCustomerEmailAddr(String CustomerEmailAddr) {
        this.CustomerEmailAddr = CustomerEmailAddr;
    }

    public String getCustomerResidentStatus() {
        return CustomerResidentStatus;
    }

    public void setCustomerResidentStatus(String CustomerResidentStatus) {
        this.CustomerResidentStatus = CustomerResidentStatus;
    }

    public byte getCustomerStatus() {
        return CustomerStatus;
    }

    public void setCustomerStatus(byte CustomerStatus) {
        this.CustomerStatus = CustomerStatus;
    }
    
    
    @Override
    public String toString() {
        return "\t" + custUin + "\t " + MainPage.padRight(CustomerName, 20) + "\t " + CustomerContactNo + "\t " + MainPage.padRight(CustomerAddr,20)
                + "\t " + MainPage.padRight(CustomerEmailAddr,20) + "\t " 
                + MainPage.padRight(CustomerResidentStatus, 10) + "\t " + (CustomerStatus ==1? "Active" : "Dormant") 
                + "\t " + MainPage.padRight(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
                .format(LastUpdateDateTime), 25) + "    " + MainPage.padRight(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
                .format(CreationDateTime), 25);        
    }
            
    
    
}
