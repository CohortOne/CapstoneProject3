package customerdetails;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mainprog.LocaleEx;
import mainprog.LoggingUtil;
import mainprog.MainPage;

public class CustomerDAO {
    public static ResourceBundle custDAO;

    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }

    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
    public static boolean checkUIN(String UIN) throws Exception {
        custDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = CustomerDAO.init();

        String insStmt = "Select count(*) from customerdetails where customerUIN = '" + UIN + "';";

        ResultSet rs = stmt.executeQuery(insStmt);

        if (rs.next() && rs.getInt(1)==1) {
            System.out.println(" \n\t\t         " + custDAO.getObject("nricexist"));
        } else {
            System.out.println(" \n\t\t         " + custDAO.getObject("nricNoexist"));
            return false;
        }

        return true;
    }

    public static boolean insertCustomer(Customer c) throws Exception {
        custDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = CustomerDAO.init();

        String insStmt = "insert into customerdetails (customerUIN, customerName, customerAddr, customerContactNo, customerEmailAddr, customerResidentStatus, customerStatus, LastUpdateDateTime, creationDateTime) "
                + " values(\"" + c.getCustUin()
                + "\",\"" + c.getCustomerName() + "\",\"" + c.getCustomerAddr() + "\"," + c.getCustomerContactNo() + ",\"" + c.getCustomerEmailAddr()
                + "\",\"" + c.getCustomerResidentStatus() + "\"," + c.getCustomerStatus() + "," + "\"" + c.getLastUpdateDateTime() + "\"," + "\"" + c.getCreationDateTime() + "\"" + ");";

        int result = stmt.executeUpdate(insStmt);

        if (result > 0) {
            LoggingUtil.doInfoLog(" Insert Success ");
        } else {
            LoggingUtil.doWarnLog(" Insert Fail, check logic of program ");
            System.out.println(custDAO.getObject("insertfail"));
        }

        return true;
    }

    public static boolean delCustomer(String cUIN) throws Exception {
        Statement stmt = CustomerDAO.init();
        String delStmt = "delete from bank.customerdetails where CustomerUIN = '" + cUIN + "';";

        int result = stmt.executeUpdate(delStmt);
        if (result > 0) {
            LoggingUtil.doInfoLog("Deletion is successful");
            //System.out.println(" Delete Success ");
        } else {
            LoggingUtil.doInfoLog("Deletion has failed. Please check.");
            //System.out.println(" Delete  Fail ");
        }
        return true;
    }

    public static List<Customer> listCustomer() throws Exception {
        Statement stmt = CustomerDAO.init();
        List<Customer> custList = new ArrayList<>();
        String qStmt = "Select * from Bank.customerdetails;";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            custList.add(new Customer(rs.getString("customerUIN"), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return custList;
    }
    
    public static ObservableList<Customer> listCustomerInApp() throws Exception {
        Statement stmt = CustomerDAO.init();
        ObservableList <Customer> custList = FXCollections.observableArrayList();
        String qStmt = "Select * from Bank.customerdetails;";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            custList.add(new Customer(rs.getString("customerUIN").trim(), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
            System.out.println(new Customer(rs.getString("customerUIN"), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return custList;
    }

    public static Customer getCustomer(String cUIN) throws Exception {
        Statement stmt = CustomerDAO.init();
        Customer cust = null;
        String qStmt = "Select * from Bank.Customerdetails where customerUIN = '" + cUIN + "';";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            cust = new Customer(rs.getString("customerUIN"), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class));
        }
        return cust;
    }

    public static List<Customer> getCustomer(int contactNo) throws Exception {
        Connection conn = CustomerDAO.initConn();
        List<Customer> custList = new ArrayList<>();
        String qStmt = "Select * from Bank.customerdetails where customerContactNo = ? ";

        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setInt(1, contactNo);
        ResultSet rs = pStmt.executeQuery();
        while (rs.next()) {
            custList.add(new Customer(rs.getString("customerUIN"), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return custList;
    }
    
    public static List<Customer> getCustomer(String select, int choice) throws Exception {
        Connection conn = CustomerDAO.initConn();
        List<Customer> custList = new ArrayList<>();
        String qStmt = null;
        if (choice == 1)
            qStmt = "Select * from Bank.customerdetails where customerName = ? ";
        if (choice == 2)
            qStmt = "Select * from Bank.customerdetails where customerUIN = ? ";
        if (choice == 4)
            qStmt = "Select * from Bank.customerdetails where customerEmailAddr = ? ";

        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, select);
        ResultSet rs = pStmt.executeQuery();
        while (rs.next()) {
            custList.add(new Customer(rs.getString("customerUIN"), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return custList;
    }


    public static boolean updateCustomer(Customer c) throws Exception {
        Statement stmt = CustomerDAO.init();
//        String lt = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
//                .format(Timestamp.from(Instant.now()).toLocalDateTime());

        String updStmt = "Update Bank.Customerdetails set customerAddr = '" + c.getCustomerAddr() + "', customerEmailAddr = '" + c.getCustomerEmailAddr() + "', customerContactNo = '"
                + c.getCustomerContactNo() + "', LastUpdateDateTime = '" + LocalDateTime.now() + "' where customerUIN = '" + c.getCustUin() + "';";

        if (stmt.executeUpdate(updStmt) > 0) {
            LoggingUtil.doInfoLog(" Update Success ");
        } else {
            LoggingUtil.doInfoLog(" Update Failed ");
        }
        return true;
    }

    public static List<Customer> sortCustomersList(int userChoice) throws Exception {
        custDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Connection conn = CustomerDAO.initConn();
        List<Customer> custList = new ArrayList<>();
        String qStmt = null;
        
        switch (userChoice) {
            case 1:
                qStmt = "CALL GetUpdatedCustomers()";
                break;
            case 2:
                qStmt = "CALL GetCustomersByName()";
                break;
            case 3:
                qStmt = "CALL GetCustomersByCreationDate()";
                break;
            default:
                System.out.println(" \n\n \t\t #### " + custDAO.getObject("invalid") + " ####");
                return custList;                
        }
        
        CallableStatement cstmt = (CallableStatement) conn.prepareCall(qStmt);        
        ResultSet rs = cstmt.executeQuery();        
        while (rs.next()) {
            Customer c = new Customer(rs.getString("customerUIN"), rs.getString("customerName"), rs.getString("customerAddr"), rs.getInt("customerContactNo"), rs.getString("customerEmailAddr"),
                    rs.getString("customerResidentStatus"), rs.getByte("customerStatus"), rs.getObject("LastUpdateDateTime", LocalDateTime.class), rs.getObject("CreationDateTime", LocalDateTime.class));
            custList.add(c);
        }
        return custList;
        
    }

}
