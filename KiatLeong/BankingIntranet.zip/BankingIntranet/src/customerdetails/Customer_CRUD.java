package customerdetails;


import java.time.LocalDateTime;
import java.util.ResourceBundle;
import java.util.Scanner;
import mainprog.LocaleEx;
import mainprog.LoggingUtil;
import mainprog.MainPage;
import static mainprog.MainPage.printFooter;
import static mainprog.MainPage.printHeader;


public class Customer_CRUD {

    public static Scanner myObj = new Scanner(System.in);    
    public static ResourceBundle customerPage;
    //Methods for Customers
    public static int listCustomers() throws Exception {
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println("\t"+customerPage.getObject("UIN")+"  \t\t "+customerPage.getObject("name")+" \t\t\t"+customerPage.getObject("contact")+
                "    \t"+customerPage.getObject("addr")+"    \t\t"+customerPage.getObject("email")+" \t\t\t"+customerPage.getObject("citizenship")+
                " \t"+customerPage.getObject("status")+"    "+customerPage.getObject("lastupdate")+"          \t"+customerPage.getObject("createdDT"));
        printFooter();
        CustomerDAO.listCustomer().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int listCustomersByChoice() throws Exception {
        LoggingUtil.doInfoLog("Start of sorted listing method");
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println(customerPage.getObject("selectsortlist")+" ::\n\t\t 1 >> "+customerPage.getObject("lastupdate")+
                "\n\t\t 2 >> "+ customerPage.getObject("name") +"\n\t\t 3 >> "+customerPage.getObject("createdDT"));
        System.out.print(customerPage.getObject("selection") + "   :   ");
        int userChoice = myObj.nextInt();
        LoggingUtil.doInfoLog(customerPage.getObject("userchoice") + " " + userChoice);
        System.out.println("\n ********************************************************************************************* ");
        printHeader();
        System.out.println("\t"+customerPage.getObject("UIN")+"  \t\t "+customerPage.getObject("name")+" \t\t\t"+customerPage.getObject("contact")+
                "    \t"+customerPage.getObject("addr")+"    \t\t"+customerPage.getObject("email")+" \t\t\t"+customerPage.getObject("citizenship")+
                " \t"+customerPage.getObject("status")+"    "+customerPage.getObject("lastupdate")+"          \t"+customerPage.getObject("createdDT"));
        printFooter();
        CustomerDAO.sortCustomersList(userChoice).stream().forEach(System.out::println);
        printFooter();
        LoggingUtil.doInfoLog("End of sorted listing method");
        return 1;
    }

    public static int findCustomerBy() throws Exception {
        LoggingUtil.doInfoLog("Start of finding customer method");
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println(customerPage.getObject("findcustomerby") + " ::\n\t\t 1 >> "+ customerPage.getObject("name") +
                "\n\t\t 2 >> " + customerPage.getObject("UIN") + "\n\t\t 3 >> " + customerPage.getObject("contact") + 
                "\n\t\t 4 >> " + customerPage.getObject("email"));
        System.out.print(customerPage.getObject("selection") + "  :   ");
        int userChoice = myObj.nextInt();
        LoggingUtil.doInfoLog(customerPage.getObject("userchoice") + " "+userChoice);
        System.out.println("\n ********************************************************************************************* ");
        
        switch (userChoice) {
            case 1:
                printHeader();
                System.out.print(" \t" + customerPage.getObject("enterName") + customerPage.getObject("find") + " :: ");
                String name = myObj.useDelimiter("\n").next();
                name = MainPage.verifyName(name);
                LoggingUtil.doInfoLog("Name is verified");
                printHeader();
                System.out.println("\t"+customerPage.getObject("UIN")+"  \t\t "+customerPage.getObject("name")+" \t\t\t"+customerPage.getObject("contact")+
                "    \t"+customerPage.getObject("addr")+"    \t\t"+customerPage.getObject("email")+" \t\t\t"+customerPage.getObject("citizenship")+
                " \t"+customerPage.getObject("status")+"    "+customerPage.getObject("lastupdate")+"          \t"+customerPage.getObject("createdDT"));
                printFooter();
                CustomerDAO.getCustomer(name, 1).stream().forEach(System.out::println);
                LoggingUtil.doInfoLog("Customer with name '"+ name + "' is found");
                printFooter();
                break;
            case 2:
                printHeader();
                System.out.print(" \t" + customerPage.getObject("enterUIN")+ customerPage.getObject("find") + " :: ");
                String nric = myObj.next();
                nric = MainPage.verifyUIN(nric);
                LoggingUtil.doInfoLog("NRIC is verified");
                printHeader();
                System.out.println("\t"+customerPage.getObject("UIN")+"  \t\t "+customerPage.getObject("name")+" \t\t\t"+customerPage.getObject("contact")+
                "    \t"+customerPage.getObject("addr")+"    \t\t"+customerPage.getObject("email")+" \t\t\t"+customerPage.getObject("citizenship")+
                " \t"+customerPage.getObject("status")+"    "+customerPage.getObject("lastupdate")+"          \t"+customerPage.getObject("createdDT"));
                printFooter();
                CustomerDAO.getCustomer(nric, 2).stream().forEach(System.out::println);
                LoggingUtil.doInfoLog("Customer with NRIC '"+ nric + "' is found");
                printFooter();
                break;
            case 3:
                printHeader();
                System.out.print(" \t" + customerPage.getObject("entercontact") + customerPage.getObject("find") + " :: ");
                int contactNo = myObj.nextInt();
                contactNo = Integer.parseInt(MainPage.verifyContactNo(Integer.toString(contactNo)));
                LoggingUtil.doInfoLog("Contact No is verified");
                printHeader();
                System.out.println("\t"+customerPage.getObject("UIN")+"  \t\t "+customerPage.getObject("name")+" \t\t\t"+customerPage.getObject("contact")+
                "    \t"+customerPage.getObject("addr")+"    \t\t"+customerPage.getObject("email")+" \t\t\t"+customerPage.getObject("citizenship")+
                " \t"+customerPage.getObject("status")+"    "+customerPage.getObject("lastupdate")+"          \t"+customerPage.getObject("createdDT"));
                printFooter();
                CustomerDAO.getCustomer(contactNo).stream().forEach(System.out::println);
                LoggingUtil.doInfoLog("Customer with Contact No '"+ contactNo + "' is found");
                printFooter();
                break;
            case 4:
                printHeader();
                System.out.print(" \t" + customerPage.getObject("enteremail")+ customerPage.getObject("find") + " :: ");
                String email = myObj.next();
                email = MainPage.verifyEmail(email);
                LoggingUtil.doInfoLog("Email is verified");
                printHeader();
                System.out.println("\t"+customerPage.getObject("UIN")+"  \t\t "+customerPage.getObject("name")+" \t\t\t"+customerPage.getObject("contact")+
                "    \t"+customerPage.getObject("addr")+"    \t\t"+customerPage.getObject("email")+" \t\t\t"+customerPage.getObject("citizenship")+
                " \t"+customerPage.getObject("status")+"    "+customerPage.getObject("lastupdate")+"          \t"+customerPage.getObject("createdDT"));
                printFooter();
                CustomerDAO.getCustomer(email, 4).stream().forEach(System.out::println);
                LoggingUtil.doInfoLog("Customer with Email Addr '"+ email + "' is found");
                printFooter();
                break;
            default:
                System.out.println(" \n\n \t\t #### " + customerPage.getObject("invalid") + " ####");
                return 1;
        }
        LoggingUtil.doInfoLog("End of finding customer method");
        return 1;
        
    }

    public static int delCustomers() throws Exception {
        LoggingUtil.doInfoLog("Start of delete customer method");
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        listCustomers();
        System.out.print(" \t" + customerPage.getObject("enterUIN") + customerPage.getObject("delete") + " :: ");
        String cUIN = myObj.next();
        cUIN = MainPage.verifyUIN(cUIN);
        LoggingUtil.doInfoLog("Customer UIN verified");
        System.out.print(" \n\t\t    " + customerPage.getObject("confirmation") + " [y/n][Y/N]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" \n\t\t     " + customerPage.getObject("initdelete") + " ::" + cUIN);
            printHeader();
            if(CustomerDAO.delCustomer(cUIN)){
                System.out.println(" \n\t\t    "+ customerPage.getObject("deletesuccess") + ".");   
            }
            printFooter();
        }
        LoggingUtil.doInfoLog("End of delete customer method");
        return 1;
    }

    public static int updCustomers() throws Exception {
        LoggingUtil.doInfoLog("Start of updating customer method");
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        listCustomers();
        System.out.print(" \t" + customerPage.getObject("enterUIN")+ customerPage.getObject("update") + " :: ");
        String cUIN = myObj.next();
        cUIN = MainPage.verifyUIN(cUIN);
        LoggingUtil.doInfoLog("Customer UIN verified");
        System.out.print(" \t " + customerPage.getObject("confupdatecust") + " [Y/N][y/n]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(customerPage.getObject("initupdate") + " " + customerPage.getObject("UIN")+ " ::" + cUIN);
            printHeader();
            Customer c = CustomerDAO.getCustomer(cUIN);
            System.out.println(customerPage.getObject("selectedcust") + " ::: ");
            System.out.println(c);
            LoggingUtil.doInfoLog("Selected customer to update:");
            LoggingUtil.doInfoLog(c.toString());
            printFooter();

            System.out.println(" \n\t\t   " + customerPage.getObject("currentaddr") + "   \t : " + c.getCustomerAddr());
            System.out.print(" \n\t\t    " + customerPage.getObject("confaddr") + " [y/n]  :  ");
            String resp1 = myObj.next();
            if (resp1.equalsIgnoreCase("y")) {
                System.out.print(" \n\t\t   "+ customerPage.getObject("newaddr") +"       \t : ");
                String address = myObj.useDelimiter("\n").next();
                c.setCustomerAddr(address);
                LoggingUtil.doInfoLog("New address : " + address);
            }

            System.out.println(" \n\t\t   " + customerPage.getObject("currentemail") + "   \t : " + c.getCustomerEmailAddr());
            System.out.print(" \n\t\t    " + customerPage.getObject("confemail") + " [y/n]  :  ");
            String resp2 = myObj.next();
            if (resp2.equalsIgnoreCase("y")) {
                System.out.print(" \n\t\t   " + customerPage.getObject("newemail") + "       \t : ");
                String email = myObj.next();
                email = MainPage.verifyEmail(email);
                c.setCustomerEmailAddr(email);
                LoggingUtil.doInfoLog("New email address : " + email);
            }

            System.out.println(" \n\t\t    " + customerPage.getObject("currentcontact") + "    \t : " + c.getCustomerContactNo());
            System.out.print(" \n\t\t    " + customerPage.getObject("confcontact") + " [y/n]  :  ");
            String resp3 = myObj.next();
            if (resp3.equalsIgnoreCase("y")) {
                System.out.print(" \n\t\t    " + customerPage.getObject("newcontact") + "          \t : ");
                int contactNo = myObj.nextInt();
                contactNo = Integer.parseInt(MainPage.verifyContactNo(Integer.toString(contactNo)));
                c.setCustomerContactNo(contactNo);
                LoggingUtil.doInfoLog("New Contact No : " + contactNo);
            }

            if (CustomerDAO.updateCustomer(c)){
                System.out.println(" \n\t\t    " + customerPage.getObject("updatesuccess"));
                LoggingUtil.doInfoLog("Customer details has been updated. New details as follow : " );
                LoggingUtil.doInfoLog(c.toString());
                printFooter();
            }
        }
        return 1;
    }

    public static int insCustomer() throws Exception {        
        LoggingUtil.doInfoLog("Start of inserting new Customer method");
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" \t" + customerPage.getObject("insertnewdetails") + "  :: ");
        printFooter();
        System.out.print(" \n\t\t        " + customerPage.getObject("customerIC") + "    \t : ");
        String UIN = myObj.next();
        UIN = MainPage.verifyUIN(UIN);
        if (CustomerDAO.checkUIN(UIN))
            return 1;
        System.out.print(" \n\t\t        " + customerPage.getObject("name") + "     \t : ");
        String name = myObj.useDelimiter("\n").next();
        name = MainPage.verifyName(name);
        System.out.print(" \n\t\t        " + customerPage.getObject("addr") + "     \t : ");
        String address = myObj.useDelimiter("\n").next();    //name = myObj.nextLine();
        System.out.print(" \n\t\t        " + customerPage.getObject("contact") + "  \t : ");
        int contactNo = myObj.nextInt();
        contactNo = Integer.parseInt(MainPage.verifyContactNo(Integer.toString(contactNo)));
        System.out.print(" \n\t\t        " + customerPage.getObject("email") + "          \t : ");
        String email = myObj.next();
        email = MainPage.verifyEmail(email);
        System.out.print(" \n\t\t        " + customerPage.getObject("citizenship") + "       \t : ");
        Customer.citizenship types[] = Customer.citizenship.values();
        for(Customer.citizenship type: types){
            System.out.println(" \n\t\t        "+type.selection+ ". " + type);
        }
        System.out.print(" \n\t\t         " + customerPage.getObject("keyinselection") + "  :   ");
        int userInput = myObj.nextInt();
        String citizenship = Customer.citizenship.getSelection(userInput).toString();               
        LocalDateTime createTime = LocalDateTime.now();
        LocalDateTime lastUpdate = createTime;
        
//        String createTime = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
//                .format(LocalDateTime.now());
//        String lastUpdate = createTime;

//        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//        LocalDate date = LocalDate.parse(dob, sourceFormatter);
        printHeader();
        LoggingUtil.doInfoLog("About to insert new customer with following details");
        LoggingUtil.doInfoLog((new Customer(UIN.toUpperCase(), name, address, contactNo, email, citizenship, (byte) 1, lastUpdate, createTime)).toString());
        if (CustomerDAO.insertCustomer(new Customer(UIN.toUpperCase(), name, address, contactNo, email, citizenship, (byte) 1, lastUpdate, createTime))) {
            printFooter();
        }
        LoggingUtil.doInfoLog("End of insert new customer method.");
        return 1;
    }
    
      
    
    
    public static int DisplayOptionsCust() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t " + customerPage.getObject("custCRUD") + " ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \t" + customerPage.getObject("optionsAvailable") + " :: ");
        System.out.println(" \n\t\t1 >> " + customerPage.getObject("insertnewcust"));
        System.out.println(" \n\t\t2 >> " + customerPage.getObject("updatecust"));
        System.out.println(" \n\t\t3 >> " + customerPage.getObject("delcust"));
        System.out.println(" \n\t\t4 >> " + customerPage.getObject("listcust")); 
        System.out.println(" \n\t\t5 >> " + customerPage.getObject("sortlistcust"));
        System.out.println(" \n\t\t6 >> " + customerPage.getObject("findcustomerby"));
        System.out.println(" \n\t\t9 >> " + customerPage.getObject("back"));
        System.out.println(" \n\t\t0 >> " + customerPage.getObject("exit"));

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(customerPage.getObject("selection") + "  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
    
    public static void customerOperations() throws Exception{
        customerPage = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(customerPage.getObject("custCRUD"));
        printFooter();
        int firstOption = DisplayOptionsCust();
        printHeader();
        System.out.print("\t\t " + customerPage.getObject("optionselected") + " : \t\t");
                    
        switch (firstOption) {
            case 1:
                System.out.println(customerPage.getObject("insertnewcust") + " ::: ");
                printFooter();
                insCustomer();
                break;
            case 2:
                System.out.println(customerPage.getObject("updatecust") + " ::: ");
                updCustomers();
                break;
            case 3:
                System.out.println(customerPage.getObject("delcust") + " ::: ");
                delCustomers();
                break;
            case 4:
                System.out.println(customerPage.getObject("listcust") + " ::: ");
                listCustomers();
                break;
            case 5:
                System.out.println(customerPage.getObject("sortlistcust") + " ::: ");
                listCustomersByChoice();
                break;
            case 6:
                System.out.println(customerPage.getObject("findcustomerby") + " ::: ");
                findCustomerBy();
                break;
            case 9:
                System.out.println(customerPage.getObject("back") + " ::: ");
                MainPage.mainMenu();
                break;
            case 0:
                System.out.println(customerPage.getObject("exit"));
                printFooter();
                Thread.sleep(2000);
                System.exit(0);
                break;
            default:
                //printHeader();
                System.out.println(" \n\n \t\t #### " + customerPage.getObject("invalid") + " ####");
                printFooter();
                Thread.sleep(2000);
                break;
        }
    }
}
