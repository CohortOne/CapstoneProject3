
package transaction;

import java.time.LocalDateTime;
import java.util.ResourceBundle;
import java.util.Scanner;
import mainprog.LocaleEx;
import mainprog.MainPage;
import static mainprog.MainPage.printFooter;
import static mainprog.MainPage.printHeader;


public class Trans_CRUD {
    public static Scanner myObj = new Scanner(System.in);
    public static ResourceBundle transCRUD;
    //Methods
    public static int listAccounts(int accNo) throws Exception {
        transCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println("\t" + transCRUD.getObject("accType") + "  \t " + transCRUD.getObject("accNo") + "  \t" + transCRUD.getObject("transRec") + " "
                + "\t" + transCRUD.getObject("transType") + "     \t" + transCRUD.getObject("transDesc") + "  \t\t\t\t\t" + transCRUD.getObject("createdDT"));
        printFooter();
        TransDAO.listAccount(accNo).stream().forEach(System.out::println);
        printFooter();
        return 1;
    }    
    
    public static int transacLine(String transType, double amt, int accNo, String accType) throws Exception{
        int transTypeNo = 0;
        String transDesc = "";
        if (transType.equalsIgnoreCase("Deposit")){
            transTypeNo = 1;
            transDesc = "Deposit of "+ amt + " has been made at the bank.";
        }
        if (transType.equalsIgnoreCase("Withdrawal")){
            transTypeNo = 2;
            transDesc = "Withdrawal of "+ amt + " has been made at the bank.";
        }
        LocalDateTime createdDateTime = LocalDateTime.now();
        printHeader();        
        if (TransDAO.insertTransacLine(new Trans(accType, accNo, amt, transTypeNo, transDesc, createdDateTime))) {
            printFooter();
        }
        return 1;        
    }
        
}
