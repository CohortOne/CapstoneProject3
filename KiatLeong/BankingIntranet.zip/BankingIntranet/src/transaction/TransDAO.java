
package transaction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import mainprog.LocaleEx;
import mainprog.MainPage;

public class TransDAO {
    public static ResourceBundle transDAO;
    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }

    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
    public static List<Trans> listAccount(int accNo) throws Exception {
        Connection conn = TransDAO.initConn();
        List<Trans> accList = new ArrayList<>();
        String qStmt = "Select * from Bank.transactions where AccNo = ? ";
               

        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, Integer.toString(accNo));
        ResultSet rs = pStmt.executeQuery();
        while (rs.next()) {
            accList.add(new Trans(rs.getString("AccType"), rs.getInt("AccNo"), rs.getDouble("TransRec"), rs.getInt("TransType"), rs.getString("TransDesc"),
                    rs.getObject("CreationDateTime", LocalDateTime.class)));
        }
        return accList;
    }
    
    public static Trans getAccount(int accNo) throws Exception {
        Statement stmt = TransDAO.init();
        Trans record = null;
        String qStmt = "Select * from Bank.debitaccdetails where AccNo = '" + accNo + "';";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            record = new Trans(rs.getString("AccType"), rs.getInt("AccNo"), rs.getDouble("TransRec"), rs.getInt("TransType"), rs.getString("TransDesc"),
                    rs.getObject("CreationDateTime", LocalDateTime.class));
        }
        return record;
    }
    
    public static boolean insertTransacLine(Trans a) throws Exception {
        transDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = TransDAO.init();

        String insStmt = "insert into transactions (accType, accNo, TransRec, transtype, transdesc, creationDateTime) "
                + " values(\"" + a.getAccType()
                + "\"," + a.getAccNo()+ ", " + a.getTransRec()+ ", " + a.getTransType()+ ", \"" + a.getTransDesc()
                + "\", \"" + a.getCreationDateTime() + "\");"; 

        int result = stmt.executeUpdate(insStmt);

        if (result > 0) {
            System.out.println(transDAO.getObject("transInSuccess"));            
        } else {
            System.out.println(transDAO.getObject("transInFail"));
        }

        return true;
    }
}
