
package transaction;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Trans {
    private String AccType;
    private int AccNo;
    private double TransRec;
    private int TransType;
    private String TransDesc;
    private LocalDateTime CreationDateTime;

    public enum transType { //https://stackoverflow.com/questions/14319232/get-enum-name-from-enum-value/14319528
        Deposit(1), Withdrawal(2), Interest(3), Transfer(4), Card_Trans(5), Annual_Fee(6), Late_Payment_Fee(7), FX_Charges(8), Auto_Payment(9);
        
        public int selection;
        
        public int getTransType(){
            return selection;
        }
        
        transType(int selection) {
            this.selection = selection;
        }
        public static transType getSelection(int selection){
            for (transType type: transType.values()){
                if (type.selection == selection){
                    return type;
                }
            }
            return null;
        }
    }
    
    public Trans(String AccType, int AccNo, double TransRec, int TransType, String TransDesc, LocalDateTime CreationDateTime) {
        this.AccType = AccType;
        this.AccNo = AccNo;
        this.TransRec = TransRec;
        this.TransType = TransType;
        this.TransDesc = TransDesc;
        this.CreationDateTime = CreationDateTime;
    }
    
    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }

    public int getAccNo() {
        return AccNo;
    }

    public void setAccNo(int AccNo) {
        this.AccNo = AccNo;
    }

    public double getTransRec() {
        return TransRec;
    }

    public void setTransRec(double TransRec) {
        this.TransRec = TransRec;
    }

    public int getTransType() {
        return TransType;
    }

    public void setTransType(int TransType) {
        this.TransType = TransType;
    }

    public String getTransDesc() {
        return TransDesc;
    }

    public void setTransDesc(String TransDesc) {
        this.TransDesc = TransDesc;
    }

    public LocalDateTime getCreationDateTime() {
        return CreationDateTime;
    }

    public void setCreationDateTime(LocalDateTime CreationDateTime) {
        this.CreationDateTime = CreationDateTime;
    }

    @Override
    public String toString() {
        return "\t" + AccType + "\t " + AccNo + "\t\t  " + TransRec + "\t\t\t  " + transType.getSelection(TransType) + "\t\t " 
                + TransDesc + "\t\t\t " +   
                DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).format(CreationDateTime);
    }
    
}
