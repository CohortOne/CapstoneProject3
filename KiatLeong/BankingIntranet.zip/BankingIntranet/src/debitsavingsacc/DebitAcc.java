
package debitsavingsacc;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class DebitAcc {
    private String AccType;
    private int AccNo;
    private double AccBal;
    public double MinBal = 50;
    private byte AccStatus;
    private double TransNotifLimit;
    private LocalDateTime LastUpdateDateTime;
    
    public enum acctStatus { //https://stackoverflow.com/questions/14319232/get-enum-name-from-enum-value/14319528
        Active(1), Dormant(2), Freeze(3), Suspended(4), Cancelled(5);
        public int selection;
        
        acctStatus(int selection) {
            this.selection = selection;
        }
        public static acctStatus getSelection(int selection){
            for (acctStatus type: acctStatus.values()){
                if (type.selection == selection){
                    return type;
                }
            }
            return null;
        }
    }

    public DebitAcc(String AccType, int AccNo, double AccBal, double MinBal, byte AccStatus, double TransNotifLimit, LocalDateTime LastUpdateDateTime) {
        this.AccType = AccType;
        this.AccNo = AccNo;
        this.AccBal = AccBal;
        this.MinBal = MinBal;
        this.AccStatus = AccStatus;
        this.TransNotifLimit = TransNotifLimit;
        this.LastUpdateDateTime = LastUpdateDateTime;
    }   
    
    public DebitAcc(){      
    }

    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }

    public int getAccNo() {
        return AccNo;
    }

    public void setAccNo(int AccNo) {
        this.AccNo = AccNo;
    }

    public double getAccBal() {
        return AccBal;
    }

    public void setAccBal(double AccBal) {
        this.AccBal = AccBal;
    }

    public double getMinBal() {
        return MinBal;
    }

    public void setMinBal(double MinBal) {
        this.MinBal = MinBal;
    }

    public byte getAccStatus() {
        return AccStatus;
    }

    public void setAccStatus(byte AccStatus) {
        this.AccStatus = AccStatus;
    }

    public double getTransNotifLimit() {
        return TransNotifLimit;
    }

    public void setTransNotifLimit(double TransNotifLimit) {
        this.TransNotifLimit = TransNotifLimit;
    }

    public LocalDateTime getLastUpdateDateTime() {
        return LastUpdateDateTime;
    }

    public void setLastUpdateDateTime(LocalDateTime LastUpdateDateTime) {
        this.LastUpdateDateTime = LastUpdateDateTime;
    }

    @Override
    public String toString() {
        return "\t" + AccType + "\t " + AccNo + "\t\t  " + AccBal + "\t\t\t  " + MinBal + "\t\t " 
                + acctStatus.getSelection(AccStatus) + "\t\t\t " + TransNotifLimit +  "\t\t\t"  
                + DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)
                .format(LastUpdateDateTime);
    }
        
}
