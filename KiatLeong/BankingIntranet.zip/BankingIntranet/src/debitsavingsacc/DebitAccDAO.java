
package debitsavingsacc;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import mainprog.LocaleEx;
import mainprog.MainPage;


public class DebitAccDAO {
    public static ResourceBundle debitDAO;
    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }

    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
    public static boolean checkAccNo(int accNo) throws Exception {
        debitDAO = LocaleEx.inputLang(MainPage.currentLanguage);
        Statement stmt = DebitAccDAO.init();

        String insStmt = "Select count(*) from debitaccdetails where accNo = '" + accNo + "';";

        ResultSet rs = stmt.executeQuery(insStmt);

        if (rs.next() && rs.getInt(1)==1) {            
        } else {
            System.out.println(" \n\t\t         " + debitDAO.getObject("accNoExist"));
            return false;
        }

        return true;
    }
    
    public static DebitAcc getAccount(int accNo) throws Exception {
        Statement stmt = DebitAccDAO.init();
        DebitAcc acct = null;
        String qStmt = "Select * from Bank.debitaccdetails where AccNo = '" + accNo + "';";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            acct = new DebitAcc(rs.getString("AccType"), rs.getInt("AccNo"), rs.getDouble("AccBal"), rs.getDouble("MinBal"), rs.getByte("AccStatus"),
                    rs.getDouble("TransNotifLimit"), rs.getObject("LastUpdateDateTime", LocalDateTime.class));
        }
        return acct;
    }
    
    public static List<DebitAcc> listAccount() throws Exception {
        Connection conn = DebitAccDAO.initConn();
        List<DebitAcc> accList = new ArrayList<>();
        String qStmt = "CALL GetDebitAccountsDetails()";                
        
        CallableStatement cstmt = (CallableStatement) conn.prepareCall(qStmt);        
        ResultSet rs = cstmt.executeQuery();        
        while (rs.next()) {
            DebitAcc a = new DebitAcc(rs.getString("AccType"), rs.getInt("AccNo"), rs.getDouble("AccBal"), rs.getDouble("MinBal"), rs.getByte("AccStatus"),
                    rs.getDouble("TransNotifLimit"), rs.getObject("LastUpdateDateTime", LocalDateTime.class));
            accList.add(a);
        }
        return accList;
        
    }
    
    public static double getMinBalance() throws Exception {
        Statement stmt = DebitAccDAO.init();
        double minBal = 0;
        String qStmt = "SELECT COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'debitaccdetails' AND COLUMN_NAME = 'minbal';";

        ResultSet rs = stmt.executeQuery(qStmt);
        while (rs.next()) {
            minBal = rs.getDouble("Column_Default");
        }
        return minBal;
    }
    
    public static boolean updateAccStatus(DebitAcc da) throws Exception {
        Statement stmt = DebitAccDAO.init();
        String updStmt = "Update Bank.debitaccdetails set AccStatus = '" + da.getAccStatus() 
                + "', LastUpdateDateTime = '" + LocalDateTime.now() + "' where AccNo= '" + da.getAccNo() + "';";

        if (stmt.executeUpdate(updStmt) > 0) {
            System.out.println(" Update Success ");
        } else {
            System.out.println(" Update Failed ");
        }
        return true;
    }    
    
    public static boolean updateMinBal(double newMinBal, String resp) throws Exception {
        Statement stmt = DebitAccDAO.init();
        String updStmt = null;
        String updStmt2 = null;
        if (resp.equalsIgnoreCase("y")){
            updStmt = "Alter table debitaccdetails alter minBal set default " + newMinBal + ";";
        }else{ 
            updStmt = "Alter table debitaccdetails alter minBal set default " + newMinBal + ";"; 
            updStmt2 = "update debitaccdetails set minbal = " + newMinBal + " where accNo>0;";
        }               

        if (!resp.equalsIgnoreCase("y") && stmt.executeUpdate(updStmt) >= 0 && stmt.executeUpdate(updStmt2) >0){
            System.out.println(" Update Success ");
        }else if(stmt.executeUpdate(updStmt) >= 0){
            System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
    public static boolean updateAccBal(DebitAcc da) throws Exception {
        Statement stmt = DebitAccDAO.init();
        String updStmt = "Update Bank.debitaccdetails set AccBal = '" + da.getAccBal() 
                + "', LastUpdateDateTime = '" + LocalDateTime.now() + "' where AccNo= '" + da.getAccNo() + "';";

        if (stmt.executeUpdate(updStmt) > 0) {
            System.out.println(" Update Success ");
        } else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
    public static boolean updateTransLimit(DebitAcc da) throws Exception {
        Statement stmt = DebitAccDAO.init();
        String updStmt = "Update Bank.debitaccdetails set TransNotifLimit = '" + da.getTransNotifLimit() 
                + "', LastUpdateDateTime = '" + LocalDateTime.now() + "' where AccNo= '" + da.getAccNo() + "';";

        if (stmt.executeUpdate(updStmt) > 0) {
            System.out.println(" Update Success ");
        } else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
        
}
