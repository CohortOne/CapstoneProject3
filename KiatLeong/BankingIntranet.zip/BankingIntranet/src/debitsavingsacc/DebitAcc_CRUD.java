
package debitsavingsacc;

import customeracc.Account_CRUD;
import java.util.ResourceBundle;
import java.util.Scanner;
import mainprog.LocaleEx;
import mainprog.MainPage;
import static mainprog.MainPage.printFooter;
import static mainprog.MainPage.printHeader;
import transaction.Trans_CRUD;


public class DebitAcc_CRUD {
    public static Scanner myObj = new Scanner(System.in);
    public static ResourceBundle debitCRUD;
    //Methods
    public static int listAccounts() throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println("\t" + debitCRUD.getObject("accType") + "  \t " + debitCRUD.getObject("accNo") + "  \t " + debitCRUD.getObject("accBal") +
                " \t " + debitCRUD.getObject("minBal") + "    \t " + debitCRUD.getObject("accStatus") + "  \t" + debitCRUD.getObject("transNotLim") +
                " \t" + debitCRUD.getObject("lastupdate"));
        printFooter();
        DebitAccDAO.listAccount().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int updateMinBal() throws Exception{
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println(debitCRUD.getObject("updMinBalSel"));
        printFooter();
        System.out.print(" \n\t\t   " + debitCRUD.getObject("currentMinBal") + "      \t : $" + DebitAccDAO.getMinBalance());        
        System.out.print(" \n\t\t   " + debitCRUD.getObject("setNewMin") + "       \t : ");
        double newMinBal = myObj.nextDouble();        
        System.out.print(" \n\t\t   " + debitCRUD.getObject("confUpdMin") + " [y/n] ");
        System.out.print(" \n\t\t   " + debitCRUD.getObject("confUpdMinCond") + " :");
        String resp = myObj.next();        
        DebitAccDAO.updateMinBal(newMinBal, resp);
        printFooter();
        return 1;
    }
    
    public static void specificDebitAcc() throws Exception{
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        listAccounts();
        System.out.print(" \t" + debitCRUD.getObject("enterAccNo") + " " + debitCRUD.getObject("speciAccPrefix") + " :: ");
        int accNo = myObj.nextInt();
        if (!DebitAccDAO.checkAccNo(accNo)){
            return;
        }
        System.out.println(debitCRUD.getObject("initDebitOper") + "  ::" + accNo);
        printHeader();
        DebitAcc a = DebitAccDAO.getAccount(accNo);
        System.out.println(" " + debitCRUD.getObject("selectedAcc") + " ::: ");
        System.out.println(a);
        printFooter();
        specificAccOperations(accNo);        
    }      
    
    public static int deposit(int accNo) throws Exception{
        printHeader();
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        String transType = "Deposit";
        System.out.println(debitCRUD.getObject("depSelected"));
        printFooter();
        DebitAcc a = DebitAccDAO.getAccount(accNo);
        System.out.print(" \n\t\t   " + debitCRUD.getObject("amtDep") + "       \t : ");
        double depositAmt = myObj.nextDouble();
        double bal = a.getAccBal() + depositAmt;
        System.out.print(" \n\t\t   " + debitCRUD.getObject("currBal") + "       \t : $" + bal);
        a.setAccBal(bal);
        DebitAccDAO.updateAccBal(a);
        printFooter();
        Trans_CRUD.transacLine(transType, depositAmt, accNo, a.getAccType());
        return 1;
    }
    
    public static int withdrawal(int accNo) throws Exception{
        printHeader();
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        String transType = "Withdrawal";
        System.out.println(debitCRUD.getObject("withSelected"));
        printFooter();
        DebitAcc a = DebitAccDAO.getAccount(accNo);
        System.out.print(" \n\t\t   " + debitCRUD.getObject("amtWith") + "       \t : ");
        double withdrawAmt = myObj.nextDouble();
        if (withdrawAmt > a.getAccBal()){
            System.out.println(" \n\t\t   " + debitCRUD.getObject("insuffAmtWith"));
            return 1;
        }
        double bal = a.getAccBal() - withdrawAmt;
        if (bal <= a.getMinBal()){
            System.out.println(" \n\t\t   " + debitCRUD.getObject("withWarn") + 
                    " \n\t\t    " + debitCRUD.getObject("withWarn2"));
        }
        System.out.print(" \n\t\t   " + debitCRUD.getObject("currBal") + "       \t : $" + bal);
        a.setAccBal(bal);
        DebitAccDAO.updateAccBal(a);
        printFooter();
        Trans_CRUD.transacLine(transType, withdrawAmt, accNo, a.getAccType());
        return 1;
    }
    
    public static int changeAccStatus(int accNo) throws Exception{
        printHeader();
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(debitCRUD.getObject("changeAccStatus"));
        printFooter();
        DebitAcc a = DebitAccDAO.getAccount(accNo);
        DebitAcc.acctStatus types[] = DebitAcc.acctStatus.values();
        for(DebitAcc.acctStatus type: types){
            System.out.println(" \n\t\t        "+type.selection+ ". " + type);
        }
        System.out.print(" \n\t\t         " + debitCRUD.getObject("keyinselection") + " :   ");
        byte accStatusNo = myObj.nextByte();
        a.setAccStatus(accStatusNo);
        DebitAccDAO.updateAccStatus(a);
        printFooter();
        return 1;
    }
    
    public static int setTransNotifLimit(int accNo) throws Exception{
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        printHeader();
        System.out.println(debitCRUD.getObject("setTransNot"));
        printFooter();
        DebitAcc a = DebitAccDAO.getAccount(accNo);
        System.out.print(" \n\t\t         " + debitCRUD.getObject("currLim") + " :   " + a.getTransNotifLimit());
        System.out.print(" \n\t\t         " + debitCRUD.getObject("newLim") + " : ");
        double newLimit = myObj.nextDouble();
        a.setTransNotifLimit(newLimit);
        DebitAccDAO.updateTransLimit(a);
        printFooter();
        return 1;
    }
    
    public static int displayAccTypesOperations() throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t " + debitCRUD.getObject("accType") +" ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");
        
        System.out.println(" \t" + debitCRUD.getObject("optionsAvailable") + " :: ");
        System.out.println(" \n\t\t1 >> " + debitCRUD.getObject("debit"));
        System.out.println(" \n\t\t2 >> " + debitCRUD.getObject("fd"));
        System.out.println(" \n\t\t3 >> " + debitCRUD.getObject("cc"));
        System.out.println(" \n\t\t9 >> " + debitCRUD.getObject("back"));
        System.out.println(" \n\t\t0 >> " + debitCRUD.getObject("exit"));
        printFooter();
        // Create a Scanner object
        System.out.print(debitCRUD.getObject("selection") + "  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
        
    public static int displayDebitMainPage() throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t " + debitCRUD.getObject("debit") +" ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");
        
        System.out.println(" \t" + debitCRUD.getObject("optionsAvailable") + " :: ");
        System.out.println(" \n\t\t1 >> " + debitCRUD.getObject("listAllAcc"));
        System.out.println(" \n\t\t2 >> " + debitCRUD.getObject("updMinBal"));
        System.out.println(" \n\t\t9 >> " + debitCRUD.getObject("back"));
        System.out.println(" \n\t\t0 >> " + debitCRUD.getObject("exit"));
        printFooter();
        // Create a Scanner object
        System.out.print(debitCRUD.getObject("selection") + "  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
        
    public static int displayDebitOperations() throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(" \t" + debitCRUD.getObject("optionsAvailable") + " :: ");
        System.out.println(" \n\t\t1 >> " + debitCRUD.getObject("deposit"));
        System.out.println(" \n\t\t2 >> " + debitCRUD.getObject("withdraw"));
        System.out.println(" \n\t\t3 >> " + debitCRUD.getObject("changeAccStatus"));
        System.out.println(" \n\t\t4 >> " + debitCRUD.getObject("setTransNot") ); 
        System.out.println(" \n\t\t5 >> " + debitCRUD.getObject("viewTransDetails"));
        System.out.println(" \n\t\t9 >> " + debitCRUD.getObject("back"));
        System.out.println(" \n\t\t0 >> " + debitCRUD.getObject("exit"));
        printFooter();
        // Create a Scanner object
        System.out.print(debitCRUD.getObject("selection") + "  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
    
    public static void selectAccType() throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(debitCRUD.getObject("accOperations"));
        int mainOption = displayAccTypesOperations();
        printHeader();
        System.out.print("\t\t " + debitCRUD.getObject("optionselected") + " : \t\t");
                    
        switch (mainOption) {

            case 1:
                System.out.println(debitCRUD.getObject("debit") + " ::: ");
                printFooter();
                selectDebitAccOperations();
                break;
            case 2:
                System.out.println(debitCRUD.getObject("fd") + " ::: ");   
                printFooter();
                break;  
            case 3:
                System.out.println(debitCRUD.getObject("cc") + " ::: ");
                printFooter();                
                break;
            case 9:
                System.out.println(debitCRUD.getObject("back") + " ::: ");
                Account_CRUD.acctOperations();
                break;                 
            case 0:
                System.out.println(debitCRUD.getObject("exit"));
                printFooter();
                Thread.sleep(2000);
                System.exit(0);
                break;
            default:
                //printHeader();
                System.out.println(" \n\n \t\t #### " + debitCRUD.getObject("invalid") + " ####");
                printFooter();
                Thread.sleep(2000);
                break;
        }
    }
    
    public static void selectDebitAccOperations() throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(debitCRUD.getObject("debit"));
        int mainOption = displayDebitMainPage();
        printHeader();
        System.out.print("\t\t " + debitCRUD.getObject("optionselected") + " : \t\t");
                    
        switch (mainOption) {

            case 1:
                System.out.println(debitCRUD.getObject("listAllAcc") + " ::: ");
                printFooter();
                specificDebitAcc();                
                break;
            case 2:
                System.out.println(debitCRUD.getObject("updMinBal") + " ::: ");
                updateMinBal();
                break;  
            case 9:
                System.out.println(debitCRUD.getObject("back") + " ::: ");
                selectAccType();
                break;     
            case 0:
                System.out.println(debitCRUD.getObject("exit"));
                printFooter();
                Thread.sleep(2000);
                System.exit(0);
                break;
            default:
                //printHeader();
                System.out.println(" \n\n \t\t #### " + debitCRUD.getObject("invalid") + " ####");
                printFooter();
                Thread.sleep(2000);
                break;
        }
    }
    
    public static void specificAccOperations(int accNo) throws Exception {
        debitCRUD = LocaleEx.inputLang(MainPage.currentLanguage);
        System.out.println(debitCRUD.getObject("debit") + " : " + accNo + " " + debitCRUD.getObject("ops"));
        int mainOption = displayDebitOperations();
        printHeader();
        System.out.print("\t\t " + debitCRUD.getObject("optionselected") + " : \t\t");
                    
        switch (mainOption) {

            case 1:
                System.out.println(debitCRUD.getObject("deposit") + " ::: ");
                printFooter();
                deposit(accNo);
                Thread.sleep(1000);
                specificAccOperations(accNo);
                break;
            case 2:
                System.out.println(debitCRUD.getObject("withdraw") + " ::: ");
                printFooter();
                withdrawal(accNo);
                Thread.sleep(1000);
                specificAccOperations(accNo);
                break;  
            case 3:
                System.out.println(debitCRUD.getObject("changeAccStatus") + " ::: ");
                printFooter();
                changeAccStatus(accNo);
                Thread.sleep(1000);
                specificAccOperations(accNo);
                break;
            case 4:
                System.out.println(debitCRUD.getObject("setTransNot") + " ::: ");
                printFooter();
                setTransNotifLimit(accNo);
                Thread.sleep(1000);
                specificAccOperations(accNo);
                break;
            case 5:
                System.out.println(debitCRUD.getObject("viewTransDetails") + " ::: ");
                Trans_CRUD.listAccounts(accNo);
                printFooter();
                Thread.sleep(1000);
                specificAccOperations(accNo);
                break;
            case 9:
                System.out.println(debitCRUD.getObject("back") + " ::: ");
                printFooter();
                selectDebitAccOperations();
                break; 
            case 0:
                System.out.println(debitCRUD.getObject("exit"));
                printFooter();
                Thread.sleep(2000);
                System.exit(0);
                break;
            default:
                //printHeader();
                System.out.println(" \n\n \t\t #### " + debitCRUD.getObject("invalid") + " ####");
                printFooter();
                Thread.sleep(2000);
                break;
        }
    }
    
    
}
