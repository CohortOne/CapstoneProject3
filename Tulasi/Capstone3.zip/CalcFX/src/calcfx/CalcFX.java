/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calcfx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author ltula
 */
public class CalcFX extends Application {
    
    
   public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws Exception {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("CalcFXML.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root);

        stage.setTitle(" Calculator ");
        stage.setScene(scene);
        stage.show();
    }
    

}
    
