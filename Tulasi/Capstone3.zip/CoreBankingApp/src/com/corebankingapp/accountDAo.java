/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ltula
 */
public class accountDAo {
    
    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/corebankingapp?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
     public static boolean insertAccount(account a) throws Exception{
        Statement stmt = CustomerDAO.init();        
        String insStmt = "insert into coreBankingApp.account(AccType, AccNo, AccBal, MinBal, AccStatus, TransNolimit,LastUpdateDateTime,custUIN)"
                + " values (\""+ a.getAccType()+ "\","
                   + a.getAccNo()+","
                   + a.getAccBal()+ ","
                   + a.getMinBal()+ "," 
                  + a.getAccStatus() + ","
                 + a.getTransNolimit() +"," 
                 +"DATE(\""+ a.getLastUpdateDateTime().toString() + "\"),"
                  + a.getCustUIN()+");";
        System.out.println(insStmt);
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }  
     
       public static List <account> listAccountdetails() throws Exception{
        Statement stmt = accountDAo.init();
        List <account> AcctList = new ArrayList<>();
        String qStmt = "Select * from coreBankingApp.account;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            AcctList.add(new account(rs.getString("AccType"),rs.getInt("AccNo"),
                                     rs.getDouble("AccBAl"),rs.getDouble("MinBal"),rs.getByte("AccStatus"),
                                     rs.getDouble("TransNolimit"),rs.getDate("LastUpdateDateTime").toLocalDate(),rs.getInt("custUIN")));
        }
        return AcctList;
    } 
       
    public static boolean delAccount(int UIN)  throws Exception {
       
       Statement stmt = accountDAo.init(); 
       String delStmt = "delete from coreBankingApp.account where custUIN = " + UIN + ";";
       
       int result = stmt.executeUpdate(delStmt);
       if(result > 0){
           
           System.out.println("Delete Sucess");
          
       }else {
           System.out.println("Delete Fail");
       }
       return true;
   } 
    
    public static account getAccount(int AccNo) throws Exception{
        Statement stmt = accountDAo.init();
        account Acct = null;
        String qStmt = "Select * from coreBankingApp.account where AccNo = " + AccNo + ";";
        
        System.out.println(qStmt);
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
           Acct = new account(rs.getString("AccType"),rs.getInt("AccNo"),
                                     rs.getDouble("AccBAl"),rs.getDouble("MinBal"),rs.getByte("AccStatus"),
                                     rs.getDouble("TransNolimit"),rs.getDate("LastUpdateDateTime").toLocalDate(),rs.getInt("custUIN"));
        }
        return Acct;
    }
  
    
     public static boolean updateAccount(account a) throws Exception {
        Statement stmt = accountDAo.init();
        String updStmt = "Update coreBankingApp.account set AccBal = '" + a.getAccBal() + "' where AccNo = " + a.getAccNo() + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
}
