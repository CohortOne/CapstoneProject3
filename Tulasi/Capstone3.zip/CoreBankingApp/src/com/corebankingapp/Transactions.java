/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

import com.mysql.cj.util.StringUtils;
import java.time.LocalDate;

/**
 *
 * @author ltula
 */
public class Transactions {
    
    private String AccType;
    private int AccNo;
    private double TranReferenceID;
    private String TransType;
    private String TrnsDesc;
    private  LocalDate CreationDateTime;
    private double Amount;

    public Transactions(String AccType, int AccNo, double TranReferenceID, String TransType, String TrnsDesc, LocalDate CreationDateTime, double Amount) {
        this.AccType = AccType;
        this.AccNo = AccNo;
        this.TranReferenceID = TranReferenceID;
        this.TransType = TransType;
        this.TrnsDesc = TrnsDesc;
        this.CreationDateTime = CreationDateTime;
        this.Amount = Amount;
    }

    public double getAmount() {
        return Amount;
    }

    public void setAmount(double Amount) {
        this.Amount = Amount;
    }

    

    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }

    public int getAccNo() {
        return AccNo;
    }

    public void setAccNo(int AccNo) {
        this.AccNo = AccNo;
    }

    public double getTranReferenceID() {
        return TranReferenceID;
    }

    public void setTranReferenceID(double TranReferenceID) {
        this.TranReferenceID = TranReferenceID;
    }

    public String getTransType() {
        return TransType;
    }

    public void setTransType(String TransType) {
        this.TransType = TransType;
    }

    public String getTrnsDesc() {
        return TrnsDesc;
    }

    public void setTrnsDesc(String TrnsDesc) {
        this.TrnsDesc = TrnsDesc;
    }

    public LocalDate getCreationDateTime() {
        return CreationDateTime;
    }

    public void setCreationDateTime(LocalDate CreationDateTime) {
        this.CreationDateTime = CreationDateTime;
    }
 public void deposit(double amount){
        
        double newbalance = Amount + amount;
        Amount = newbalance;
    }
   
    //withdraw amount
   public void withdraw(double amount) {
       
       double newbalance = Amount - amount;
        Amount = newbalance;
   }
   
    
    @Override
    public String toString() {
       // return "Transactions{" + "AccType=" + AccType + ", AccNo=" + AccNo + ", TranReferenceID=" + TranReferenceID + ", TransType=" + TransType + ", TrnsDesc=" + TrnsDesc + ", CreationDateTime=" + CreationDateTime + '}';
        return StringUtils.padString(AccType,16) +
               StringUtils.padString(String.valueOf(AccNo),10) +
               StringUtils.padString(String.valueOf(TranReferenceID),15) +
               StringUtils.padString(TransType,16) + 
               StringUtils.padString(TrnsDesc,46) +   
               StringUtils.padString(String.valueOf(CreationDateTime),20) +
               StringUtils.padString(String.valueOf(Amount),20) ;
    }
    
    
    
}
