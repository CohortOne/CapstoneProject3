/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

import com.mysql.cj.util.StringUtils;
import java.time.LocalDate;

/**
 *
 * @author ltula
 */
public class account {
    
    private String AccType;
    private int AccNo;
    private double AccBal;
    private double MinBal;
    private Byte AccStatus;
    private double TransNolimit;
    private LocalDate LastUpdateDateTime;
    private int custUIN;

    public account(String AccType, int AccNo, double AccBal, double MinBal, Byte AccStatus, double TransNolimit, LocalDate LastUpdateDateTime, int custUIN) {
        this.AccType = AccType;
        this.AccNo = AccNo;
        this.AccBal = AccBal;
        this.MinBal = MinBal;
        this.AccStatus = AccStatus;
        this.TransNolimit = TransNolimit;
        this.LastUpdateDateTime = LastUpdateDateTime;
        this.custUIN = custUIN;
    }

    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }

    public int getAccNo() {
        return AccNo;
    }

    public void setAccNo(int AccNo) {
        this.AccNo = AccNo;
    }

    public double getAccBal() {
        return AccBal;
    }

    public void setAccBal(double AccBal) {
        this.AccBal = AccBal;
    }

    public double getMinBal() {
        return MinBal;
    }

    public void setMinBal(double MinBal) {
        this.MinBal = MinBal;
    }

    public Byte getAccStatus() {
        return AccStatus;
    }

    public void setAccStatus(Byte AccStatus) {
        this.AccStatus = AccStatus;
    }

    public double getTransNolimit() {
        return TransNolimit;
    }

    public void setTransNolimit(double TransNolimit) {
        this.TransNolimit = TransNolimit;
    }

    public LocalDate getLastUpdateDateTime() {
        return LastUpdateDateTime;
    }

    public void setLastUpdateDateTime(LocalDate LastUpdateDateTime) {
        this.LastUpdateDateTime = LastUpdateDateTime;
    }

    public int getCustUIN() {
        return custUIN;
    }

    public void setCustUIN(int custUIN) {
        this.custUIN = custUIN;
    }

    @Override
    public String toString() {
        //return "account{" + "AccType=" + AccType + ", AccNo=" + AccNo + ", AccBal=" + AccBal + ", MinBal=" + MinBal + ", AccStatus=" + AccStatus + ", TransNolimit=" + TransNolimit + ", LastUpdateDateTime=" + LastUpdateDateTime + ", custUIN=" + custUIN + '}';
         return   StringUtils.padString(AccType,16) +
                  StringUtils.padString(String.valueOf(AccNo),10) +
                  StringUtils.padString(String.valueOf(AccBal),15) + 
                  StringUtils.padString(String.valueOf(MinBal),10) +
                  StringUtils.padString(String.valueOf(AccStatus==1 ? "Active" : "Dormant"),15) +
                  StringUtils.padString(String.valueOf(TransNolimit),15) +
                  //StringUtils.padString((custStatus==1 ? "True" : "False"),7) +
                  //custStatus +
                  StringUtils.padString(String.valueOf(LastUpdateDateTime),25) + 
                  StringUtils.padString(String.valueOf(custUIN),6) ;
        
    }

}
