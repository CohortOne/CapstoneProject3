/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

import static com.corebankingapp.Main.myObj;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class Customer_CRUD {

    public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }

    public static String printPretty() {
        String s = "\n  |";
        for (int i = 0; i <= iteration; i++) {
            s += "---";
        }

        return s + " >> ";
    }
    
    public static int insCustomer() throws Exception {
        LogUtil.doInfoLog(" inside Insert Customer Method ");

        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        int nxtID = CustomerDAO.getNextID();
        System.out.println(nxtID);
        System.out.println(" \tEnter the following details  :: ");
        printFooter();
        System.out.println(" \n\t\t        Customer UIN    \t : " + nxtID);
        int UIN = nxtID;
        System.out.print(" \n\t\t     Customer Name      \t : ");
        String name = myObj.next();
        System.out.print(" \n\t\t        Customer Address  \t : ");
        String Address = myObj.next();
        System.out.print(" \n\t\t       Customer Contact No       \t : ");
        int ContactNo = myObj.nextInt();
        System.out.print(" \n\t\t        Customer Email    \t : ");
        String Email = myObj.next();
        System.out.print(" \n\t\t        Customer Residential Status     \t : ");
        String ResidentialStatus = myObj.next();
        System.out.print(" \n\t\t        LastUpdateDateTime  \t : ");
        String LastUpdateDateTime = myObj.next();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse(LastUpdateDateTime, sourceFormatter);
        System.out.print(" \n\t\t        CreationDateTimee  \t : ");
        String CreationDateTime = myObj.next();

        if (ResidentialStatus.equals("Citizen") || ResidentialStatus.equals("PR") || ResidentialStatus.equals("Foreigner")) {
            printHeader();
            if (CustomerDAO.insertCustomer(new Customer(UIN, name, Address, ContactNo, Email, ResidentialStatus, 1,
                    LocalDate.parse(LastUpdateDateTime, DateTimeFormatter.ISO_DATE), LocalDate.parse(CreationDateTime, DateTimeFormatter.ISO_DATE)))) {
                printFooter();
                LogUtil.doInfoLog(" About to insert customer with the following details ");
                LogUtil.doInfoLog(new Customer(UIN, name, Address, ContactNo, Email, ResidentialStatus, 1,
                        LocalDate.parse(LastUpdateDateTime, DateTimeFormatter.ISO_DATE), LocalDate.parse(CreationDateTime, DateTimeFormatter.ISO_DATE)).toString());
            }

        } else {

            System.out.println("Invalid Residential Status");
        }
        LogUtil.doInfoLog(" End of Method  ");
        return 1;
    }


    public static int delCustomers() throws Exception {       
        System.out.print(" \t Enter The Customer UIN to Delete :: ");
        int uin = myObj.nextInt();
        System.out.print(" \t Are you sure [y/n][Y/N]:: ");
          String resp = myObj.next();
          if (resp.equalsIgnoreCase("Y")) {
              System.out.println("Initiationg delete for Customer UIN ::" + uin);
               CustomerDAO.delCustomer(uin);             
          }
          return 1;
     
    }
    
    public static int listCustomers() throws Exception {
        
        printHeader();
        //System.out.println("\tUIN   \tName \t\tAddress  \t\tContactNo \t\t Email  \t\t ResidentialStatus \tStatus \tLastUpdateDateTime \tCreationDateTime");
        System.out.println("UIN  Name                                          Address                                       "
                + "Email                                         Contact  ResStatus  Status LastUpdateDateTime CreationDateTime");
        printFooter();
       CustomerDAO.listCustomer().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int updateCustomers() throws Exception{
        listCustomers();
        System.out.print(" \tEnter the Customer UIN to Update :: ");
        int uin = myObj.nextInt();
        System.out.print(" \t You can only update Email and PhoneNo [Y/N][y/n]:: ");
        String resp = myObj.next();
      if(resp.equalsIgnoreCase("y")) {
          System.out.println("\" Initiating update for Customer UIN ::" + uin );
          printHeader();
          Customer c = CustomerDAO.getCustomer(uin);
          System.out.println(" Select Customer ::: ");
            System.out.print(c);
            printFooter();
          System.out.println(" \n\t\t   Current Email   \t : " + c.getCustEmail());
            System.out.print(" \n\t\t   New Email       \t : ");
            c.setCustEmail(myObj.next());
            System.out.println(" \n\t\t    Current Phone    \t : " + c.getCustContactNo());
            System.out.print(" \n\t\t    New  Phone          \t : ");
            c.setCustContactNo(myObj.nextInt());
            CustomerDAO.updateCustomer(c);
            printFooter();  
            
      }
       return 1;
    }
     public static int listCustomersByResStatus() throws Exception {
        printHeader();    
         System.out.println("UIN  Name                                          Address                                       "
                + "Email                                         Contact  ResStatus  Status LastUpdateDateTime CreationDateTime");
        printFooter();
        CustomerDAO.listCustomerOrderByResStatus().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
     public static int DisplayOptions() throws Exception {
        System.out.print("Enter the Language [en/hi] ::"); 
        String language = myObj.next();
        System.out.print("Enter the counry [US/IN]::"); 
        String country  = myObj.next();
         Locale locale = new Locale(language, country);
        
        ResourceBundle msgs = ResourceBundle.getBundle("Resources.Msg_Resources", locale);
        System.out.println(locale);
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
         System.out.println("\n **************************************************************************************************************** ");
         //System.out.println("\n\t Customer CRUD Operations:::");
         System.out.println("\n\t "+( msgs.getObject("Msg"))+":::");
         System.out.println(" \t----------------------------------");
         System.out.println("\n **************************************************************************************************************** ");

         System.out.println(" \t  " +( msgs.getObject("Msg0"))+":::");
         //System.out.println(" \n\t\t1 >> Insert Customer");
         System.out.println("  \n\t\t1  >> "  +( msgs.getObject("Msg1")));         
         //System.out.println(" \n\t\t2 >> update Customer");
         System.out.println(" \n\t\t2 >> " +( msgs.getObject("Msg4")));
         //System.out.println(" \n\t\t3 >> Delete Customer");
         System.out.println(" \n\t\t3 >> " +( msgs.getObject("Msg2")));
         //System.out.println(" \n\t\t4 >> List Customer ");
         System.out.println(" \n\t\t4 >> " +( msgs.getObject("Msg3")));
         //System.out.println(" \n\t\t5 >>Find Customer by Residential Status");
         System.out.println(" \n\t\t5 >> " +( msgs.getObject("Msg5")));
//         System.out.println(" \n\t\t6 >> Insert Account details ");
           System.out.println("  \n\t\t6 >> " +( msgs.getObject("Msg6")));

         // System.out.println(" \n\t\t7 >> List Account details ");
         System.out.println(" \n\t\t7 >> " +( msgs.getObject("Msg7")));
         //System.out.println(" \n\t\t8 >> Delete Account");
         System.out.println(" \n\t\t8 >>" +( msgs.getObject("Msg8")));
         //System.out.println(" \n\t\t9 >> Update Account Record");
         System.out.println(" \n\t\t9 >> " +( msgs.getObject("Msg9")));
         //System.out.println(" \n\t\t10 >> Trnsaction Types");
         System.out.println(" \n\t\t10 >> " +( msgs.getObject("Msg11")));
//          System.out.println(" \n\t\t11 >> AccountUpadated");
//           System.out.println(" \n\t\t12 >> Calculate Interest");
//        System.out.println(" \n\t\t7 >> List Customers Order By Name ");
        // System.out.println(" \n\t\t0 >> Exit");
          System.out.println("  \n\t\t0 >>" +( msgs.getObject("Msg0")));


        System.out.println("\n ******************************************************************************************************************* ");
        // Create a Scanner object
        //System.out.print(" Enter a number to carry out the operation  :   ");
          System.out.println(( msgs.getObject("Msg12"))+"  :   " );
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }
      public static void printHeader() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" ================================================================================================================================================================================================================");

    }

    public static void printFooter() {
        System.out.println(" ==================================================================================================================================================================================================================");
    }
  
    
        
   
  
}