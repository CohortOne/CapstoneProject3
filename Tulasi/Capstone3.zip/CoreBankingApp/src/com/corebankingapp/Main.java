/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;


import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 *
 * @author ltula
 */
public class Main {

    public static Scanner myObj = new Scanner(System.in);
    public static Locale locale;
    public static ResourceBundle msgs;

    public static void main(String[] args) throws Exception {
        //Logger logger = Logger.getLogger(Customer.class.getName());
        Customer_CRUD CC = new Customer_CRUD();
        account_CRUD AC = new account_CRUD();
        Transaction_CRUD TC = new Transaction_CRUD();
        String language = args[0];
        String country = args[1];
        myObj.useDelimiter("\n");

        locale = new Locale(language, country);

        msgs = ResourceBundle.getBundle("Resources.Msg_Resources", locale);
        System.out.println(locale);

        try {

            while (true) {
                int optionVal = CC.DisplayOptions();

                CC.printHeader();
                System.out.print("\t\t Option Selected : \t\t" + optionVal);
//                Handler fileHandler = new FileHandler("C:\\Capstone3\\CoreBankingApp\\logs\\logger.log", 200000, 1);
//                fileHandler.setFormatter(new SimpleFormatter());
//
//                //setting custom filter for FileHandler
//                logger.addHandler(fileHandler);
//
//                for (int i = 0; i < 10; i++) {
//                    //logging messages
//                    logger.log(Level.INFO, "Msg" + i);
//                }
//                for (int i = 0; i < 10; i++) {
//                    //logging messages
//                    logger.log(Level.SEVERE, "Msg" + i);
//                }
//                logger.log(Level.CONFIG, "Config data");

                switch (optionVal) {

                    case 1:
                        //System.out.println("Insert Customer  ");
                        System.out.println(msgs.getObject("Msg1"));
                        CC.printFooter();
                        LogUtil.doInfoLog(" Start of the Application ");
                        CC.insCustomer();
                        LogUtil.doInfoLog(" End of the Application ");
                        break;
                    case 3:
                        // System.out.println("Delete Customer ::: ");
                        System.out.println(msgs.getObject("Msg2"));
                        CC.delCustomers();
                        break;
                    case 4:
                        //System.out.println("List Customers ::: ");
                        System.out.println(msgs.getObject("Msg3"));
                        CC.listCustomers();
                        break;
                    case 2:
                        // System.out.println("Update Customer :::");
                        System.out.println(msgs.getObject("Msg4"));
                        CC.updateCustomers();
                        break;
                    case 5:

                        //System.out.println("Find Customer by Residential Status ::");
                        System.out.println(msgs.getObject("Msg5"));
                        CC.listCustomersByResStatus();
                        break;
                    case 6:
                        //System.out.println("Insert Account details :: ");
                        System.out.println(msgs.getObject("Msg6"));
                        LogUtil.doInfoLog(" Start of the Application ");
                        AC.insAccount();
                         LogUtil.doInfoLog(" End of the Application ");
                        break;
                    case 7:
                        //System.out.println("List Account detais :: ");
                        System.out.println(msgs.getObject("Msg7"));
                        AC.listAccount();
                        break;

                    case 8:
                        // System.out.println("Delete Account ");
                        System.out.println(msgs.getObject("Msg8"));
                        AC.delAccount();
                        break;
                    case 9:
                        //System.out.println("Update Account Record ");
                        System.out.println(msgs.getObject("Msg8"));
                        AC.updateAccount();
                        break;
                       
                    case 10:
                        // System.out.println("Transaction Types" );
                        System.out.println(msgs.getObject("Msg11"));
                        int optionVal1 = TC.transactionMenu();
                        System.out.print("\t\t Option Selected : \t\t" + optionVal1);
                        switch (optionVal1) {

                            case 11:
                                System.out.println("Deposit Money  ");
                                TC.Deposit();
                                break;
                            case 12:
                                System.out.println("Withdrawl ::: ");
                                TC.Withdrwal();
                                break;
                            case 13: 
                                System.out.println("CheckBalance :");
                               AC.checkbalance(); 
                              break;
                        }

                        break;

                    case 0:
                        System.out.println(msgs.getObject("Msg10"));
                        CC.printFooter();
                        Thread.sleep(4000);
                        System.exit(0);
                        break;
                    default:
                        //printHeader();
                        System.out.println(" \n\n \t\t #### Invalid Option ####");
                        CC.printFooter();
                        Thread.sleep(4000);
                        break;
                }
                CC.printFooter();
                System.out.print(" Press any key to continue.....");
                CC.toContinue();

            }
        } catch (SecurityException | IOException e) {
            e.printStackTrace();

        }
    }
}
