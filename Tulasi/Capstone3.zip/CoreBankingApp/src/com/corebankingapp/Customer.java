/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;


import com.mysql.cj.util.StringUtils;
import java.time.LocalDate;

/**
 *
 * @author ltula
 */
public class Customer {

    private int custUIN;
    private String custName;
    private String custAddress;
    private int custContactNo;
    private String custEmail;
    private String custResidentialStatus;
    private int custStatus;
    private  LocalDate LastUpdateDateTime;
    private LocalDate CreationDateTime;


    public Customer(int custUIN, String custName, String custAddress, int custContactNo, String custEmail, String custResidentialStatus, int custStatus, LocalDate LastUpdateDateTime, LocalDate CreationDateTime) {
        this.custUIN = custUIN;
        this.custName = custName;
        this.custAddress = custAddress;
        this.custContactNo = custContactNo;
        this.custEmail = custEmail;
        this.custResidentialStatus = custResidentialStatus;
        this.custStatus = custStatus;
        this.LastUpdateDateTime = LastUpdateDateTime;
        this.CreationDateTime = CreationDateTime;
    }

    public int getCustUIN() {
        return custUIN;
    }

    public void setCustUIN(int custUIN) {
        this.custUIN = custUIN;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustAddress() {
        return custAddress;
    }

    public void setCustAddress(String custAddress) {
        this.custAddress = custAddress;
    }

    public int getCustContactNo() {
        return custContactNo;
    }

    public void setCustContactNo(int custContactNo) {
        this.custContactNo = custContactNo;
    }

    public String getCustEmail() {
        return custEmail;
    }

    public void setCustEmail(String custEmail) {
        this.custEmail = custEmail;
    }

    public String getCustResidentialStatus() {
        return custResidentialStatus;
    }

    public void setCustResidentialStatus(String custResidentialStatus) {
        this.custResidentialStatus = custResidentialStatus;
    }

    public int getCustStatus() {
        return custStatus;
    }

    public void setCustStatus(byte custStatus) {
        this.custStatus = custStatus;
    }

    public LocalDate getLastUpdateDateTime() {
        return LastUpdateDateTime;
    }

    public void setLastUpdateDateTime(LocalDate LastUpdateDateTime) {
        this.LastUpdateDateTime = LastUpdateDateTime;
    }

    public LocalDate getCreationDateTime() {
        return CreationDateTime;
    }

    public void setCreationDateTime(LocalDate CreationDateTime) {
        this.CreationDateTime = CreationDateTime;
    }

    @Override
    public String toString() {
        
         // return "\t" + custUIN + "\t " + custName + "\t\t" + custAddress + "\t" + custEmail  + " \t " + custContactNo + " \t" + custResidentialStatus + "\t " + (custStatus==1 ? true : false) + "\t" + LastUpdateDateTime + "\t" + CreationDateTime ;
          return StringUtils.padString(String.valueOf(custUIN),5) +
                  StringUtils.padString(custName,46) +
                  StringUtils.padString(custAddress,46) + 
                  StringUtils.padString(custEmail,46) +
                  StringUtils.padString(String.valueOf(custContactNo),9) +
                  StringUtils.padString(custResidentialStatus,11) +
                  StringUtils.padString((custStatus==1 ? "True" : "False"),7) +
                  //custStatus +
                  StringUtils.padString(String.valueOf(LastUpdateDateTime),20) + 
                  StringUtils.padString(String.valueOf(CreationDateTime),20) ;
        
    }

   
    
    
  
    
}
