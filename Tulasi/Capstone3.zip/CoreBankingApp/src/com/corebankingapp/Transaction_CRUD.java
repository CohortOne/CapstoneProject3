/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;


import static com.corebankingapp.account_CRUD.myObj;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author ltula
 */
public class Transaction_CRUD {
    public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }

    public static String printPretty() {
        String s = "\n  |";
        for (int i = 0; i <= iteration; i++) {
            s += "---";
        }

        return s + " >> ";
    } 
    
    
     public static int transactionMenu() throws Exception {
         
         new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
         System.out.println("\n **************************************************************************************************************** ");
         System.out.println("\n\t Transction Methods:::");
         System.out.println(" \t----------------------------------");
         System.out.println("\n **************************************************************************************************************** ");
         System.out.println(" \t Following are the options:::");
         System.out.println(" \n\t\t11 >> Deposit");
         System.out.println(" \n\t\t12 >> Withdrawl");
         System.out.println(" \n\t\t13 >> checkbalance");
           System.out.println(" \n\t\t0 >> Exit");
         System.out.println("\n ******************************************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" Enter a numer to carry out the operation  :   ");
        int optValue;
        try {
            optValue = myObj.nextInt();
        } catch (Exception e) {

            optValue = -1;
        }
        return optValue;
    }
     
     
     
    public static int Deposit()throws Exception {
        
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
       int nxtID = TransactionDAO.getNextTRID();
        System.out.println(nxtID);
        System.out.println(" \tEnter the following details  :: ");
        Customer_CRUD.printFooter();        
        System.out.print(" \n\t\t        AccType     \t : ");
        String AccType = myObj.next();
        System.out.print(" \n\t\t        AccountNo  \t : ");
        int AccNo = myObj.nextInt();
        System.out.print(" \n\t\t      TranReferenceID      \t : " + nxtID );
        int TransRID = nxtID;
        System.out.print(" \n\t\t        TransType    \t : ");
        String TransType = myObj.next();
        System.out.print(" \n\t\t        TransDesc     \t : ");
        String TransDesc = myObj.next();
        System.out.print(" \n\t\t       CreationDateTime \t : ");        
        String  CreationDateTime = myObj.next();
        System.out.print(" \n\t\t       Enter Amount  \t : ");
        int Amount = myObj.nextInt();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse( CreationDateTime, sourceFormatter);
        if (AccType.equals("Current") || AccType.equals("Savings") || AccType.equals("Junior") ) {      
       Customer_CRUD.printHeader();
        if (TransactionDAO.insertTransaction(new Transactions(AccType,AccNo,TransRID, TransType,TransDesc,LocalDate.parse(CreationDateTime, DateTimeFormatter.ISO_DATE),Amount)));
               {
                    Customer_CRUD.printFooter();
        }
        account a = accountDAo.getAccount(AccNo);
        a.setAccBal(a.getAccBal()+Amount);
        accountDAo.updateAccount(a);
        
        } else {
            
            System.out.println("Invalid account type : ");
        }
        return 1;
        
    }
  
    
     public static int Withdrwal()throws Exception {
        
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" \tEnter the following details  :: ");
        Customer_CRUD.printFooter();        
        System.out.print(" \n\t\t        AccType     \t : ");
        String AccType = myObj.next();
        System.out.print(" \n\t\t        AccountNo  \t : ");
        int AccNo = myObj.nextInt();
        System.out.print(" \n\t\t      TranReferenceID      \t : " );
        double TransRID = myObj.nextInt();
        System.out.print(" \n\t\t        TransType    \t : ");
        String TransType = myObj.next();
        System.out.print(" \n\t\t        TransDesc     \t : ");
        String TransDesc = myObj.next();
        System.out.print(" \n\t\t       CreationDateTime \t : ");        
        String  CreationDateTime = myObj.next();
        System.out.print(" \n\t\t       Enter Amount  \t : ");
        int Amount = myObj.nextInt();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse( CreationDateTime, sourceFormatter);
              
       Customer_CRUD.printHeader();
       account a = accountDAo.getAccount(AccNo);
       
       if (a.getAccBal()-Amount >= 0) {

            if (TransactionDAO.withdraw(new Transactions(AccType,AccNo,TransRID, TransType,TransDesc,LocalDate.parse(CreationDateTime, DateTimeFormatter.ISO_DATE),Amount)));
                   {
                        Customer_CRUD.printFooter();
            }
                    a.setAccBal(a.getAccBal()-Amount);
                    accountDAo.updateAccount(a);
        }
        else
        {          
                System.out.print("Insufficient Balance available!");
        }
                
        return 1;
        
    }
    
    
     public static int updateTransAccount() throws Exception{
        Customer_CRUD.insCustomer();
        account_CRUD.listAccount();
        System.out.print(" \tEnter the AccNo to Update :: ");
        int AccNo = myObj.nextInt();
        System.out.print(" \t  You want to update AccType  [Y/N][y/n]:: ");
        String resp = myObj.next();
        if(resp.equalsIgnoreCase("y")) {
        System.out.print("\" Initiating update for Customer AccType ::" + resp );
         account a = accountDAo.getAccount(AccNo);
         Transactions T = TransactionDAO.getTransAccount(AccNo);
         System.out.println(" \n\t\t  old AccType   \t : " + a.getAccType());
         System.out.print(" \n\t\t   New AccType       \t : ");
         a.setAccType(myObj.next());
         System.out.println(" \n\t\t    AccBal    \t : " + a.getAccBal());
         System.out.println("\" \\n\\t\\t    AccBal    \\t : " + T.getAmount());
         
         System.out.print(" \n\t\t    New  AccBal          \t : " + a.getAccBal() + T.getAmount() );
         a.setAccBal(myObj.nextDouble());
         TransactionDAO.updateAccount(T);
    }
        return 1;
  }
      
}
