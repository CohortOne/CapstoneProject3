/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

import static com.corebankingapp.Customer_CRUD.listCustomers;
import static com.corebankingapp.Customer_CRUD.myObj;
import static com.corebankingapp.Customer_CRUD.printFooter;
import static com.corebankingapp.Customer_CRUD.printHeader;
import static com.corebankingapp.Transaction_CRUD.myObj;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class account_CRUD {
   public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }

    public static String printPretty() {
        String s = "\n  |";
        for (int i = 0; i <= iteration; i++) {
            s += "---";
        }

        return s + " >> ";
    } 
    
     public static int insAccount()throws Exception {
        
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        //int nxtID = CustomerDAO.getNextID(); 
        System.out.println(" \tEnter the following details  :: ");
        printFooter();        
        System.out.print(" \n\t\t        AccType     \t : ");
        String AccType = myObj.next();
        System.out.print(" \n\t\t        AccountNo  \t : ");
        int AccNo = myObj.nextInt();
        System.out.print(" \n\t\t       AccountBalance       \t : ");
        double AccBal = myObj.nextInt();
        System.out.print(" \n\t\t        Minimum Balance    \t : ");
        double MinBal = myObj.nextInt();
        System.out.print(" \n\t\t        Account Status     \t : ");
        byte AccStatus = myObj.nextByte();
        System.out.print(" \n\t\t       Transactions limit  \t : ");
        double TransNotlimit = myObj.nextInt();
         System.out.print(" \n\t\t        LastUpdateDateTime  \t : ");
        String LastUpdateDateTime = myObj.next();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse(LastUpdateDateTime, sourceFormatter);
        System.out.println(" \n\t\t        Customer UIN    \t : " );
        int UIN = myObj.nextInt();
      
        System.out.print("AccType is "+AccType);
        
        if (AccType.equals("Current") || AccType.equals("Savings") || AccType.equals("Junior") ) {
                     printHeader();
            if (accountDAo.insertAccount(new account(AccType, AccNo,AccBal,MinBal, AccStatus, TransNotlimit, 
                    LocalDate.parse(LastUpdateDateTime, DateTimeFormatter.ISO_DATE),UIN))) {
                        printFooter();
                    }
        }
        else {
               System.out.print("Invalid Account Type!");
               
        }
        
        return 1;
    }
     
    public static int listAccount() throws Exception {        
        printHeader();       
       System.out.println("AccType         AccNo     AccBal        MinBal       AccStatus     "
               + "TransNolimit    LastUpadateDateTime     UIN       ");                                 
          
      printFooter();
      accountDAo.listAccountdetails().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int delAccount() throws Exception {       
        System.out.print(" \t Enter The Customer UIN to Delete the Account record:: ");
        int UIN = myObj.nextInt();
        System.out.print(" \t Are you sure [y/n][Y/N]:: ");
          String resp = myObj.next();
          if (resp.equalsIgnoreCase("Y")) {
              System.out.println("Initiationg delete for Customer UIN Account ::" + UIN);
               accountDAo.delAccount(UIN);             
          }
          return 1;
     
    }

    
    public static int checkbalance() throws Exception {
        
       System.out.println("Enter account number : " );
       int AccNo = myObj.nextInt();
       account a  = accountDAo.getAccount(AccNo);
        //System.out.print(" \n\t\t        AccType     \t : ");
         String AccType = a.getAccType();
         System.out.println("get Account Balance :  " + a.getAccBal());
         
         if (AccType.equals("Savings") && a.getAccBal() < 100) { 
             System.out.println("Account :" +AccNo +" is having balance of  " + a.getAccBal() + "less than Minimum balance of 100");
             System.out.println("Account :" +AccNo +" will incurr min bal fine of $2");
             
             }
         else if (AccType.equals("Savings") && a.getAccBal() >= 100) {
             System.out.println("Account :" +AccNo +" is has balance of  " + a.getAccBal() + " greater than or equal to minimum balance of 100");
         }
         else {
             System.out.println("Account is not Savings Account to check for Min Balance");
         }
       
      return 1; 
   }
    
    
    public static int updateAccount() throws Exception{
        listCustomers();
        listAccount();
        System.out.print(" \tEnter the Customer Account Number to Update :: ");
        int AccNo = myObj.nextInt();
        //System.out.print(" \tEnter the AccType to Update :: ");
        // String AccType = myObj.next();
//        System.out.print(" \t  You want to update AccType  [Y/N][y/n]:: ");
//        String resp = myObj.next();
//       if(resp.equalsIgnoreCase("y")) {
//       System.out.print("\" Initiating update for Customer Account ::" + resp );
        account a = accountDAo.getAccount(AccNo);
//        System.out.println(" \n\t\t  old AccType   \t : " + a.getAccType());
//        System.out.print(" \n\t\t   New AccType       \t : ");
//        a.setAccType(myObj.next());
        System.out.println(" \n\t\t    AccBal    \t : " + a.getAccBal());
        System.out.print(" \n\t\t    New  AccBal          \t : ");
        a.setAccBal(a.getAccBal()+myObj.nextDouble());
        accountDAo.updateAccount(a);
        return 1;
       }
        
    }
      
  

