/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author ltula
 */
public class TransactionDAO {
     public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/corebankingapp?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
     public static int getNextTRID(){
        int nxtID = 0;
        try{
            Statement stmt = TransactionDAO.init();
            String nxID = "select max(TranReferenceID) from corebankingapp.transactions;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;     
          
        }catch(Exception e){
            System.out.println(" Exception from TransactionDAO :: " + e.getMessage());
            e.printStackTrace();
        }
        return nxtID;
    }
    public static boolean insertTransaction(Transactions T) throws Exception{
        Statement stmt = TransactionDAO.init();        
        String insStmt = "insert into coreBankingApp.transactions(AccType, AccNo, TranReferenceID, TransType, TrnsDesc,CreationDateTime,Amount)"
                + " values (\""+ T.getAccType()+ "\","
                   + T.getAccNo()+","
                   + T.getTranReferenceID()+              
                 ",\"" + T.getTransType()+ "\",\""
                  + T.getTrnsDesc() +  "\"" +          
                 ", DATE(\""+ T.getCreationDateTime().toString() + "\")," + T.getAmount()+ ");";
                  
        System.out.println(insStmt);
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Deposit Success ");
        }else {
            System.out.println(" Deposit Fail ");
        }
        
        return true;
    }  
    
    public static boolean withdraw(
       Transactions T) throws Exception {
   Statement stmt = accountDAo.init();    
   String upStmt =  "UPDATE coreBankingApp.account SET AccBal = AccBal - "
                    + T.getAmount() + " where  AccNo = " + T.getAccNo() + ";";
   
   int result = stmt.executeUpdate(upStmt);
        
        if(result > 0){
            System.out.println(" withdraw Success ");
        }else {
            System.out.println(" withdraw Fail ");
        }
        
        return true;
    }  


    public static Transactions getTransAccount(int AccNo) throws Exception{
        Statement stmt = TransactionDAO.init();
        Transactions Transacc = null;
        
        String qStmt = "Select * from coreBankingApp.transactions where AccNo = " + AccNo + ";";
        
        System.out.println(qStmt);
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
           Transacc = new Transactions(rs.getString("AccType"),rs.getInt("AccNo"),
                                     rs.getDouble("TranReferenceID"),rs.getString("TransType"),
                                   rs.getString("TrnsDesc"),rs.getDate("CreationDateTime").toLocalDate(),rs.getDouble("Amount"));
        }
        return Transacc;
    }
//  
     public static boolean updateAccount(Transactions T) throws Exception {
        Statement stmt = accountDAo.init();
         String updStmt = "Update coreBankingApp.account set AccBal = AccBal + " + T.getAmount() + "' where AccNo = " + T.getAccNo() + ";";
      
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
     
}
