/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.corebankingapp;

//import com.mysql.cj.jdbc.CallableStatement;
import com.mysql.cj.jdbc.CallableStatement;
import com.mysql.cj.util.StringUtils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.util.logging.Logger;
/**
 *
 * @author ltula
 */
public class CustomerDAO {
    
        public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/corebankingapp?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
    
    public static int getNextID(){
        int nxtID = 0;
        try{
            Statement stmt = CustomerDAO.init();
            String nxID = "select max(custUIN) from corebankingapp.customer;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;     
          
        }catch(Exception e){
            System.out.println(" Exception from CustomerDAO :: " + e.getMessage());
            e.printStackTrace();
        }
        return nxtID;
    }
     public static boolean insertCustomer(Customer c) throws Exception{
            Logger logger = Logger.getLogger(Customer.class.getName());
        Statement stmt = CustomerDAO.init();
        
        String insStmt = "insert into coreBankingApp.Customer (custUIN, custName, custAddress, custEmail,custContactNo,custResidentialStatus,custStatus,LastUpdateDateTime,CreationDateTime)"
                + " values(" + c.getCustUIN() + 
                ",\"" + c.getCustName() + "\",\"" + c.getCustAddress() + "\",\""
                 + c.getCustEmail() + "\"," + c.getCustContactNo() + ", \""
                + c.getCustResidentialStatus() + "\"," + c.getCustStatus() + ",DATE(\"" + c.getLastUpdateDateTime().toString()+"\")," + "DATE(\"" + c.getCreationDateTime().toString()+"\")" + ");";
        
        System.out.println(insStmt);
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }    
   public static boolean delCustomer(int UIN)  throws Exception {
          Logger logger = Logger.getLogger(Customer.class.getName());
       Statement stmt = CustomerDAO.init(); 
       String delStmt = "delete from coreBankingApp.Customer where custUIN = " + UIN + ";";
       
       int result = stmt.executeUpdate(delStmt);
       if(result > 0){
           
           System.out.println("Delete Success");
          
       }else {
           System.out.println("Delete Fail");
       }
       return true;
   } 
   public static List <Customer> listCustomer() throws Exception{
          Logger logger = Logger.getLogger(Customer.class.getName());
        Statement stmt = CustomerDAO.init();
        List <Customer> custList = new ArrayList<>();
        String qStmt = "Select * from coreBankingApp.Customer;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            custList.add(new Customer(rs.getInt("custUIN"),rs.getString("custName"),rs.getString("custAddress"),
                                     rs.getInt("custContactNo"),rs.getString("custEmail"),rs.getString("custResidentialStatus"),
                                     rs.getInt("custStatus"),rs.getDate("LastUpdateDateTime").toLocalDate(),rs.getDate("CreationDateTime").toLocalDate()));
        }
        return custList;
    }  
    public static Customer getCustomer(int custUIN) throws Exception{
           Logger logger = Logger.getLogger(Customer.class.getName());
        Statement stmt = CustomerDAO.init();
        Customer cust = null;
        String qStmt = "Select * from coreBankingApp.Customer where custUIN = " + custUIN + ";";
        
        System.out.println(qStmt);
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            cust = new Customer(rs.getInt("custUIN"),rs.getString("custName"),rs.getString("custAddress"),
                               rs.getInt("custContactNo"),rs.getString("custEmail"),rs.getString("custResidentialStatus"),
                              rs.getInt("custStatus"),rs.getDate("LastUpdateDateTime").toLocalDate(),rs.getDate("CreationDateTime").toLocalDate());                             
        }
        return cust;
    }
   
   public static List<Customer> listCustomerOrderByResStatus() throws Exception {
          Logger logger = Logger.getLogger(Customer.class.getName());
     
       Connection conn = CustomerDAO.initConn();
       List <Customer> custList = new ArrayList<>();
       String qStmt = "{Call corebankingapp.GetCustomer()}";
       
       CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
       ResultSet rs = cstmt.executeQuery();
       
       while(rs.next()){           
           Customer c = new Customer(rs.getInt("custUIN"),rs.getString("custName"),rs.getString("custAddress"),
                                     rs.getInt("custContactNo"),rs.getString("custEmail"),rs.getString("custResidentialStatus"),
                                      rs.getInt("custStatus"),rs.getDate("LastUpdateDateTime").toLocalDate(),rs.getDate("CreationDateTime").toLocalDate());
           custList.add(c);
       } 
       return custList;
   
   }
    public static boolean updateCustomer(Customer c) throws Exception{
           Logger logger = Logger.getLogger(Customer.class.getName());
        Statement stmt = CustomerDAO.init();
        String updStmt = "Update coreBankingApp.Customer set custEmail = '" + c.getCustEmail() + "', custContactNo = '" + c.getCustContactNo()+ "' where custUIN = " + c.getCustUIN() + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
   }
    

