/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author keng
 */
public class Transaction {
    
    private String accountNum;
    private String accountType;
    private String transactionID;
    private LocalDateTime transactionDT;
    private char transactionType;
    private double transactionAmt;
    private String transactionDesc;

    public Transaction(String accountNum, String accountType, String transactionID, 
            LocalDateTime transactionDT, char transactionType, double transactionAmt, 
            String transactionDesc) {
        this.accountNum = accountNum;
        this.accountType = accountType;
        this.transactionID = transactionID;
        this.transactionDT = transactionDT;
        this.transactionType = transactionType;
        this.transactionAmt = transactionAmt;
        this.transactionDesc = transactionDesc;
    }

    @Override
    public String toString() {
        return transactionID + "  " + transactionDT + "  \t" + transactionType + "  " 
                + "\t$" + transactionAmt + "\t\t" + transactionDesc;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public LocalDateTime getTransactionDT() {
        return transactionDT;
    }

    public void setTransactionDT(LocalDateTime transactionDT) {
        this.transactionDT = transactionDT;
    }

    public char getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(char transactionType) {
        this.transactionType = transactionType;
    }

    public double getTransactionAmt() {
        return transactionAmt;
    }

    public void setTransactionAmt(double transactionAmt) {
        this.transactionAmt = transactionAmt;
    }

    public String getTransactionDesc() {
        return transactionDesc;
    }

    public void setTransactionDesc(String transactionDesc) {
        this.transactionDesc = transactionDesc;
    }
    
    
    
}
