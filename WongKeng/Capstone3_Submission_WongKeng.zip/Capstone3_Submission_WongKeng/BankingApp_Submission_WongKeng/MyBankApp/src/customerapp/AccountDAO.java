/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author keng
 */
public class AccountDAO {
    
    public static String getCustomerAccountNum(String custID, String acctType) throws Exception{
        //Logging
        LogUtil.doWarnLog("Enter getCustomerAccountNum()");
        
        Statement stmt = CustomerDAO.init();
        
        Account custAcct = null;
        
        String acctNum = null;
        
        //sort records in DB in descending order for required NRIC and Account Type     
        String qStmt = "Select * from MyBank.Account where custNRIC = \"" + custID 
                + "\" and accountType = \"" + acctType + "\"  order by accountNum DESC;";
        
//        System.out.println(qStmt);
        
        ResultSet rs = stmt.executeQuery(qStmt);               
        
//        System.out.println("From getCustomerAccountNum accountType = " + rs.getString("accountType"));
//        System.out.println("AcctType = " + acctType);
        
//        custAcct = new Account(rs.getString("custNRIC"), rs.getString("accountType"), 
//                rs.getString("accountNum"), rs.getString("accountStatus").charAt(0));
        

        //move pointer to first row of rs. True if next record exist.
        
        if(rs.next()) {
          if ((rs.getString("accountType").equalsIgnoreCase(acctType)) || 
                  (rs.getString("accountType") == null)){
              acctNum = rs.getString("accountNum");
          }
        }         
        //Logging
        LogUtil.doWarnLog("Exiting getCustomerAccountNum()");
        
        return acctNum;
    }
    
    public static boolean insertAccount(Account c) throws Exception{
        Statement stmt = CustomerDAO.init();
        
        String insStmt = "insert into MyBank.Account (custNRIC, accountType, accountNum, "
                + "accountStartDate, accountBalance, interestRate, "
                + "withdrawalLimit, accountStatus, belowMinBalanceFee, minBalance) "
                + " values(\"" + c.getCustNRIC() + "\", \"" + c.getAccountType() + "\", \"" +  c.getAccountNum() 
                + "\", \"" + c.getAccountStartDate() + "\", \"" + c.getAccountBalance() + "\", \"" + c.getInterestRate() 
                + "\", \"" + c.getWithdrawalLimit() + "\", \"" + c.getAccountStatus() 
                + "\", \"" + c.getBelowMinBalanceFee() + "\", \"" + c.getMinBalance()
                + "\");";
                
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }
    
    public static boolean AccountTransactions (String nric, String accountType, 
            double amount, char transactionType) throws Exception {
        
        String transactionDesc = null;

        LocalDateTime transactionDT = LocalDateTime.now();
        
        //get customer account number
        String accountNum = getCustomerAccountNum(nric, accountType);
        
        if (accountNum != null) {
            switch (transactionType) {
            case 'D':
                transactionDesc = "Deposit transaction of $" + amount + " on "
                        + transactionDT;
                break;
            case 'W':
                transactionDesc = "Withdrawal transaction of $" + amount + " on "
                        + transactionDT;
                amount = (-1.0) * amount;
                break;
            case 'T':
                transactionDesc = "Remit transaction of $" + amount + " on "
                        + transactionDT;
                amount = (-1.0) * amount;
                break;
            default:
                transactionDesc = "Unknown transaction";
                
            }
            
            String transactionID = accountNum + transactionDT;
            
            Statement stmt = CustomerDAO.init();
        
            String insStmt = "insert into MyBank.Transaction (accountType, accountNum, "
                    + "transactionID, transactionDT, transactionType, "
                    + "transactionAmt, transactionDesc) "
                    + " values(\"" + accountType + "\", \"" + accountNum + "\", \"" +  transactionID 
                    + "\", \"" + transactionDT + "\", \"" + transactionType + "\", \"" + amount 
                    + "\", \"" + transactionDesc
                    + "\");";

            int result = stmt.executeUpdate(insStmt);

            if(result > 0){
                System.out.println(" Insert Success ");
            }else {
                System.out.println(" Insert Fail ");
            }
            
        }
        
        return true;
    }
    
    public static List <Transaction> DisplayBalanceSummary (String nric, String accountType) throws Exception {
        
        List <Transaction> transactionList = new ArrayList<>();
        
        
        //get required account number
        String selectedAccountNum = getCustomerAccountNum(nric, accountType);
        
        Statement stmt = CustomerDAO.init();
        
        String qStmt = "Select * from MyBank.Transaction where accountNum = \"" + selectedAccountNum
            + "\" and accountType = \"" + accountType + "\"" + "order by transactionDT;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        
        while(rs.next()){
            
            transactionList.add(new Transaction (rs.getString("accountNum"),
                    rs.getString("accountType"), rs.getString("transactionID"),                     
                    rs.getObject("transactionDT", LocalDateTime.class),
                    rs.getString("transactionType").charAt(0), 
                    rs.getDouble("transactionAmt"), 
                    rs.getString("transactionDesc")));
                 
        }
        return transactionList;
        
    }
    
    public static List <String> GetAllAccounts (String nric) throws Exception {
        
        List <String> requiredAccountList = new ArrayList<>();
                
        Statement stmt = CustomerDAO.init();
                
        String qStmt = "Select * from MyBank.Account where custNRIC = \"" 
                    + nric + "\";";
        
        System.out.println("GetAllAccounts : " + qStmt);
        
        ResultSet rs = stmt.executeQuery(qStmt);
        
        while(rs.next()){            
            requiredAccountList.add(new String (rs.getString("accountType")));
        }
        
        return requiredAccountList;
    }
    
    public static Account GetAccountDetails(String nric, String accountType) throws Exception {
                        
        Account requiredAccountDetails = null;
        
        Statement stmt = CustomerDAO.init();
                
        String qStmt = "Select * from MyBank.Account where custNRIC = \"" + nric
                + "\" and accountType = \"" + accountType + "\";";
                
//        System.out.println(qStmt);
        
        ResultSet rs = stmt.executeQuery(qStmt);
        
        if (rs.next()) {
            requiredAccountDetails = new Account (rs.getString("custNRIC"),
                    rs.getString("accountType"), rs.getString("accountNum"),
                    rs.getDouble("accountBalance"), rs.getDouble("withdrawalLimit"),
                    rs.getString("accountStatus").charAt(0),
                    rs.getDouble("interestRate"), rs.getDouble("minBalance"),
                    rs.getDouble("belowMinBalanceFee"));
        }        
                            
        return requiredAccountDetails;
    }
    
    public static boolean UpdateAccount(Account c) throws Exception{
                        
        Statement stmt = CustomerDAO.init();
        String updStmt = "Update MyBank.Account set accountBalance = \"" + c.getAccountBalance()
                + "\", withdrawalLimit = \"" + c.getWithdrawalLimit()
                + "\" where custNRIC = \"" + c.getCustNRIC() 
                + "\" and accountType = \"" + c.getAccountType() + "\";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
}
