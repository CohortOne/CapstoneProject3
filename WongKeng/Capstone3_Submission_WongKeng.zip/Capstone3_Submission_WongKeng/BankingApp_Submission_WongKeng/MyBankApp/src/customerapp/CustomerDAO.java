/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import static java.time.temporal.ChronoUnit.YEARS;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author keng
 */
public class CustomerDAO {
    
    public static Connection initConn() throws Exception {
        Connection conn = null;
        
        //check if this driver file exist.
        if (Class.forName("com.mysql.cj.jdbc.Driver") != null) {
            conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/MyBank?useTimezone=true&serverTimezone=Asia/Singapore&"
                        + "user=root&password=mysql_08");
        } 
        
        return conn;
    }
    
    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement(); //create Statement object for SQL use
    }
    
    public static boolean insertCustomer(Customer c) throws Exception{
        //Initiating Logging
        LogUtil.doInfoLog("Inside insertCustomer()");
        
        Statement stmt = CustomerDAO.init();
        
        String insStmt = "insert into Customer (custNRIC, firstName, lastName, "
                + "custNationality, custDOB, custPIN, "
                + "custContactNum, custAddress, custGender, custEmail, custCreateDate, custStatus)"
                + " values (\"" + c.getCustNRIC() + "\", \"" + c.getFirstName() + "\", \"" +  c.getLastName() 
                + "\", \"" + c.getCustNationality() + "\", \"" + c.getCustDOB() + "\", \"" + c.getCustPIN() 
                + "\", \"" + c.getCustContactNum() + "\", \"" + c.getCustAddress() + "\", \"" + c.getCustGender()
                + "\", \"" + c.getCustEmail() + "\", \"" + c.getCustCreateDate() 
                + "\", \"" + c.getCustStatus()
                + "\");";
                               
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        LogUtil.doInfoLog("Exiting insertCustomer()");
        
        return true;
    }
    
    public static List <Customer> listCustomer(int i) throws Exception{
        
        //Logging
        LogUtil.doWarnLog("Enter listCustomer()");
        
        String qStmt = "";
        
        Statement stmt = CustomerDAO.init();
        List <Customer> custList = new ArrayList<>();
        
        if (i == 4)
            qStmt = "Select * from MyBank.Customer;";
        else
            qStmt = "Select * from MyBank.Customer order by custDOB;";
        
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            custList.add(new Customer(rs.getString("custNRIC"),rs.getString("firstName"), rs.getString("lastName"),
                    rs.getString("custNationality"), rs.getDate("custDOB").toLocalDate(),
                    rs.getInt("custPin"), rs.getString("custContactNum"), rs.getString("custEmail"), rs.getString("custAddress"),
                    rs.getTimestamp("custCreateDate"), rs.getTimestamp("custModifyDate"), rs.getString("custStatus").charAt(0)));
        }
        //Logging
        LogUtil.doWarnLog("Exiting listCustomer()");
        
        return custList;
    }
    
    public static Customer getCustomer(String custID) throws Exception{
        Statement stmt = CustomerDAO.init();
        Customer cust = null;
        String qStmt = "Select * from MyBank.Customer where custNRIC = \"" + custID + "\";";
             
        ResultSet rs = stmt.executeQuery(qStmt);
        
        while(rs.next()){
            cust = new Customer(rs.getString("custNRIC"),rs.getString("firstName"), rs.getString("lastName"),
                    rs.getString("custNationality"), rs.getDate("custDOB").toLocalDate(),
                    rs.getInt("custPin"), rs.getString("custContactNum"),rs.getString("custEmail"), rs.getString("custAddress"),
                    rs.getTimestamp("custCreateDate"), rs.getTimestamp("custModifyDate"), rs.getString("custStatus").charAt(0));
        }
        return cust;
    }
    
    public static boolean updateCustomer(Customer c) throws Exception{
        
        Timestamp modTime = new Timestamp(System.currentTimeMillis());
        
        Statement stmt = CustomerDAO.init();
        String updStmt = "Update MyBank.Customer set custEmail = \"" + c.getCustEmail() 
                + "\", custContactNum = \"" + c.getCustContactNum()
                + "\", custAddress = \"" + c.getCustAddress()
                + "\", custModifyDate = \"" + modTime
                + "\" where custNRIC = \"" + c.getCustNRIC() + "\";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
    public static List <Customer> getCustomerByPhone(String phoneNo) throws Exception{
        Connection conn = CustomerDAO.initConn();
        List <Customer> custList = new ArrayList<>();
        String qStmt = "Select * from MyBank.customer where custContactNum = ? ";
        
        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, phoneNo);
        ResultSet rs = pStmt.executeQuery();
        while(rs.next()){
            custList.add(new Customer(rs.getString("custNRIC"),rs.getString("firstName"), rs.getString("lastName"),
                    rs.getString("custNationality"), rs.getDate("custDOB").toLocalDate(),
                    rs.getInt("custPin"), rs.getString("custContactNum"),rs.getString("custEmail"), rs.getString("custAddress"),
                    rs.getTimestamp("custCreateDate"), rs.getTimestamp("custModifyDate"), rs.getString("custStatus").charAt(0)));
        }
        return custList;
    }
    
    public static boolean delCustomer(String cid) throws Exception{
        Statement stmt = CustomerDAO.init();     
        String delStmt = "delete from MyBank.Customer where custNRIC = \"" + cid + "\";";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Delete Success ");
        }else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }
    
    public static boolean actSusCustomer(String cid, char choice) throws Exception{
               
        Timestamp modTime = new Timestamp(System.currentTimeMillis());
        
        Statement stmt = CustomerDAO.init();
        String updStmt = "Update MyBank.Customer set custStatus = \"" + choice 
                + "\", custModifyDate = \"" + modTime
                + "\" where custNRIC = \"" + cid + "\";";
                        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Operation Success ");
        }else {
            System.out.println(" Operation Failed ");
        }
        return true;
    }
}
