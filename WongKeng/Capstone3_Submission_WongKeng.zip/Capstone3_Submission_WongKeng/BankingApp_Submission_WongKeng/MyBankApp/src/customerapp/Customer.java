/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.sql.Timestamp;

/**
 *
 * @author keng
 */
public class Customer {
    
    private String custNRIC;
    private String firstName;
    private String lastName;
    private String custNationality;
    private LocalDate custDOB;
    private int custPIN;
    private String custContactNum;
    private String custAddress;
    private char custGender = ' ';
    private String custEmail;
    private Timestamp custCreateDate;
    private Timestamp custModifyDate;
    private char custStatus;

    public Customer(String custNRIC, String firstName, String lastName, String custNationality, 
            LocalDate custDOB, int custPIN, String custContactNum, String custEmail, String custAddress, 
            Timestamp custCreateDate, char custStatus) 
    {
        this.custNRIC = custNRIC;
        this.firstName = firstName;
        this.lastName = lastName;
        this.custNationality = custNationality;
        this.custDOB = custDOB;
        this.custPIN = custPIN;
        this.custContactNum = custContactNum;
        this.custEmail = custEmail;
        this.custAddress = custAddress;
        this.custCreateDate = custCreateDate;
        this.custStatus = custStatus;
    }
    
    public Customer(String custNRIC, String firstName, String lastName, String custNationality, 
            LocalDate custDOB, int custPIN, String custContactNum, String custEmail, String custAddress, 
            Timestamp custCreateDate, Timestamp custModifyDate, char custStatus) 
    {
        this.custNRIC = custNRIC;
        this.firstName = firstName;
        this.lastName = lastName;
        this.custNationality = custNationality;
        this.custDOB = custDOB;
        this.custPIN = custPIN;
        this.custContactNum = custContactNum;
        this.custEmail = custEmail;
        this.custAddress = custAddress;
        this.custCreateDate = custCreateDate;
        this.custModifyDate = custModifyDate;
        this.custStatus = custStatus;
    }

    public String getCustNRIC() {
        return custNRIC;
    }

    public void setCustNRIC(String custNRIC) {
        this.custNRIC = custNRIC;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCustNationality() {
        return custNationality;
    }

    public void setCustNationality(String custNationality) {
        this.custNationality = custNationality;
    }

    public LocalDate getCustDOB() {
        return custDOB;
    }

    public void setCustDOB(LocalDate custDOB) {
        this.custDOB = custDOB;
    }

    public int getCustPIN() {
        return custPIN;
    }

    public void setCustPIN(int custPIN) {
        this.custPIN = custPIN;
    }

    public String getCustContactNum() {
        return custContactNum;
    }

    public void setCustContactNum(String custContactNum) {
        this.custContactNum = custContactNum;
    }

    public String getCustAddress() {
        return custAddress;
    }

    public void setCustAddress(String custAddress) {
        this.custAddress = custAddress;
    }

    public char getCustGender() {
        return custGender;
    }

    public void setCustGender(char custGender) {
        this.custGender = custGender;
    }

    public String getCustEmail() {
        return custEmail;
    }

    public void setCustEmail(String custEmail) {
        this.custEmail = custEmail;
    }

    public Timestamp getCustCreateDate() {
        return custCreateDate;
    }

    public void setCustCreateDate(Timestamp custCreateDate) {
        this.custCreateDate = custCreateDate;
    }

    public Timestamp getCustModifyDate() {
        return custModifyDate;
    }

    public void setCustModifyDate(Timestamp custModifyDate) {
        this.custModifyDate = custModifyDate;
    }

    public char getCustStatus() {
        return custStatus;
    }

    public void setCustStatus(char custStatus) {
        this.custStatus = custStatus;
    }
        
    @Override
    public String toString() {
        return custNRIC + "\t" + firstName + "\t\t" + lastName + "\t\t" + custNationality + "\t" 
                + custDOB + "\t" + custPIN + "\t" + custContactNum 
                + "\t" + custAddress + "\t" + custStatus + "\t" + custEmail
                + "\t\t" + custCreateDate + "\t" + custModifyDate;
    }
    
}