/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import static customerapp.BankMain.msgs;

/**
 *
 * @author keng
 */
public class CustomerMain {

    /**
     * @param args the command line arguments
     */
    public static Scanner myObj = new Scanner(System.in);
    
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }    
    
    public static int DisplayOptions() throws Exception {
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t Customer CRUD Operations ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \tFollowing are the options :: ");
        System.out.println(" \n\t\t1 >> Create Customer ");
        System.out.println(" \n\t\t2 >> Update Customer Details");
        System.out.println(" \n\t\t3 >> Delete Customer ");
        System.out.println(" \n\t\t4 >> List Customer "); 
        System.out.println(" \n\t\t5 >> List Customers Order By DOB ");
        System.out.println(" \n\t\t6 >> Find Customers By Contact Number ");
        System.out.println(" \n\t\t7 >> Activate/Suspend Customer ");
        System.out.println(" \n\t\t0 >> Return To Main Menu ");

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" Enter a numer to carry out the operation  :   ");
        
        int optVal;
        
        try {
            optVal = myObj.nextInt();
            
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }

    public static void printHeader() throws Exception {

        System.out.println(" ===============================================================================================================================================================================================================");

    }

    public static void printFooter() {
        System.out.println(" ===============================================================================================================================================================================================================");
    }
    
    public static int insCustomer() throws Exception {
        
        
        System.out.println(" \tEnter the following details  :: ");
        printFooter();
        System.out.print(" \n\t\t        " + msgs.getObject("nric") + "\t\t: ");
        String nric = myObj.next();
        System.out.print(" \n\t\t        " + msgs.getObject("fname") + "\t: ");
        String firstName = myObj.next();
        System.out.print(" \n\t\t        " + msgs.getObject("lname") + "\t\t: ");
        String lastName = myObj.next();
        System.out.print(" \n\t\t        " + msgs.getObject("nationality") + "\t: ");
        String nationality = myObj.next();
        System.out.print(" \n\t\t        " + msgs.getObject("dob") + "\t: ");
        String dob = myObj.next();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dateOfBirth = LocalDate.parse(dob, sourceFormatter);
        System.out.print(" \n\t\t        " + msgs.getObject("pin") + "\t\t: ");
        int pin = myObj.nextInt();
        System.out.print(" \n\t\t        " + msgs.getObject("phone") + "\t: ");
        String contactNum = myObj.next();
        System.out.print(" \n\t\t        " + msgs.getObject("email") + "\t\t: ");
        String email = myObj.next();
        System.out.print(" \n\t\t        " + msgs.getObject("address") + "\t\t: ");
        String address = myObj.useDelimiter("\n").next();
        
/*
        System.out.println(" \tEnter the following details  :: ");
        printFooter();
        System.out.print(" \n\t\t        Customer NRIC    : ");
        String nric = myObj.next();
        System.out.print(" \n\t\t        First Name     \t : ");
        String firstName = myObj.next();
        System.out.print(" \n\t\t        Last Name     \t : ");
        String lastName = myObj.next();
        System.out.print(" \n\t\t        Nationality     : ");
        String nationality = myObj.next();
        System.out.print(" \n\t\t        Date Of Birth (yyyy-mm-dd)  \t : ");
        String dob = myObj.next();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dateOfBirth = LocalDate.parse(dob, sourceFormatter);
        System.out.print(" \n\t\t        PIN     \t : ");
        int pin = myObj.nextInt();
        System.out.print(" \n\t\t        Contact Number     : ");
        String contactNum = myObj.next();
        System.out.print(" \n\t\t        Email          \t : ");
        String email = myObj.next();
        System.out.print(" \n\t\t        Address     \t : ");
        String address = myObj.useDelimiter("\n").next();
*/
        
        //get current time in millisec
        Timestamp createDate = new Timestamp(System.currentTimeMillis());
        
        //set customer status to Active
        char status = 'A';        
        
        Customer custObj = new Customer(nric, firstName, lastName, nationality, dateOfBirth, 
                pin, contactNum, email, address, createDate, status);
                
        printHeader();
        
        if (CustomerDAO.insertCustomer(custObj)) {
            printFooter();
        }
        
        System.out.println(custObj);
        
        return 1;
    }
    
    public static int listCustomers(int i) throws Exception {
        printHeader();
        System.out.println("NRIC  \t\tFirst Name \tLast Name \tNationality "
                + "\tDOB \t\tPin \tContact Number \tAddress \tStatus \tEmail \t\t\t\tCreate Date \t\tModify Date ");
        printFooter();
        CustomerDAO.listCustomer(i).stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int updCustomer() throws Exception {
        listCustomers(4); //4 = display sorted by NRIC
        System.out.print(" \tEnter the Customer NRIC to Update :: ");
        String cid = myObj.next();
        String input = "";
//        System.out.print(" \t You can only update Email and PhoneNo [Y/N][y/n]:: ");
//        String resp = myObj.next();
        
            System.out.println(" Initiating update for Customer ID ::" + cid);
            printHeader();
            Customer c = CustomerDAO.getCustomer(cid);
            System.out.println(" Select Customer ::: ");
            System.out.print(c);
            printFooter();

            System.out.println(" \n\t\t   Current Email   \t : " + c.getCustEmail());
            System.out.print(" \n\t\t   New Email       \t : ");
            input = myObj.useDelimiter("\n").next();
            if (!(input.isEmpty())) {
                c.setCustEmail(input);
            }        
            
            System.out.println(" \n\t\tCurrent Contact Number    \t : " + c.getCustContactNum());
            System.out.print(" \n\t\t    New  Phone          \t : ");
            input = myObj.useDelimiter("\n").next();
            if (!(input.isEmpty())) {
                c.setCustContactNum(input);
            }           
            
            System.out.println(" \n\t   Current Address    \t : " + c.getCustAddress());
            System.out.print(" \n\t    New Address          \t : ");
            input = myObj.useDelimiter("\n").next();            
            if (!(input.isEmpty())) {
                c.setCustAddress(input);
            }                      
            
            CustomerDAO.updateCustomer(c);
            printFooter();
        
            return 1;
    }
    
    public static int findCustomerByPhoneNo() throws Exception {
        printHeader();
        System.out.print(" \tEnter the Contact Number to Find :: ");
        String phoneNo = myObj.next();
        
        printHeader();
        System.out.println("NRIC  \t\tFirst Name \tLast Name \tNationality "
                + "\tDOB \t\tPin \tContact Number \tAddress \tCreate Date \tModify Date \tStatus \tEmail ");
        printFooter();
        CustomerDAO.getCustomerByPhone(phoneNo).stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int delCustomers() throws Exception {
        listCustomers(4); //4 - sort by NRIC and list
        System.out.print(" \tEnter the Customer NRIC to Delete Record :: ");
        String cid = myObj.next();
        System.out.print(" \tAre you sure [Y/N]:: ");
        String resp = myObj.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating delete for Customer NRIC ::" + cid);
            printHeader();
            CustomerDAO.delCustomer(cid);
            printFooter();
            
            listCustomers(4);
        }
        return 1;
    }
    
    public static int actSusCustomers() throws Exception {
        listCustomers(4); //4 - sort by NRIC and list
        System.out.print(" \tEnter the Customer NRIC to Activate/Suspend :: ");
        String cid = myObj.next();
        
        System.out.print(" \tEnter 'A' to Activate or 'S' to Suspend or "
                + "'Q' to Quit :: ");
        char choice = Character.toUpperCase(myObj.next().charAt(0));
        
        System.out.print(" \tAre you sure [Y/N]:: ");
        String resp = myObj.next();
        
        if (resp.equalsIgnoreCase("y")) {
            
            if (choice == 'A') {
                System.out.println(" Activating Customer, NRIC ::" + cid);
                printHeader();
                CustomerDAO.actSusCustomer(cid, choice);
                printFooter();

            } else if (choice == 'S') {
                System.out.println(" Suspending Customer, NRIC ::" + cid);
                printHeader();
                CustomerDAO.actSusCustomer(cid, choice);
                printFooter();

            } else {
                System.out.println("\nOperation Cancelled!");
            }
            
            listCustomers(4);
        }
        
        
        
        return 1;
    }

    public static void CustomerMgmtMain() throws Exception {
        // TODO code application logic here
                    
        while (true) {
            int optionVal = DisplayOptions();

            printHeader();
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {

                case 1:
                    System.out.println("Insert Customer  ");
                    printFooter();
                    insCustomer();
                    break;
                case 2:
                    System.out.println("Update Customer ::: ");
                    updCustomer();
                    break;
                case 3:
                    System.out.println("Delete Customer ::: ");
                    delCustomers();
                    break;
                case 4:
                    System.out.println("List Customers ::: ");
                    listCustomers(optionVal);
                    break;
                case 5:
                    System.out.println("List Customers ::: ");
                    listCustomers(optionVal);
                    break;
                case 6:
                    System.out.println("Find Customers By Phone No::: ");
                    findCustomerByPhoneNo();
                    break;
                case 7:
                    System.out.println("Activate/Suspend Customer ::: ");
                    actSusCustomers();
                    break;
                case 0:
                    System.out.println("Return To Main Menu");
                    printFooter();                    
                    return;
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    printFooter();
                    Thread.sleep(4000);
                    return;
            }
        }
    
    }
}
