/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.logging.Formatter;

/**
 *
 * @author keng
 */
public class LogUtil {
    
    static private FileHandler logFile;
    static private SimpleFormatter logFormatter;
    
    static private final Logger LOGGER = Logger.getLogger(LogUtil.class.getName());
    
    //static constructor
    static {
        
        LOGGER.setUseParentHandlers(false); //suppress logging to root console
        
        LOGGER.setLevel(Level.INFO);
        
        try {
            logFile = new FileHandler("/Volumes/Toshiba-4TB/My Trainings/"
            + "Java Developer Course/Capstone3/MyBankApp/"
            + "logs/MyBankApp.log");
        
        logFormatter = new SimpleFormatter();
        
        logFile.setFormatter(logFormatter);
        LOGGER.addHandler(logFile);
        
        } catch (Exception e) {
            LOGGER.warning("Error in UtilLog static constructor.");
        }
        
    }
   
    public static void doInfoLog(String s) {
        LOGGER.info(s);
    }
    
    public static void doWarnLog(String s) {
        LOGGER.warning(s);
    }
    
    public static void doSevereLog(String s) {
        LOGGER.severe(s);
    }     
}
//Entry for VM Options in Project Properties Run
//-Djava.util.logging.config.file="/Volumes/Toshiba-4TB/My Trainings/Java Developer Course/Capstone3/MyBankApp/loggerConfig/log_v3.properties"
