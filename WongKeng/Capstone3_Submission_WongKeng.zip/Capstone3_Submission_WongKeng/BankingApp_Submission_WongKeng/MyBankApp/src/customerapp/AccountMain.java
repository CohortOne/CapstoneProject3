/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import static customerapp.CustomerMain.printFooter;
import static customerapp.CustomerMain.printHeader;
import java.util.Scanner;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author keng
 */
public class AccountMain {
    
    public static Scanner myObj = new Scanner(System.in);
    
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }
    
    public static int DisplayAccountManagementOptions() throws Exception {
        
        //Logging
        LogUtil.doWarnLog("Enter DisplayAccountManagementOptions");
        
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t Account Management System ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \tFollowing are the options :: ");
        System.out.println(" \n\t\t1 >> Open New Account ");
        System.out.println(" \n\t\t2 >> Deposit Funds ");
        System.out.println(" \n\t\t3 >> Withdraw Funds ");
        System.out.println(" \n\t\t4 >> Set Withdrawal Limit "); 
        System.out.println(" \n\t\t5 >> Generate Statement ");
        System.out.println(" \n\t\t0 >> Return To Main Menu ");

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" Please enter option  :   ");
        
        int optVal;
        
        try {
            optVal = myObj.nextInt();
            
        } catch (Exception e) {

            optVal = -1;
        }
        
        LogUtil.doWarnLog("Exiting DisplayAccountManagementOptions");
        
        return optVal;
    }
    
    public static void AccountMgmtMain() throws Exception {
        // TODO code application logic here
                    
        while (true) {
            int optionVal = DisplayAccountManagementOptions();

            printHeader();
            System.out.print("\t\t Option Selected : \t\t");
            
            switch (optionVal) {

                case 1:
                    System.out.println("Open New Account ::: ");
                    printFooter();
                    CreateAccount();
                    break;
                case 2:
                    System.out.println("Deposit Funds ::: ");
                    DepositFunds();
                    break;
                case 3:
                    System.out.println("Withdraw Funds ::: ");
                    WithdrawFunds();
                    break;
                case 4:
                    System.out.println("Set/Change Withdrawal Limit ::: ");
                    SetWithdrawalLimit();
                    break;
                case 5:
                    System.out.println("Generate Statement ::: ");
                    GenerateStatement();
                    break;
                case 0:
                    System.out.println("Return To Main Menu");
                    printFooter();
                    return;                    
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    printFooter();
                    Thread.sleep(4000);
                    return;                    
            }
        }
    
    }
    
    public static int CreateAccount() throws Exception {
        
        double interest;
        double minBalance;
        double belowMinBalanceFee;
        
        System.out.println(" \tEnter the following details  :: ");
        printFooter();
        System.out.print(" \n\t\t     Customer NRIC    : ");
        String nric = myObj.next();
        System.out.print(" \n\t\t     Account Type [Savings (SA) / Current (CA) / Senior (SN)]\t : ");
        String accountType = myObj.next();
        System.out.print(" \n\t\t     Initial Deposit Amount\t : $");
        double depositAmt = myObj.nextDouble();
        System.out.print(" \n\t\t     Set Withdrawal Limit \t : $");
        double withdrawalLimit  = myObj.nextDouble();
        
        //check if user already have the requested account type
        String acctTypeExist = CheckAcctTypeExist(nric, accountType);
        
//        System.out.println("Account Number = " + acctTypeExist);
        
        if (acctTypeExist == null) {
           String accountNum = generateAcctNum(nric, accountType);
        
            switch (accountType) {
                case "CA":
                    interest = 0.0;
                    minBalance = 0.0;
                    belowMinBalanceFee = 0.0;
                    break;
                case "SN":
                    interest = 0.20;
                    minBalance = 0.0;
                    belowMinBalanceFee = 0.0;
                    break;
                default: //is Saving
                    accountType = "SA";
                    interest = 0.10;
                    minBalance = 500.0;
                    belowMinBalanceFee = 2.5;               
            }
                      
            //set customer status to Active
            char accountStatus = 'A';

            Account custAcctObj = new Account(nric, accountType, accountNum, depositAmt, 
                    withdrawalLimit, accountStatus, interest, minBalance, belowMinBalanceFee);

            printHeader();
            
            boolean status = AccountDAO.insertAccount(custAcctObj);

            if (status) {
                printFooter();
                
            //update Transaction table
                AccountDAO.AccountTransactions(nric, accountType, depositAmt, 'D');
            } 
        }
                                   
//        System.out.println(custAcctObj);
        
        return 1;
    }
    
    public static boolean DepositFunds() throws Exception {
        
        boolean status;
                        
        System.out.print("\n\t\t Please enter customer's NRIC -> ");
        String nric = myObj.next();
        
        System.out.print("\n\t\t Deposit Account Type \n\t\t [Savings (SA) / Current (CA) / Senior (SN)] -> ");
        String accountType = myObj.next();
        
        System.out.print("\n\t\t Deposit Amount -> $");
        double amount = myObj.nextDouble();
        
        char transactionType = 'D'; //Deposit Transaction
        
        Account acctDetails = AccountDAO.GetAccountDetails(nric, accountType);
        
        status = AccountDAO.AccountTransactions(nric, accountType, amount, transactionType);
        
        //update account balance
        acctDetails.setAccountBalance(acctDetails.getAccountBalance()+ amount);
        status = AccountDAO.UpdateAccount(acctDetails);
        
        if (status)
            ListTransactions(nric, accountType);         
                  
        return status;
        
    }
    
    public static boolean WithdrawFunds() throws Exception {
        
        boolean status;
                                
        System.out.print("\n\t\t Please enter customer's NRIC -> ");
        String nric = myObj.next();
        
        System.out.print("\n\t\t Withdrawal Account Type \n\t\t [Savings (SA) / Current (CA) / Senior (SN)] -> ");
        String accountType = myObj.next();
        
        System.out.print("\n\t\t Withdrawal Amount -> $");
        double amount = myObj.nextDouble();
        
        char transactionType = 'W'; //Deposit Transaction
        
        status = CheckWithdrawalCriteria (nric, accountType, amount);
                        
        if (status)
            AccountDAO.AccountTransactions(nric, accountType, amount, transactionType);
        
        ListTransactions(nric, accountType);         
                  
        return status;
        
    }
    
    public static boolean CheckWithdrawalCriteria(String nric, String accountType, double amount) throws Exception {
        
        boolean status = false;
        
        Account acctDetails = AccountDAO.GetAccountDetails(nric, accountType);
                      
        if (amount <= acctDetails.getWithdrawalLimit()){
            
            if (amount < acctDetails.getAccountBalance()) {
                
                if ((acctDetails.getAccountBalance() - amount) < acctDetails.getMinBalance()) {
                    System.out.println("The Minimum Balance that you are required to maintain is $"
                    + acctDetails.getMinBalance() + ". If you proceed to withdraw, you will be charged the "
                            + "Below Minimum Balance Fee of $" + acctDetails.getBelowMinBalanceFee());
                    
                    System.out.print("\nDo you want to proceed (Y/N)?");
                    String resp = myObj.next();
                    
                    if (resp.equalsIgnoreCase("y")) {                                           
                        
                        System.out.println("Withdrawal successful. "
                                + "\nYour new account balance in " + acctDetails.getAccountNum()
                                + " is $" + acctDetails.getAccountBalance() +
                                " and you will also be charged a fee of $" + acctDetails.getBelowMinBalanceFee() +
                                " at the end of the month.\n");
                        
                        acctDetails.setAccountBalance(acctDetails.getAccountBalance()-amount);
                        status = AccountDAO.UpdateAccount(acctDetails);                                                
                                                
                    }
                    
                } else {                    
                    System.out.println("Withdrawal successful. "
                                + "\nYour new account balance in " + acctDetails.getAccountNum()
                                + " is $" + acctDetails.getAccountBalance());
                    
                                        
                    acctDetails.setAccountBalance(acctDetails.getAccountBalance()-amount);
                    status = AccountDAO.UpdateAccount(acctDetails);                                     
                    }
                
            } else {
                System.out.println("\nWithdrawal UNSUCCESSFUL - Your withdrawal amount of $" + amount 
                        + " is greater than your current account balance of $" + acctDetails.getAccountBalance());
                System.out.println("Please re-enter an amount lower than your withdrawal limit.\n");
            }
        } else {
            System.out.println("\nWithdrawal UNSUCCESSFUL - Your current withdrawal limit is $"
                + acctDetails.getWithdrawalLimit());
            System.out.println("Please re-enter an amount lower than your withdrawal limit.\n");
        }
                
        return status;
    }
    
    public static boolean GenerateStatement() throws Exception {
        boolean status = false;
        
        List <String> requiredAccountNum = new ArrayList<>();
        Account accountDetails = null;
                       
        printHeader();
        
        System.out.print("\n\t\t Please enter customer's NRIC -> ");
        String nric = myObj.next();
        
        requiredAccountNum = AccountDAO.GetAllAccounts(nric);
        
        if (requiredAccountNum != null) {
            
            for (String acctType : requiredAccountNum) {
                ListTransactions(nric, acctType);
                
                accountDetails = AccountDAO.GetAccountDetails(nric, acctType);
                
                System.out.println("Account Balance -> $" + accountDetails.getAccountBalance());
                
                accountDetails = null; //reset object
            }
            
            status = true;
        }
        
        return status;        
    }
    
    public static int ListTransactions (String nric, String accountType) throws Exception {
        
        printHeader();
        
        System.out.println("Customer NRIC : " + nric);
        System.out.println("Type of Account : " + accountType);
        System.out.println("\nTransactions details as follows:");
        
        System.out.println("\nTransaction ID  \t\t\tDate & Time \t\tType \tAmount ($) "
                + "\tDescription");
        
        printFooter();
        
        AccountDAO.DisplayBalanceSummary(nric, accountType).stream().forEach(System.out::println);
        
        printFooter();
        
        return 1;
    }
    
    public static String CheckAcctTypeExist(String nric, String accountType) throws Exception {
                       
        String accountNum = AccountDAO.getCustomerAccountNum(nric, accountType);
        
        if (accountNum != null) {
            System.out.println("\nCustomer with NRIC (" + nric +") already has a " + 
                    accountType + " account. \nThe Account Number is -> " + accountNum);
                        
        }
        
        return accountNum;
    }
    
    public static String generateAcctNum(String nric, String accountType) throws Exception {
        //call function to check account held by customer
        
        String accountNum = accountType + nric.substring(4) + "-1";
                
        return accountNum;
    }
    
    public static boolean SetWithdrawalLimit() throws Exception{
        
        boolean status;
        
        System.out.print("\n\t\t Please enter customer's NRIC -> ");
        String nric = myObj.next();
        
        System.out.print("\n\t\t Account Type \n\t\t [Savings (SA) / Current (CA) / Senior (SN)] -> ");
        String accountType = myObj.next();
        
        Account acctDetails = AccountDAO.GetAccountDetails(nric, accountType);
        
        System.out.println("\n\t\t Current Withdrawal Limit -> $" + 
                acctDetails.getWithdrawalLimit());
        
        System.out.print("\n\t\t Enter New Withdrawal Limit -> $");
        double amount = myObj.nextDouble();
        
        acctDetails.setWithdrawalLimit(amount);
        
        status = AccountDAO.UpdateAccount(acctDetails);
        
        return status;
    }
}
