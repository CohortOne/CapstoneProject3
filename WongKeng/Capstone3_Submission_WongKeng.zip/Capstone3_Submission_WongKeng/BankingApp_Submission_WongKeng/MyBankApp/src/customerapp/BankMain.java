/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import static customerapp.CustomerMain.printFooter;
import static customerapp.CustomerMain.printHeader;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 *
 * @author keng
 */
public class BankMain {
    
    //Global variable for internationalisation
    public static String language;
    public static String country;
    
    public static Locale locale;
    public static ResourceBundle msgs;
        
    public static Scanner myObj = new Scanner(System.in);
    
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }
    
    public static int DisplayBankMainOptions() throws Exception {
        
               
        //start logging
        LogUtil.doInfoLog("In DisplayBankMainOptions()");
                        
        System.out.println("\n\n ********************************************************************************************* ");
        System.out.println("\n\t " + msgs.getObject("bankAppSys") + " ::: ");
        System.out.println(" \t------------------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \t" + msgs.getObject("followOptions") + " :: ");
        System.out.println(" \n\t\t1 >> " + msgs.getObject("custMgt") + " ");
        System.out.println(" \n\t\t2 >> " + msgs.getObject("accountMgt") + " ");
        System.out.println(" \n\t\t0 >> " + msgs.getObject("exit"));

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" " + msgs.getObject("optionSelected") + "  :   ");
        
        int optVal;
        
        try {
            optVal = myObj.nextInt();
            
        } catch (Exception e) {

            optVal = -1;
        }
        
        LogUtil.doInfoLog("Exit DisplayBankMainOptions()");
        
        return optVal;
    }
    
    public static void main(String[] args) throws Exception {
        
        //Localisation of Application
        System.out.print("Please select Language option (EN-English or CH-Chinese) -> ");
        String langOpt = myObj.next();
        
        if (langOpt.equalsIgnoreCase("CH")) {
            language = "zh";
            country = "CN";
        } else {
            language = "en";
            country = "SG";
        }
                
        //Localisation
        locale = new Locale(language, country);
        msgs = ResourceBundle.getBundle("bundles.Msg_Bundle", locale);
        
        //Setup Logger using its static constructor
//        LogUtil logStart = new LogUtil();
        
        //start logging
        LogUtil.doInfoLog("Here in Main");
                                    
        while (true) {
            int optionVal = DisplayBankMainOptions();

            printHeader();
            
            //Internationalisation
            
            System.out.print("\t\t " + msgs.getObject("optionSelected") +
                    " : \t\t");
            
            switch (optionVal) {

                case 1:
                    System.out.println(" " + msgs.getObject("custMgt") + " ::: ");
                    printFooter();
                    CustomerMain.CustomerMgmtMain();
                    break;
                case 2:
                    System.out.println(" " + msgs.getObject("accountMgt") + " ::: ");
                    AccountMain.AccountMgmtMain();
                    break;
                case 0:
                    System.out.println(msgs.getObject("exit") + "...");
                    printFooter();                    
                    System.exit(0);
                    break;
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### " + msgs.getObject("invalidOption") + " ####");
                    printFooter();
                    Thread.sleep(4000);
                    break;
            }
            
/*
            System.out.print("\t\t Option Selected : \t\t");
            
            switch (optionVal) {

                case 1:
                    System.out.println("Customer Management ::: ");
                    printFooter();
                    CustomerMain.CustomerMgmtMain();
                    break;
                case 2:
                    System.out.println("Account Management ::: ");
                    AccountMain.AccountMgmtMain();
                    break;
                case 0:
                    System.out.println("Exiting Application...");
                    printFooter();                    
                    System.exit(0);
                    break;
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    printFooter();
                    Thread.sleep(4000);
                    break;
            }
*/
        }
    
    }
}
