/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.time.LocalDateTime;

/**
 *
 * @author keng
 */
public class Account {
    
    private String custNRIC;
    private String accountType;
    private String accountNum;
    private LocalDateTime accountStartDate;
    private double accountBalance;
    private double interestRate;
    private double withdrawalLimit;
    private char accountStatus;
    private double belowMinBalanceFee;
    private double minBalance;

    public Account(String custNRIC, String accountType, String accountNum, 
            double accountBalance, double withdrawalLimit, char accountStatus,
            double interestRate, double minBalance, 
            double belowMinBalanceFee) {
        this.custNRIC = custNRIC;
        this.accountType = accountType;
        this.accountNum = accountNum;
        this.accountBalance = accountBalance;
        this.withdrawalLimit = withdrawalLimit;
        this.accountStatus = accountStatus;
        this.interestRate = interestRate;
        this.minBalance = minBalance;
        this.belowMinBalanceFee = belowMinBalanceFee;
        
        //set account creation date time
        this.accountStartDate = LocalDateTime.now();
    }
    
    public Account(String accountType) {
        this.accountType = accountType;
    }
    
    public Account(String custNRIC, String accountType, String accountNum, 
            char accountStatus) {
        this.custNRIC = custNRIC;
        this.accountType = accountType;
        this.accountNum = accountNum;
        this.accountStatus = accountStatus;
    }        

    public String getCustNRIC() {
        return custNRIC;
    }

    public void setCustNRIC(String custNRIC) {
        this.custNRIC = custNRIC;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public LocalDateTime getAccountStartDate() {
        return accountStartDate;
    }

    public void setAccountStartDate(LocalDateTime accountStartDate) {
        this.accountStartDate = accountStartDate;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getWithdrawalLimit() {
        return withdrawalLimit;
    }

    public void setWithdrawalLimit(double withdrawalLimit) {
        this.withdrawalLimit = withdrawalLimit;
    }

    public char getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(char accountStatus) {
        this.accountStatus = accountStatus;
    }

    public double getBelowMinBalanceFee() {
        return belowMinBalanceFee;
    }

    public void setBelowMinBalanceFee(double belowMinBalanceFee) {
        this.belowMinBalanceFee = belowMinBalanceFee;
    }

    public double getMinBalance() {
        return minBalance;
    }

    public void setMinBalance(double minBalance) {
        this.minBalance = minBalance;
    }

    @Override
    public String toString() {
        return "Customer NRIC : " + custNRIC 
                + "\nAccount Type : " + accountType 
                + "\nAccount Number : " + accountNum 
                + "\nAccount Start Date : " + accountStartDate
                + "\nAccount Balance : " + accountBalance 
                + "\nInterestRate : " + interestRate 
                + "\nWithdrawal Limit : " + withdrawalLimit 
                + "\nAccount Status : " + accountStatus 
                + "\nBelow Min Balance Fee : " + belowMinBalanceFee 
                + "\nMinimum Balance : " + minBalance;
    }
    
    
}
