/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxapp5;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author chand
 */
public class UniqueClockController implements Initializable {

    @FXML
    private ProgressIndicator min;
    @FXML
    private ProgressIndicator hr;
    @FXML
    private ProgressIndicator sec;
    @FXML
    private Label hrl;
    @FXML
    private Label minl;
    @FXML
    private Label secl;    
    @FXML
    private Label time;
    @FXML
    private Label date;
    @FXML
    private Label daysToWeekend;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Timeline fiveSecondsWonder = new Timeline(
                new KeyFrame(Duration.seconds(.5),
                        new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        LocalTime lt = LocalTime.now();
                        LocalDate ld = LocalDate.now();
                        
                        String displayHr = lt.format(DateTimeFormatter.ofPattern("HH"));
                        String displayMin = lt.format(DateTimeFormatter.ofPattern("mm"));
                        String displaySec = lt.format(DateTimeFormatter.ofPattern("ss"));                        
                        
                        hr.setProgress(lt.getHour() * 4.166666666666667 / 100);
                        min.setProgress(lt.getMinute() * 1.666666666666667 / 100);
                        sec.setProgress(lt.getSecond() * 1.666666666666667 / 100);
                        hrl.setText("" + displayHr);
                        minl.setText("" + displayMin);
                        secl.setText("" + displaySec);
                        time.setText(displayHr + ":" + displayMin 
                            + ":" + displaySec);
                        date.setText(ld.getDayOfWeek() + ", "
                            + ld.getDayOfMonth() + "-"
                            + ld.getMonth() + "-"
                            + ld.getYear());
                        
                        //call method to calculate number of days to weekend
                        int numDaysToWE = checkWeekend();
                        
                        if (numDaysToWE == 0) 
                            daysToWeekend.setText("TGIF, Today is the Weekend!!!");
                        else if (numDaysToWE == 1)
                            daysToWeekend.setText("TOMORROW is The Weekend!!!");
                        else
                            daysToWeekend.setText(numDaysToWE + " Days To The Weekend!!!");
                        
                      //  pind.setProgress(lt.getSecond() * 1.666666666666667 / 100);
                                            
                    }
                }));
        fiveSecondsWonder.setCycleCount(Timeline.INDEFINITE);
        fiveSecondsWonder.play();

    }
    
    public int checkWeekend() {
        
        Calendar c = Calendar.getInstance();
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
                
        int numDaysToWE = 0;
        
        if (dayOfWeek == Calendar.FRIDAY)
            return 0;
        else {
            for (int i=1; i<7; i++) {
                c.add(Calendar.DATE, i);
                dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            
                if (dayOfWeek == Calendar.FRIDAY) {
                    numDaysToWE = i;
                    break;
                }        
            }
                
        }
        return numDaysToWE;
    }
}

    
