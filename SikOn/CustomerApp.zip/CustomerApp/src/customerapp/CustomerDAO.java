/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import com.mysql.cj.jdbc.CallableStatement;
import static customerapp.Main.LOGGER;
import static customerapp.Utility.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 *
 * @author chand
 */
public class CustomerDAO {


    public static int newCustomer(Customer c) throws Exception{
        Connection conn = initConn();
        String qStmt = "{CALL newCustomer('" + c.getCustName() + "', '" + c.getNric() + "', '"
                     + c.getAddr1() + "', '" + c.getAddr2() + "', '" 
                     + c.getCustDOB().toString() + "')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        int retnCode = 9999;
        String retnMsg = "";
        int custId = 0;

        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            retnCode = rs.getInt("RetnCode");
            retnMsg = rs.getString("RetnMsg");
            custId = rs.getInt("CustId");
            break;
        }
        
        if (retnCode == 0) {
            System.out.println(" Insert Success ");
        }else {
            System.out.println("Insert Failed: " + retnMsg 
            + (custId>0?("(" + Integer.toString(custId) + ")"):""));
        }
        
        return custId;
                
    }


    public static void andCustomer(Customer c, char chrAD) throws Exception{
    boolean errDB = false;
    int retnCode = 9999;
    String retnMsg = "";
    int custId = 0;
        try {
            Connection conn = initConn();
            String qStmt = "{CALL updCustomer(" + c.getCustID() + ", '" + chrAD + "', '', '',  '', '', '1900-01-01')}";
            CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);

            ResultSet rs = cstmt.executeQuery();
            while(rs.next()){
                retnCode = rs.getInt("RetnCode");
                retnMsg = rs.getString("RetnMsg");
                custId = rs.getInt("CustId");
                break;
            }
        }
        catch (Exception e) {
                        errDB = true;
                        LOGGER.log(Level.SEVERE, "DB Error, {0}", e.getMessage());
        }

        String strSrv = (chrAD=='A'?"Activation":"Deactivation");
        if (errDB) {
           System.out.println(strSrv + " failed due to database problem, report to IT Support.");
        } else {
            if (retnCode == 0) {
               System.out.println(strSrv + " success ");
            }else {
                System.out.println(strSrv + " failed: " + retnMsg 
                + (custId>0?("(" + Integer.toString(custId) + ")"):""));
            }
        }
    }


    public static List <Customer> findCustomer(int intCustId, String strNRIC, String strName, String strSort) throws Exception{
        List <Customer> custList = new ArrayList<>();

        Connection conn = initConn();
        String qStmt = "{CALL findCustomer(" + intCustId + ", '" + strNRIC + "', '" + strName + "', '" + strSort + "')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();

        while(rs.next()){
            custList.add(new Customer(rs.getInt("CustId"), rs.getString("CustName"), rs.getString("NRIC"),
                                      rs.getString("Addr1"), rs.getString("Addr2"), rs.getDate("CustDOB").toLocalDate(),
                                      rs.getString("CustStts").charAt(0), rs.getDate("DateCrea").toLocalDate(), rs.getDate("DateUpd").toLocalDate()));
        }
        return custList;
    }  


    public static Customer getCustomer(int cid) {
        Customer myCust = null;
        try {
            Connection conn = initConn();
            String qStmt = "{CALL findCustomer(" + cid + ", '', '', '')}";
            CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
            ResultSet rs = cstmt.executeQuery();

            while(rs.next()){
                myCust = new Customer(rs.getInt("CustId"), rs.getString("CustName"), rs.getString("NRIC"),
                                      rs.getString("Addr1"), rs.getString("Addr2"), rs.getDate("CustDOB").toLocalDate(),
                                      rs.getString("CustStts").charAt(0), rs.getDate("DateCrea").toLocalDate(), rs.getDate("DateUpd").toLocalDate());
                break;
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "DB Error, {0}", e.getMessage());
            System.out.println("**** DB Error, please report to IT Support ***");
            return myCust;
        }
        return myCust;
        
    }
    
    
    public static boolean updCustomer(Customer c) throws Exception{
        Connection conn = initConn();
        String qStmt = "{CALL updCustomer(" + c.getCustID() + ", 'U', '" + c.getCustName() + "', '" + c.getNric() + "',  '" 
                                            + c.getAddr1() + "', '" + c.getAddr2() + "', '" + c.getCustDOB().toString() + "')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        int retnCode = 9999;
        String retnMsg = "";
        int custId = 0;

        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            retnCode = rs.getInt("RetnCode");
            retnMsg = rs.getString("RetnMsg");
            custId = rs.getInt("CustId");
            break;
        }
        
        if (retnCode == 0) {
           System.out.println(" Update Success ");
        }else {
            System.out.println("Update Failed: " + retnMsg 
            + (custId>0?("(" + Integer.toString(custId) + ")"):""));
        }
        return true;
        
    }
}


