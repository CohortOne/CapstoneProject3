package customerapp;
import static customerapp.AccountDAO.*;
import static customerapp.Account_CRUD.listAccts;
import static customerapp.Customer_CRUD.listCusts;
import static customerapp.Main.*;
import static customerapp.Tran.*;
import static customerapp.TranDAO.*;
import static customerapp.Utility.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Tran_CRUD {

    private static List <Tran> myTranList;

    public static void listTrans(int cid, int aid) throws Exception {
        int intCustId = 0;
        int intAcctNum = 0;
        int intTranId = 0;
        int optVal = -1;

        if (cid != 0) {
            intCustId = cid;
        } else {
            if (aid != 0) {
                intAcctNum = aid;
            } else {
                do {
                    printPinned();
                    System.out.println("***********************************************");
                    System.out.println(" List Transaction Menu ::: ");
                    System.out.println("***********************************************");
                    System.out.println(" 1 Retrive by Tran Id ");
                    System.out.println(" 2 Retrive for Pinned Account");
                    System.out.println(" 3 Retrive for Pinned Customer");
                    System.out.println(" 0 Return");
                    System.out.println("***********************************************");
                    optVal = Utility.readlnInt(" Enter menu option number:");
                } while (optVal > 3);

                if (optVal == 0) { return;}

                if (optVal == 1) {
                    intTranId = readlnInt(" Enter Transaction Id, 0 to go back:   ");
                    if (intTranId == 0) {return;}
                }

                if (optVal == 2) {
                    if (pinAcct == null) {
                        System.out.println("No pinned Account.");
                    } else {
                        intAcctNum = pinAcct.getAcctNum();
                    }
                }

                if (optVal == 3) {
                    if (pinCust == null) {
                        System.out.println("No pinned Customer.");
                    } else {
                        intCustId = pinCust.getCustID();
                    }
                }
            }
        }

        myTranList = findTran(intTranId, intAcctNum, intCustId, ' ', ' ');

        Tran myTran = null;
        if (myTranList.isEmpty()) {
            System.out.println(" No Transaction found.");
            return;
        }

        int tid = 0;
        if (myTranList.size() == 1 ) {
            myTran = myTranList.get(0);
            tid = myTran.getTranId();
        } else {
            int tidFound = 0;
            String strPrompt = " Pick a Transaction to operate on by entering the Transaction Id, 0 to exit:";
            do {
                printHeader();
                System.out.println(strTranLbl);
                System.out.println(strTranUdl);
                myTranList.stream().forEach(System.out::println);
                printFooter();

                tid = readlnInt(strPrompt);
                if (tid == 0) {
                    break;
                }

                Iterator<Tran> myTranIterator = myTranList.iterator();
                while (myTranIterator.hasNext()) {
                    myTran = myTranIterator.next();
                    if (myTran.getTranId() == tid) {
                        tidFound = aid;
                        break;
                    }
                }

                if (tidFound == 0) {
                    strPrompt =" No Transaction found of Transaction Id=" + tid + ", pick again, or 0 to exit...";
                }
            } while (tidFound == 0);

            if (tidFound == 0) {
                System.out.println(" No Transaction selected, returning to upper menu...");
                return;
            }
        }

        do {
            printHeader();
            System.out.println(strTranLbl);
            System.out.println(strTranUdl);
            System.out.println(myTran.toString());
            printFooter();

            System.out.println("***********************************************");
            System.out.println(" Transaction Menu ::: ");
            System.out.println("***********************************************");
            System.out.println(" Transaction");
            System.out.println("  1 Reverse the transaction");
            System.out.println("  2 Clear the transaction");
            System.out.println(" Navigation");
            if (aid == 0) {
                System.out.println(" 21 Work with Account of this Transaction");
            }
            if (cid == 0) {
                System.out.println(" 22 Work with principal holder of Account of this Transaction");
                System.out.println(" 23 Work with joint holder of Account of this Transaction");
            }
            System.out.println("***********************************************");
            System.out.println("  0 Return");
            System.out.println("***********************************************");
            optVal = Utility.readlnInt(" Enter menu option number:");

            if (optVal == 1) {
                System.out.println("   **** function not yet implemented. ***");
                myTran = getTran(tid);
            }
            
            if (optVal == 2) {
                System.out.println("   **** function not yet implemented. ***");
                myTran = getTran(tid);
            }
            
            if (optVal == 21) {
                listAccts(myTran.getAcctNum(), 0);
                optVal = 0;
            }
                        
            if (optVal == 22) {
                var tmpAcct = getAccount(myTran.getAcctNum());
                listCusts(tmpAcct.getCustId());
                optVal = 0;
            }
            
            if (optVal == 23) {
                var tmpAcct = getAccount(myTran.getAcctNum());
                if (tmpAcct.getCustIdJoint() != 0) {
                    listCusts(tmpAcct.getCustIdJoint());
                    optVal = 0;
                } else {
                    System.out.println(" Account has no joint holder.");
                    myTran = getTran(tid);
                }
            }

        } while (optVal != 0);
    }    


    
    public static int newCashTransaction(Account myAcct, boolean booWithPin) throws Exception {
    Account thisAcct;
    List<Tran> myTrans = new ArrayList<Tran>();
    int nxtAN;
        if (myAcct.getAcctStts() != 'O') {
            System.out.println(" Account is not opened, cannot deposit/withdraw.");
            return 0;
        }
        if (booWithPin && (pinAcct == null)) {
            System.out.println(" No pinned Account, cannot transfer.");
            return 0;
        }
        if (booWithPin && (pinAcct.getAcctStts() != 'O')) {
            System.out.println(" Pinned Account is not opened, cannot transfer.");
            return 0;
        }
        System.out.println(" Enter deposit/withdrawal details:");
        printFooter();
        
        char chrTranType;
        do {
            System.out.print(" Is this a [D]eposit to / [W]ithdrawal from Account[" + myAcct.getAcctNum() + "]:");
            chrTranType = myObj.nextLine().trim().toUpperCase().charAt(0);
        } while ((chrTranType != 'D') && (chrTranType != 'W'));
        
        float tranAmt = readlnFloat("Enter the transaction amount, 0 to cancel.");
        
        if (tranAmt == 0) {
            System.out.println(" 0 amount entered, transaction cancelled.");
            return 0;
        }

        if (chrTranType == 'W') {
            float newBal = myAcct.getAcctBal() - myAcct.getAcctBalPending() + myAcct.getOdLimit() - tranAmt;
            if (newBal < 0) {
                System.out.println(" Account [" + myAcct.getAcctNum() + "] has insufficient balance for the withdrawal/transfer, withdrawal cancelled.");
                return 0;
            }
        }
        if (booWithPin && (chrTranType == 'D')) {
            float newBal = pinAcct.getAcctBal() - pinAcct.getAcctBalPending() + pinAcct.getOdLimit() - tranAmt;
            if (newBal < 0) {
                System.out.println(" Account [" + pinAcct.getAcctNum() + "] has insufficient balance for the transfer, transaction cancelled.");
                return 0;
            }
        }        

        // myTrans = null;
        if (!booWithPin) {
            myTrans.add(new Tran(myAcct.getAcctNum(), 'C', " ", (chrTranType=='D')?tranAmt:(-tranAmt), 'F', 0));
        } else {
            myTrans.add(new Tran(myAcct.getAcctNum(), 'T', " ", chrTranType=='D'?tranAmt:(-tranAmt), 'F', 0));
            myTrans.add(new Tran(pinAcct.getAcctNum(), 'T', " ", chrTranType=='D'?(-tranAmt):tranAmt, 'F', 0));
        }

        System.out.println(strTranLbl);
        System.out.println(strTranUdl);
        myTrans.stream().forEach(System.out::println);
        Utility.printHeader();
        System.out.print(" About to create the above transactions, Y to confirm:");
        String resp = myObj.nextLine();
        if (resp.equalsIgnoreCase("Y")) {
            if (!booWithPin) {
                nxtAN = newCashTran(myTrans.get(0).getAcctNum(), myTrans.get(0).getTranAmt(), 0, " ");
                if (nxtAN > 0) {
                    System.out.println("Transactions created successfully.");
                } else {
                    System.out.println("Transactions creation failed.");
                }
            } else {
                nxtAN = newCashTran(myTrans.get(0).getAcctNum(), myTrans.get(0).getTranAmt(), myTrans.get(1).getAcctNum(), " ");
                if (nxtAN > 0) {
                    System.out.println("Transfer created successfully.");
                } else {
                    System.out.println("Transfer failed.");
                }
            }
        } else {
            System.out.println("Transactions creation aborted.");
        }
        printFooter();
        
        return 1;
    }
    
}
