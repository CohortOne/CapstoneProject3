/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import static customerapp.Main.menuLines;
import java.time.LocalDate;

/**
 *
 * @author chand
 */
public class Customer {
    private int custID;
    private String custName;
    private String nric;
    private String Addr1;
    private String Addr2;
    private LocalDate custDOB;
    private char custStts;
    private LocalDate dateCrea;
    private LocalDate dateUpd;
    public static final String strCustLbl = "ID     Name                          NRIC      Addr line 1                   Addr line 2                   DOB        Created    Updated    Active java used";
    public static final String strCustUdl = "====== ============================= ========= ============================= ============================= ========== ========== ========== ======";

    public Customer(int custID, String custName, String nric, String Addr1, String Addr2, LocalDate custDOB, char custStts, LocalDate dateCrea, LocalDate dateUpd) {
        this.custID = custID;
        this.custName = custName;
        this.nric = nric;
        this.Addr1 = Addr1;
        this.Addr2 = Addr2;
        this.custDOB = custDOB;
        this.custStts = custStts;
        this.dateCrea = dateCrea;
        this.dateUpd = dateUpd;
    }
    
    
    public Customer(String custName, String nric, String Addr1, String Addr2, LocalDate custDOB) {
        this.custName = custName;
        this.nric = nric;
        this.Addr1 = Addr1;
        this.Addr2 = Addr2;
        this.custDOB = custDOB;
    }

    public int getCustID() {
        return custID;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getNric() {
        return nric;
    }

    public void setNric(String nric) {
        this.nric = nric;
    }

    public String getAddr1() {
        return Addr1;
    }

    public void setAddr1(String Addr1) {
        this.Addr1 = Addr1;
    }

    public String getAddr2() {
        return Addr2;
    }

    public void setAddr2(String Addr2) {
        this.Addr2 = Addr2;
    }

    public LocalDate getCustDOB() {
        return custDOB;
    }

    public void setCustDOB(LocalDate custDOB) {
        this.custDOB = custDOB;
    }

    public char getCustStts() {
        return custStts;
    }

    public LocalDate getDateCrea() {
        return dateCrea;
    }

    public LocalDate getDateUpd() {
        return dateUpd;
    }
    
    @Override
    public String toString() {
        String returnStr = "";
        returnStr = returnStr + ((custID==0)?" ".repeat(7):Utility.fmtInt(custID,7)) + Utility.fmtString(custName,30)+ Utility.fmtString(nric,10) 
                              + Utility.fmtString(Addr1,30) + Utility.fmtString(Addr2,30) + custDOB + " "
                              + ((dateCrea==null)?" ".repeat(10):dateCrea) + " " + ((dateUpd==null)?" ".repeat(10):dateUpd) + " ";
        if (custStts == 'A') {
            returnStr = returnStr + ((menuLines.getString("FLDAC").length()>0)?menuLines.getString("FLDAC"):"Activ");
        } else {
            returnStr = returnStr + ((menuLines.getString("FLDDA").length()>0)?menuLines.getString("FLDDA"):"Deact");
        }
        
        return returnStr;       
    }
   
    
}
