/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import static customerapp.Utility.*;
import java.time.LocalDate;

/**
 *
 * @author deng
 */
public class Account {
    
    private int AcctNum;
    private char AcctType;
    private int CustId;
    private int CustIdJoint;
    private float AcctBal;
    private float AcctBalPending;
    private float AccrInt;
    private float OdLimit;
    private LocalDate DateOpen;
    private char AcctStts;
    private LocalDate DateUpd;
    public static final String strAcctLbl = " Acct Num Type    Account Holder                Joint Account Holder                  Acct Bal Pending Bal Accrued Int    OD Limit Date Open  Status  DateUpdate";
    public static final String strAcctUdl = " ======== ======= ============================= ============================= ================ =========== =========== =========== ========== ======= ==========";

    public Account(char AcctType, int CustId, int CustIdJoint, float OdLimit) {
        this.AcctType = AcctType;
        this.CustId = CustId;
        this.CustIdJoint = CustIdJoint;
        this.OdLimit = OdLimit;
    }

    public Account(int AcctNum, char AcctType, int CustId, int CustIdJoint, float AcctBal, float AcctBalPending, float AccrInt, float OdLimit, LocalDate DateOpen, char AcctStts, LocalDate DateUpd) {
        this.AcctNum = AcctNum;
        this.AcctType = AcctType;
        this.CustId = CustId;
        this.CustIdJoint = CustIdJoint;
        this.AcctBal = AcctBal;
        this.AcctBalPending = AcctBalPending;
        this.AccrInt = AccrInt;
        this.OdLimit = OdLimit;
        this.DateOpen = DateOpen;
        this.AcctStts = AcctStts;
        this.DateUpd = DateUpd;
    }

    
    
    public int getAcctNum() {
        return AcctNum;
    }

    public char getAcctType() {
        return AcctType;
    }

    public void setAcctType(char AcctType) {
        this.AcctType = AcctType;
    }

    public int getCustId() {
        return CustId;
    }

    public void setCustId(int CustId) {
        this.CustId = CustId;
    }

    public int getCustIdJoint() {
        return CustIdJoint;
    }

    public void setCustIdJoint(int CustIdJoint) {
        this.CustIdJoint = CustIdJoint;
    }

    public float getAcctBal() {
        return AcctBal;
    }

    public float getAcctBalPending() {
        return AcctBalPending;
    }

    public float getAccrInt() {
        return AccrInt;
    }

    public float getOdLimit() {
        return OdLimit;
    }

    public void setOdLimit(float OdLimit) {
        this.OdLimit = OdLimit;
    }

    public LocalDate getDateOpen() {
        return DateOpen;
    }

    public char getAcctStts() {
        return AcctStts;
    }

    public LocalDate getDateUpd() {
        return DateUpd;
    }

    @Override
    public String toString() {
        String strAcctStts;
        switch (AcctStts) {
            case 'O': strAcctStts = "Open   "; break;
            case 'S': strAcctStts = "Suspend"; break;
            case 'C': strAcctStts = "Closed "; break;
            default: strAcctStts  = "Unknown"; break;
        }
        String strCustName;
        try {strCustName = CustomerDAO.getCustomer(CustId).getCustName();}
        catch (Exception e) { strCustName = "***NOT FOUND***";}
        String strCustNameJoint;
        if (CustIdJoint ==0) {
            strCustNameJoint = "";
        } else{
            try {strCustNameJoint = CustomerDAO.getCustomer(CustIdJoint).getCustName();}
            catch (Exception e) { strCustNameJoint = "***NOT FOUND***";}
        }
        
        String returnStr = " " + (AcctNum==0?" ".repeat(9):fmtInt(AcctNum,9)) + (AcctType=='C'?"Current ":"Savings ") + fmtString(strCustName,30) + fmtString(strCustNameJoint,30) 
                + fmtFloat(AcctBal,-16,2) + fmtFloat(AcctBalPending,-12,2) + fmtFloat(AccrInt,-12,2) 
                + (AcctType=='C'?fmtFloat(OdLimit,-12,0):" ".repeat(12)) + " " 
                + (DateOpen==null?" ".repeat(10):DateOpen) + " " + strAcctStts + " " + (DateUpd==null?" ".repeat(10):DateUpd);
        return returnStr;       

    }
    
}

/*
Customer getCustomer(int cid)
*/