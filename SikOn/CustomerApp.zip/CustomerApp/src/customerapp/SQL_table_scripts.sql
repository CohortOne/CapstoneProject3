USE onebank;


DROP TABLE  IF EXISTS syscontrol;
CREATE TABLE syscontrol (
   Sysdate     date          NOT NULL PRIMARY KEY,
   CurrRec     char(1)       NOT NULL COMMENT 'A C means this is the current control record',
   BankName    varchar(45)   NOT NULL,
   SysStts     char(1)       NOT NULL,
   LastAcctNum decimal(10,0) NOT NULL,
   SaBal       decimal(15,2) NOT NULL,
   SaPendBal   decimal(15,2) NOT NULL,
   SaIntRate   decimal(9,6)  NOT NULL,
   SaMinBal    decimal(15,2) NOT NULL,
   CaBal       decimal(15,2) NOT NULL,
   CaPendBal   decimal(15,2) NOT NULL,
   CaOdIntRate decimal(9,6)  NOT NULL,
   ATMMinWD    decimal(15,2) NOT NULL,
   SysClock    datetime      NOT NULL
   );   


DROP TABLE sysjournal;

CREATE TABLE IF EXISTS sysjournal (
   Sysclock   datetime       NOT NULL,
   CustId     int            NOT NULL DEFAULT 0,
   AcctNum    decimal(10,0)  NOT NULL DEFAULT 0,
   TranId     int            NOT NULL DEFAULT 0,
   AtmCardNum varchar(16)    NOT NULL DEFAULT '',
   EventType  varchar(1)     NOT NULL,
   EventMsg   varchar(255)   NOT NULL DEFAULT '',
   Sysdate    date           NOT NULL
   );   

INSERT sysjournal
SELECT 
   Sysclock,
   IFNULL(CustId,0),
   IFNULL(AcctNum,0),
   IFNULL(TranId,0),
   IFNULL(AtmCardNum,' '),
   EventType,
   EventMsg,
   Sysdate
FROM sysjournal_bak;


DROP TABLE IF EXISTS customer;

CREATE TABLE customer (
   CustId    int         NOT NULL AUTO_INCREMENT PRIMARY KEY,
   CustName  varchar(45) NOT NULL,
   NRIC      varchar(9)  NOT NULL,
   Addr1     varchar(30) NOT NULL,
   Addr2     varchar(30) NOT NULL,
   CustDOB   date        NOT NULL,
   DateCrea  date        NOT NULL,
   CustStts  char(1)     NOT NULL DEFAULT 'A',
   DateUpd   date        NOT NULL COMMENT 'Date of last status change.'
);   


DROP TABLE IF EXISTS account;

CREATE TABLE account (
   AcctNum        decimal(10,0) PRIMARY KEY,
   AcctType       char(1)       NOT NULL,
   CustId         int           NOT NULL,
   CustIdJoint    int           NOT NULL  DEFAULT 0,
   AcctBal        decimal(15,2) NOT NULL,
   AcctBalPending decimal(15,2) NOT NULL  COMMENT 'portion of bal pending clearing',
   AccrInt        decimal(13,4) NOT NULL  COMMENT 'Interest accrued since start of month',
   OdLimit        decimal(15,2) NOT NULL,
   DateOpen       date          NOT NULL,
   AcctStts       char(1)       NOT NULL,
   DateUpd        date          NOT NULL  COMMENT 'Date of last status update'
);   

DROP TABLE IF EXISTS acctbalhist;

CREATE TABLE acctbalhist (
   AcctNum        decimal(10,0) PRIMARY KEY,
   DateSOM        DATE          NOT NULL,
   AcctBalSOM     decimal(15,2) NOT NULL  COMMENT 'Balance at start of month',
   AcctBalPendSOM decimal(15,2) NOT NULL  COMMENT 'Pending balance at start of month'
   
);   

DROP TABLE IF EXISTS tran;

CREATE TABLE tran (
   TranId   int           NOT NULL AUTO_INCREMENT PRIMARY KEY,
   AcctNum  decimal(10,0) NOT NULL,
   TranType varchar(1)    NOT NULL,
   TranDesc varchar(45)   NOT NULL DEFAULT ' ',
   TranAmt  decimal(15,2) NOT NULL,
   TranStts varchar(1)    NOT NULL,
   ChqNum   int           NOT NULL DEFAULT 0,
   TranDate date          NOT NULL,
   EffDate  date          NOT NULL,
   TranIdRel int          NOT NULL DEFAULT 0 COMMENT 'Related tran',
   SysClock datetime      NOT NULL
   );   


DROP TABLE systype;

CREATE TABLE systype (
   TypeName  varchar(15) NOT NULL,
   TypeVal   char(1)     NOT NULL,
   TypeDesc  varchar(45) NOT NULL
);   


INSERT systype
SELECT 
   TypeName,
   TypeVal,
   TypeDesc
FROM systype_bak;

INSERT systype SELECT  'CustStts',  'A', 'Active';
INSERT systype SELECT  'CustStts',  'D', 'Dormant';

INSERT systype SELECT  'AcctType',  'S', 'Savings';
INSERT systype SELECT  'AcctType',  'C', 'Current';

INSERT systype SELECT  'AcctStts',  'O', 'Open';
INSERT systype SELECT  'AcctStts',  'S', 'Suspended';
INSERT systype SELECT  'AcctStts',  'C', 'Closed';

INSERT systype SELECT  'TranType',  'C', 'Cash';
INSERT systype SELECT  'TranType',  'T', 'Fund transfer';
INSERT systype SELECT  'TranType',  'A', 'ATM cash';
INSERT systype SELECT  'TranType',  'Q', 'Cheque';
INSERT systype SELECT  'TranType',  'I', 'Interest';
INSERT systype SELECT  'TranType',  'D', 'OD interest';
INSERT systype SELECT  'TranType',  'F', 'Fee';
INSERT systype SELECT  'TranType',  'Z', 'Close account';

INSERT systype SELECT  'TranStts',  'I', 'In progress';
INSERT systype SELECT  'TranStts',  'F', 'Fully updated';

INSERT systype SELECT  'EventType', 'I', 'Insert';
INSERT systype SELECT  'EventType', 'U', 'Update';
