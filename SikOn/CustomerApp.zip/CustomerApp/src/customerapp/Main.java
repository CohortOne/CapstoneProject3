package customerapp;

import static customerapp.Customer_CRUD.*;
import static customerapp.Account_CRUD.*;
import static customerapp.Tran_CRUD.listTrans;
import static customerapp.Utility.*;
import java.io.IOException;
import java.util.Scanner;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.Formatter;
import java.util.logging.SimpleFormatter;
import java.util.logging.XMLFormatter;

public class Main {
    public static Customer pinCust;
    public static Account pinAcct;
    public static Scanner myObj = new Scanner(System.in);
    public static Locale myLocale;
    public static ResourceBundle menuLines;

    public static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    public static Handler fileHandler = null;
    public static Formatter messageFormatter = null;
    

    public static int mainMenu() {
        String strDivider = "*".repeat(30);
        String strPrintln;
        boolean booOK;
        int optionVal;
        
        do {
            booOK = false;
            printPinned();
            menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",myLocale);
            System.out.println(strDivider);
            System.out.println(menuLines.getString("M0M00").length()>0?menuLines.getString("M0M00"):" Main Menu");
            System.out.println(strDivider);
            System.out.println(menuLines.getString("M0M01").length()>0?menuLines.getString("M0M01"):"  1 Create new Customer");
            System.out.println(menuLines.getString("M0M02").length()>0?menuLines.getString("M0M02"):"  2 Customers Menu"); 
            System.out.println(menuLines.getString("M0M03").length()>0?menuLines.getString("M0M03"):"  3 Accounts Menu"); 
            System.out.println(menuLines.getString("M0M04").length()>0?menuLines.getString("M0M04"):"  4 Transactions Menu"); 
            System.out.println(strDivider);
            System.out.println(menuLines.getString("M0M08").length()>0?menuLines.getString("M0M08"):"  8 Switch Language"); 
            System.out.println(menuLines.getString("M0M99").length()>0?menuLines.getString("M0M99"):"  0 Exit"); 
            System.out.println(strDivider);
            strPrintln = menuLines.getString("M0MP0").length()>0?menuLines.getString("M0MP0"):" Enter menu option number:";
            optionVal = readlnInt(strPrintln);
            if (optionVal == 8) {
                System.out.println(myLocale.getLanguage());
                if ("en".equals(myLocale.getLanguage())) {
                    myLocale = new Locale("cn", "ZH");
                } else {
                    myLocale = new Locale("en", "UK");
                }
                continue;
            }

            if ((optionVal == 1) || (optionVal == 2) || (optionVal == 3) || (optionVal == 4) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(menuLines.getString("M0MP9").length()>0?menuLines.getString("M0MP9"):" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }

    private static void prepLogger() {
        
       try{
            LOGGER.setUseParentHandlers(false);

            //Creating fileHandler
            fileHandler  = new FileHandler("./javacodegeeks.log");
            
            //Assigning handlers to LOGGER object
            LOGGER.addHandler(fileHandler);
             
            //Setting levels to handlers and LOGGER
            // fileHandler.setLevel(Level.ALL);
            LOGGER.setLevel(Level.ALL);
            
            LOGGER.info("Finnest message: Logger with DEFAULT FORMATTER");

            messageFormatter = new SimpleFormatter();
            fileHandler.setFormatter(messageFormatter);
            LOGGER.info("Finnest message: Logger with SIMPLE FORMATTER");

            messageFormatter = new XMLFormatter();
            fileHandler.setFormatter(messageFormatter);
            LOGGER.info("Finnest message: Logger with XML FORMATTER");

            LOGGER.log(Level.INFO, "Logger Name: {0}", LOGGER.getName());
             
             
        }catch(IOException exception){
            LOGGER.log(Level.SEVERE, "Error occur in FileHandler.", exception);
        }
        LOGGER.config("Configuration done.");
    }
    
    public static void main(String[] args) throws Exception {

         
        prepLogger();
        
        LOGGER.info("Application started.");
        if (args.length >= 2) {
            myLocale = new Locale(args[0], args[1]);
            LOGGER.log(Level.INFO, "Language set to {0}-{1}", new Object[]{args[0], args[1]});
        } else {
            myLocale = new Locale("en", "UK");
            LOGGER.log(Level.INFO, "Language set to {0}-{1} by default due to absence of args.", new Object[]{args[0], args[1]});
        }
        int optionVal;
        do {
            optionVal = mainMenu();
            LOGGER.log(Level.INFO, "User selected from main menu the option {0}",new Object[]{optionVal});
            printHeader();
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {
                case 1:
                    System.out.println("Insert Customer  ");
                    printFooter();
                    insCust();
                    break;
                case 2:
                    System.out.println("List Customers ::: ");
                    listCusts(0);
                    break;
                case 3:
                    System.out.println("List Accounts ::: ");
                    listAccts(0, 0);
                    break;
                case 4:
                    System.out.println("List Transactions ::: ");
                    listTrans(0, 0);
                    break;
                case 0:
                    System.out.println("Exit");
                    printFooter();
                    LOGGER.log(Level.INFO, "Application terminated peacefully");
                    System.exit(0);
                    break;
            }
            printFooter();
            //System.out.print(" Press any key to continue.....");
            //myObj.nextLine();
        } while (optionVal != 99);
            
    }
    
}
/*   to restructure the program
package customerapp;
public class Main {
    insCustomer();
    listCustomers();
    listAccounts();




package customerapp;
public class Customer_CRUD {
    public static void delCustomers(Customer myCust) throws Exception {
  **      CustomerDAO.deactCustomer(myCust, strAD.charAt(0));

    public static int updCustomer(Customer myCust) throws Exception {
  **    CustomerDAO.updateCustomer(myCust);


****public static int listCustomers() throws Exception {
        myCustList = CustomerDAO.listCustomer();
        updCustomer(myCust);
        myCust = CustomerDAO.getCustomer(cid);
        delCustomers(myCust);
        myCust = CustomerDAO.getCustomer(cid);
        Accounts.listAccounts(cid);
        Accounts.newAccount(cid);

****public static int insCustomer() throws Exception {
  **      nxtID = CustomerDAO.insertCustomer(new Customer(name, nric, Addr1, Addr2, dateDOB));



package customerapp;
public class CustomerDAO {
**  public static int insertCustomer(Customer c)

**  public static boolean deactCustomer(Customer c, char chrAD)

    public static List <Customer> listCustomer()

    public static Customer getCustomer(int cid)

**  public static boolean updateCustomer(Customer c)



Main menu:
1. List customers --> Customer_CRUD.listCust;
2. Add customer --> Customer_CRUD.addCust;
3. List accounts --> Account_CRUD.listAcct



Customer_CRUD.listCust;
1. call CustomerDAO.listCustomer which returns a list of customers.
2. Present list to user, ask user to pick one for processing or 0 to exist.
3.  if user picks one, proceed to procCust(cid);

Customer_CRUD.addCust;
1. prompt users to input customer details,
2. instantiate customer, list and prompt user for confirmation
3. if user confirm, call CustomerDAO.addCustomer(cust).
4. if success, proceed to to procCust(cid); with the new cid.

Customer_CRUD.procCust(cid);
1. With a customer id on hand, retrieve and display customer, prompt user for opeartions:
2. if Update customer, call UpdCust(cid);
3. if act/deact customer, call andCust(cid);
4 .if Open account for this customer, call Account_CRUD.addAcct(cid) with this cid.
5. if List account for this customer, call Account_CRUD listAcct(cid) with this cid.

Customer_CRUD.updCust(cid);
1. Prompt users for customer details, update the Customer objects.
2. Once confirm, call CustomerDAO.updCustomer(cust);

Customer_CRUD.andCust(cid);
1. Prompt users to confirm activation/deactivation.
2. Once confirm, call CustomerDAO.updCustomer(cust,and);



CustomerDAO.listCustomer(cust);
1. prompt user for filtering criterias and pull from DB a list of customers.

CustomerDAO.addCustomer(cust);
1. Add the cust object to DB

CustomerDAO.updCustomer(cust);
1. update the cust object to DB

CustomerDAO.updCustomer(cust,and);
1. update the cust object to DB/act deact


Account_CRUD.addAcct(cid);
Account_CRUD.listAcct(cid);






*/