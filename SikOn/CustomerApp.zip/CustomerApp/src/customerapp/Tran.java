package customerapp;

import static customerapp.Utility.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Tran {
   private final int TranId;
   private final int AcctNum;
   private final char TranType;
   private final String TranDesc;
   private final float TranAmt;
   private final char TranStts;
   private final int ChqNum;
   private final LocalDate TranDate;
   private final LocalDate EffDate;
   private final int TranIdRel;
   private final LocalDateTime SysClock;
   public static final String strTranLbl = " Acct Num Account Holder Name           Tran Date  Type    Transaction descriptions          Debit        Credit Cheque TranId TrnRel Stts  Ending Acct Bal";
   public static final String strTranUdl = " ======== ============================= ========== ======= ========================= ============= ============= ====== ====== ====== ==== ================";

    public Tran(int TranId, int AcctNum, char TranType, String TranDesc, float TranAmt, char TranStts, int ChqNum, LocalDate TranDate, LocalDate EffDate, int TranIdRel, LocalDateTime SysClock) {
        this.TranId = TranId;
        this.AcctNum = AcctNum;
        this.TranType = TranType;
        this.TranDesc = TranDesc;
        this.TranAmt = TranAmt;
        this.TranStts = TranStts;
        this.ChqNum = ChqNum;
        this.TranDate = TranDate;
        this.EffDate = EffDate;
        this.TranIdRel = TranIdRel;
        this.SysClock = SysClock;
    }
    
    public Tran(int AcctNum, char TranType, String TranDesc, float TranAmt, char TranStts, int ChqNum) {
        this.TranId = 0;
        this.AcctNum = AcctNum;
        this.TranType = TranType;
        this.TranDesc = TranDesc;
        this.TranAmt = TranAmt;
        this.TranStts = TranStts;
        this.ChqNum = ChqNum;
        this.TranDate = null;
        this.EffDate = null;
        this.TranIdRel = 0;
        this.SysClock = null;
    }

    public int getTranId() {
        return TranId;
    }

    public int getAcctNum() {
        return AcctNum;
    }

    public char getTranType() {
        return TranType;
    }

    public String getTranDesc() {
        return TranDesc;
    }

    public float getTranAmt() {
        return TranAmt;
    }

    public char getTranStts() {
        return TranStts;
    }

    public int getChqNum() {
        return ChqNum;
    }

    public LocalDate getTranDate() {
        return TranDate;
    }

    public LocalDate getEffDate() {
        return EffDate;
    }

    public int getTranIdRel() {
        return TranIdRel;
    }

    public LocalDateTime getSysClock() {
        return SysClock;
    }

    @Override
    public String toString() {
        String strTranType;
        Account tmpAcct;
        Customer tmpCust;
        String custName;
        float balAcct;
        switch (TranType) {
            case 'C': strTranType = "Cash    "; break;
            case 'T': strTranType = "Xfer    "; break;
            default:  strTranType = "Unknown "; break;
        }
        
        try {tmpAcct = AccountDAO.getAccount(AcctNum);}
        catch (Exception e) {tmpAcct = null;}
        if (tmpAcct == null) {
            custName = "*** ACCOUNT NOT FOUND ***";
            balAcct = 0;
        } else {
            balAcct = tmpAcct.getAcctBal() - tmpAcct.getAcctBalPending();
            try {custName = CustomerDAO.getCustomer(tmpAcct.getCustId()).getCustName();}
            catch (Exception e) {custName = "*** CUSTOMER NOT FOUND ***";}
        }
        
        String returnStr = " " + fmtInt(AcctNum,9) + fmtString(custName,30);
        returnStr = returnStr.concat((TranDate==null?" ".repeat(10):TranDate) + " " + strTranType + fmtString(TranDesc,25));
        returnStr = returnStr.concat((TranAmt<0)?(fmtFloat(-TranAmt,-14,2)):(" ".repeat(14)));
        returnStr = returnStr.concat((TranAmt>0)?fmtFloat(TranAmt,-14,2):" ".repeat(14));
        returnStr = returnStr + " " + (ChqNum!=0?fmtInt(ChqNum,7):" ".repeat(7)) + (TranId!=0?fmtInt(TranId,7):" ".repeat(7));
        returnStr = returnStr.concat((TranIdRel==0)?" ".repeat(7):fmtInt(TranIdRel,7)) + TranStts;
        if (TranId == 0) {
            balAcct = balAcct + TranAmt;
            returnStr = returnStr.concat(fmtFloat(balAcct,-20,2));
        }
        
    return returnStr;       

    }
   
}
