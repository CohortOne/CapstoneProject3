package customerapp;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AccountDAO {

    public static int newAccount(Account acct) throws Exception{
        Connection conn = Utility.initConn();
        String qStmt = "{CALL newAccount('" + acct.getAcctType() + "'," + acct.getCustId() + "," + acct.getCustIdJoint() + ","
                     + acct.getOdLimit() + ")}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        int retnCode = 9999;
        String retnMsg = "";
        int acctNum = 0;
        
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            retnCode = rs.getInt("RetnCode");
            retnMsg = rs.getString("RetnMsg");
            acctNum = rs.getInt("AcctNum");
            break;
        }

        if (retnCode == 0) {
            System.out.println(" Insert Success ");
        }else {
            System.out.println("Insert Failed: " + retnMsg 
            + (acctNum>0?("(" + Integer.toString(acctNum) + ")"):""));
        }

        return acctNum;
                
    }

    
    
    public static void printStatement(int aid) throws Exception{
        Connection conn = Utility.initConn();
        String qStmt = "{CALL genAcctStmt(" + aid + ", 0)}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        int retnCode = 9999;
        String retnMsg = "";
        
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            retnCode = rs.getInt("RetnCode");
            retnMsg = rs.getString("RetnMsg");
            break;
        }

        if (retnCode != 0) {
            System.out.println(" Statement generation failed, " + retnMsg);
        }else {
            while(rs.next()){
                retnMsg = rs.getString("RetnMsg");
                System.out.println(retnMsg);
            }
        }
                
        
    }
    
    
    
    public static void updAccount(int AcctNum, char Action, int CustId, float intOdLimit) throws Exception{
        Connection conn = Utility.initConn();
        
        String qStmt = "{CALL updAccount(" + AcctNum + ",'" + Action + "', " + CustId + ", " + Math.round(intOdLimit) + ")}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        int retnCode = 9999;
        String retnMsg = "";
        int acctNum = 0;
        int custId = 0;
        
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            retnCode = rs.getInt("RetnCode");
            retnMsg = rs.getString("RetnMsg");
            acctNum = rs.getInt("AcctNum");
            custId = rs.getInt("CustId");
            break;
        }

        if (retnCode == 0) {
            System.out.println(" Insert Success ");
        }else {
            System.out.println("Insert Failed: " + retnMsg 
            + (acctNum>0?("(Acct:" + Integer.toString(acctNum) + ")"):"")
            + (custId>0?("(CustId:" + Integer.toString(custId) + ")"):""));
        }

        return;
                
    }
    
    
    
    

    public static List <Account> findAccount(int intAcctNum, int intCustId, int intCustIdJoint, String strSele, String strSort) throws Exception{
        List <Account> acctList = new ArrayList<>();

        Connection conn = Utility.initConn();
        String qStmt = "{CALL findAccount(" + intAcctNum + "," + intCustId + ",0,'" + strSele + "', '" + strSort + "')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
                acctList.add(new Account(rs.getInt("AcctNum"), rs.getString("AcctType").charAt(0), rs.getInt("CustId"), rs.getInt("CustIdJoint"),
                                         rs.getFloat("AcctBal"),rs.getFloat("AcctBalPending"),rs.getFloat("AccrInt"),rs.getFloat("OdLimit"),
                                         rs.getDate("DateOpen").toLocalDate(),rs.getString("AcctStts").charAt(0), rs.getDate("DateUpd").toLocalDate()));
        }
        return acctList;
    }  


    public static Account getAccount(int aid) throws Exception{
        Account myAcct = null;
        Connection conn = Utility.initConn();
        String qStmt = "{CALL findAccount(" + aid + ",0,0,'','')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();

        while(rs.next()){
            myAcct = new Account(rs.getInt("AcctNum"), rs.getString("AcctType").charAt(0), rs.getInt("CustId"), rs.getInt("CustIdJoint"),
                                         rs.getFloat("AcctBal"),rs.getFloat("AcctBalPending"),rs.getFloat("AccrInt"),rs.getFloat("OdLimit"),
                                         rs.getDate("DateOpen").toLocalDate(),rs.getString("AcctStts").charAt(0), rs.getDate("DateUpd").toLocalDate());
            break;
        }
        return myAcct;
        
    }
    
}


