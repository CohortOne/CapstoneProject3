/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;


import static customerapp.Main.*;
import static customerapp.CustomerDAO.*;
import static customerapp.Customer.*;
import static customerapp.Account_CRUD.*;
import static customerapp.Utility.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

public class Customer_CRUD {
    
    private static String captureNRIC(String strPrompt, boolean booMust) {
        String strNRIC;
        boolean booOK;
        do {
            booOK = true;
            System.out.print(strPrompt);
            strNRIC = myObj.nextLine().trim();
            if (strNRIC.length() == 0) {
                if (booMust) {
                    System.out.println("\t\t NRIC is mandatory.");
                    booOK = false;
                }
            } else {
                if (strNRIC.length() != 9) {
                    System.out.println("\t\t NRIC must be 9-char long, try again.");
                    booOK = false;
                }
            }
        } while (!booOK);
        return strNRIC;
    }    
    
    private static LocalDate captureDOB(String strPrompt, boolean booMust) {
        String strDOB;
        boolean booOK;
        LocalDate dateDOB = null;
        do {
            booOK = true;
            System.out.print(strPrompt);
            strDOB = myObj.nextLine().trim();
            if (strDOB.length() == 0) {
                dateDOB = null;
                if (booMust) {
                    System.out.println("\t\t DOB is mandatory, please enter again.");
                    booOK = false;
                }
            }
            else {
                try {
                    dateDOB = LocalDate.parse(strDOB, DateTimeFormatter.ISO_DATE);
                } catch (Exception e) {
                    System.out.println("\t\t Invalid date, try again.");
                    booOK = false;
                }
            }
        } while (!booOK);
        return dateDOB;
    }
    
    
    public static int custMenu() {
    String strDivider = "*".repeat(30);
    String strPrintln;
    boolean booOK;
    int optionVal;
        menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",myLocale);
        do {
            booOK = false;
            printPinned();
            System.out.println(strDivider);
            System.out.println(menuLines.getString("MCM00").length()>0?menuLines.getString("MCM00"):" Customer Menu");
            System.out.println(strDivider);
            System.out.println(menuLines.getString("MCM01").length()>0?menuLines.getString("MCM01"):"  1 List all Customers");
            System.out.println(menuLines.getString("MCM02").length()>0?menuLines.getString("MCM02"):"  2 Find by Name"); 
            System.out.println(menuLines.getString("MCM03").length()>0?menuLines.getString("MCM03"):"  3 Find by NRIC"); 
            System.out.println(menuLines.getString("MCM04").length()>0?menuLines.getString("MCM04"):"  4 Find by Customer Id"); 
            System.out.println(strDivider);
            System.out.println(menuLines.getString("MCM99").length()>0?menuLines.getString("MCM99"):"  0 Return"); 
            System.out.println(strDivider);
            strPrintln = menuLines.getString("MCMP0").length()>0?menuLines.getString("MCMP0"):" Enter menu option number:";
            optionVal = readlnInt(strPrintln);
            if ((optionVal == 1) || (optionVal == 2) || (optionVal == 3) || (optionVal == 4) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(menuLines.getString("MCMP9").length()>0?menuLines.getString("MCMP9"):" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
        
    public static int custSortMenu() {
    String strDivider = "*".repeat(30);
    String strPrintln;
    boolean booOK;
    int optionVal;
        menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",myLocale);
        do {
            booOK = false;
            printPinned();
            System.out.println(strDivider);
            System.out.println(menuLines.getString("MCS00").length()>0?menuLines.getString("MCS00"):" How do you want the list of Customers sorted:");
            System.out.println(strDivider);
            System.out.println(menuLines.getString("MCS01").length()>0?menuLines.getString("MCS01"):"  1 by Name");
            System.out.println(menuLines.getString("MCS02").length()>0?menuLines.getString("MCS02"):"  2 by Date of Birth"); 
            System.out.println(menuLines.getString("MCS03").length()>0?menuLines.getString("MCS03"):"  3 by Customer Id"); 
            System.out.println(strDivider);
            strPrintln = menuLines.getString("MCSP0").length()>0?menuLines.getString("MCSP0"):" Enter menu option number:";
            optionVal = readlnInt(strPrintln);
            if ((optionVal == 1) || (optionVal == 2) || (optionVal == 3)) {
                booOK = true;
            }
            else {
                System.out.println(menuLines.getString("MCSP9").length()>0?menuLines.getString("MCSP9"):" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
    
    
    public static int custActiontMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("*********************************************************************************** ");
            System.out.println("********* Customer Action Menu ");
            System.out.println("*********************************************************************************** ");
            System.out.println("*********  1 Update Customer");
            System.out.println("*********  2 Activate/Deactivate Customer");
            System.out.println("*********  3 Work with Accounts held by this customer"); 
            System.out.println("*********  4 Open new account for this customer");
            System.out.println("*********  5 Take-over Principal ownership of pinned Account");
            System.out.println("*********  6 Become Joint holder of pinned Account");
            System.out.println("*********  8 Pin this Customer");
            System.out.println("********* 21 Work with Pinned Customer");
            System.out.println("*********  0 Return");
            System.out.println("*********************************************************************************** ");
            optionVal = readlnInt(" Enter a number to carry out the operation:");
            if ((optionVal >= 1) && (optionVal <= 5) || (optionVal == 6) || (optionVal == 8) || (optionVal == 21) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
    
        } while (!booOK);
        return optionVal;
    }

    public static int listCusts(int cid) throws Exception { // return 0 if called with cid but failed to find any Cust to process, otherwise return 1
    String strName = "";
    String strNRIC = "";
    int intCustId = 0;
    int optSort;
    int optVal;
    List <Customer> myCustList = new ArrayList<>();
    Customer myCust = null;

        if (cid != 0) {
            myCust = getCustomer(cid);
            if (myCust == null) {
                System.out.println(" No customer found with Customer Id=" + cid + ".");
                pause4Enter();
                return 0;
            }
            myCustList.add(myCust);
        }
        
        do { // this loop will run once only if cid is not 0, otherwise loop until user decides to exit method
            int cidFound;
            do { 
                cidFound = 0;
                while (myCustList.isEmpty()) {
                    optVal = custMenu();
                    if (optVal == 0) {return 1;}

                    strName = "";
                    if (optVal == 2) {
                        do {
                            System.out.print(" Enter Customer name, or a pattern using % and _ to filter:");
                            strName = myObj.nextLine().trim();
                            if (strName.equals("")) {System.out.print(" Blank not allowed.");}
                                } while (0 == strName.length());
                                strName = strName.replaceAll("\"", "");
                                strName = strName.replaceAll("\'", "");
                            }

                    strNRIC = "";
                    if (optVal == 3) {strNRIC = captureNRIC(" Enter NRIC of the Customer name:", true);}

                    intCustId = 0;
                    if (optVal == 4) {intCustId = readlnInt(" Enter CustID, 0 to list all :   ");}

                    myCustList = findCustomer(intCustId, strNRIC, strName, " ");
                    if (myCustList.isEmpty()) {
                        System.out.println(" No customer found matching the criteria, try again.");
                    }
                }

                if (myCustList.size() == 1 ) {
                    myCust = myCustList.get(0);
                    cidFound = myCust.getCustID();
                } else {
                    optSort = custSortMenu();
                    String strPrompt = " Pick a customer to operate on by entering the Customer Id, 0 to exit:";
                    do {
                        int cidSele = 0;
                        printHeader();
                        if (optSort == 1) {System.out.println("Sorting by Customer Name:");}
                        if (optSort == 2) {System.out.println("Sorting by Date of Birth:");}
                        if (optSort == 3) {System.out.println("Sorting by Customer Id:");}
                        // System.out.println(strCustLbl);
                        System.out.println(menuLines.getString("HDRC0").length()>0?menuLines.getString("HDRC0"):Customer.strCustLbl);
                        System.out.println(strCustUdl);
                        if (optSort == 1) {myCustList.stream().sorted((c1, c2) -> c1.getCustName().compareTo(c2.getCustName())).forEach(System.out::println);}
                        if (optSort == 2) {myCustList.stream().sorted((c1, c2) -> c1.getCustDOB().compareTo(c2.getCustDOB())).forEach(System.out::println);}
                        if (optSort == 3) {myCustList.stream().sorted((c1, c2) -> c1.getCustID()-(c2.getCustID())).forEach(System.out::println);}
                        System.out.println(strCustUdl);

                        cidSele = readlnInt(strPrompt);
                        if (cidSele == 0) {
                            break;
                        }

                        Iterator<Customer> myIterator = myCustList.iterator();
                        while (myIterator.hasNext()) {
                            myCust = myIterator.next();
                            if (myCust.getCustID() == cidSele) {
                                cidFound = cidSele;
                                break;
                            }
                        }
                        // myCust = myCustList.stream().filter((c) -> c.getCustID() == cidTmp).findFirst().get();

                        if (cidFound == 0) {
                            strPrompt =" No customer found with customer ID=" + cidSele + ", pick again, or 0 to exit...";
                            continue;
                        }
                    } while (cidFound == 0);
                }
                myCustList.clear();
            } while ((cidFound == 0) && (cid == 0));
            
            optVal = 1;
            while ((optVal != 0) && (myCust != null)) do {
                myCust = CustomerDAO.getCustomer(myCust.getCustID());
                printHeader();
                // System.out.println(strCustLbl);
                System.out.println(menuLines.getString("HDRC0").length()>0?menuLines.getString("HDRC0"):Customer.strCustLbl);
                System.out.println(strCustUdl);
                System.out.println(myCust.toString());
                System.out.println(strCustUdl);
                optVal = custActiontMenu();

                if (optVal == 1) {
                    updCust(myCust);
                }

                if (optVal == 2) {
                    andCust(myCust);
                }

                if (optVal == 3) {
                    listAccts(0, myCust.getCustID());
                }

                if (optVal == 4) {
                    insAcct(myCust);
                }

                if (optVal == 5) {
                    if (pinAcct == null) {
                        System.out.println("There is no pinned Account.");
                    } else {
                        if (pinAcct.getCustId() == myCust.getCustID()) {
                            System.out.println("This Customer is already the principal owner of the Pinned Account.");
                        } else {
                            updAcct(pinAcct,'C', myCust.getCustID());
                            pinAcct = AccountDAO.getAccount(pinAcct.getAcctNum());
                        }
                    }
                }

                if (optVal == 6) {
                    if (pinAcct == null) {
                        System.out.println("There is no pinned Account.");
                    } else {
                        if (pinAcct.getCustIdJoint() == myCust.getCustID()) {
                            System.out.println("This Customer is already the Joint holder of the Pinned Account.");
                        } else {
                            updAcct(pinAcct,'J',myCust.getCustID());
                        }
                    }
                }

                if (optVal == 8) {
                    pinCust = myCust;
                    optVal = 0;
                }

                if (optVal == 21) {
                    if (pinCust == null) {
                        System.out.println("There is no pinned Customer.");
                    } else {
                        if (pinCust.getCustID() == myCust.getCustID()) {
                            System.out.println("This Customer is the same as the Pinned Customer.");
                        } else {
                            myCust = pinCust;
                        }
                    }
                }
            } while (optVal != 0);
            myCustList.clear();
        } while (cid == 0); // cid is incoming method argument.  This means, if cid is supplied with a non-zero value, this loop runs only one.
        return 1;
    }


    public static void andCust(Customer myCust) throws Exception {
        System.out.print(" Do you want to Activate or Deactivate (A/D):");
        String strAD = myObj.nextLine().toUpperCase();
        if (!((strAD.equals("A")) || (strAD.equals("D")))) {
            System.out.println(" Invalid option entered ::" + strAD);
            return;
        }
        System.out.print(" Enter Y to confirm:");
        String resp = myObj.nextLine();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating activation/deactivation for Customer Id=" + myCust.getCustID());
            printHeader();
            andCustomer(myCust, strAD.charAt(0));
            printFooter();
        }
    }

    public static int updCust(Customer myCust) throws Exception {
        Boolean booOK = false;
        Boolean booChanged = false;
        
        System.out.println(" Starting update for Customer Id=" + myCust.getCustID());
        printHeader();
        System.out.println(myCust);
        printFooter();

        System.out.println(" Current Name:" + myCust.getCustName());
        System.out.print("     New Name:");
        String name = myObj.nextLine().trim();
        if (name.length() > 45) {
            name = name.substring(0,45);
            System.out.println(" Name too long, truncated to '" + name + "'.");
        }
        if (name.length() == 0) {
            System.out.println(" Blank name entered, current value will be used.");
        } else {
            if (name.equals(myCust.getCustName())) {
                System.out.println(" Name entered is the same as current.");
            } else {
                booChanged = true;
                myCust.setCustName(name);
            }
        }

        String nric = captureNRIC(" Current NRIC:" + myCust.getNric() + "\n     New NRIC:", false);
        if (nric.length() == 0) {
            System.out.println(" Blank NRIC entered, current will be used.");
        }
        else {
            if (nric.equals(myCust.getNric())) {
                System.out.println(" NRIC entered is the same as current.");
            } else {
                booChanged = true;
                myCust.setNric(nric);
            }
        }
        
        String Addr1;
        System.out.println(" Current Addr line 1:" + myCust.getAddr1());
        System.out.print("     New Addr line 1:");
        Addr1 = myObj.nextLine().trim();
        if (Addr1.length() == 0) {
            System.out.println(" Blank address entered, taken as per current.");
        }
        if (Addr1.length() > 30) {
            Addr1 = Addr1.substring(0,30);
            System.out.println(" Address line too long, truncated to '" + Addr1 + "'.");
        }
        if (Addr1.length() > 0) {
            if (Addr1.equals(myCust.getAddr1())) {
                System.out.println(" Address line 1 entered is the same as current.");
            } else {
                booChanged = true;
                myCust.setAddr1(Addr1);
            }
        }
        
        String Addr2;
        System.out.println(" Current Addr line 2:" + myCust.getAddr2());
        System.out.print("     New Addr line 2:");
        Addr2 = myObj.nextLine().trim();
        if (Addr2.length() == 0) {
            System.out.println(" Blank address entered, taken as per current.");
        }
        if (Addr2.length() > 30) {
            Addr2 = Addr2.substring(0,30);
            System.out.println(" Address line too long, truncated to '" + Addr2 + "'.");
        }
        if (Addr2.length() > 0) {
            if (Addr2.equals(myCust.getAddr2())) {
                System.out.println(" Address line 2 entered is the same as current.");
            } else {
                booChanged = true;
                myCust.setAddr2(Addr2);
            }
        }

        LocalDate dateDOB = captureDOB(" Current DOB:" + myCust.getCustDOB() + "\n     New DOB:", false);
        if (dateDOB == null) {
            System.out.println(" Blank entered, DOB taken as per current.");
        }
        else {
            if (dateDOB == myCust.getCustDOB()) {
                System.out.println(" DOB entered is the same as current.");
            } else {
                booChanged = true;
                myCust.setCustDOB(dateDOB);
            }
        }

        if (booChanged) {
            printHeader();
            // System.out.println(strCustLbl);
            System.out.println(menuLines.getString("HDRC0").length()>0?menuLines.getString("HDRC0"):Customer.strCustLbl);
            System.out.println(strCustUdl);
            System.out.println(myCust);
            printHeader();
            System.out.print(" About to update this Customer, Y to confirm:");
            String resp = myObj.nextLine();
            if (resp.equalsIgnoreCase("Y")) {
                updCustomer(myCust);
            } else {
                System.out.println("Customer update aborted.");
            }
        }
        else {
            System.out.println("Nothing has changed.");
        }
        printFooter();
        return 1;
    }

    public static int insCust() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        int nxtID;
        Boolean booOK;
        System.out.println(" Enter details to create new customer:");
        printFooter();
        
        System.out.print(" Name:");
        String name = myObj.nextLine().trim();
        if (name.length() == 0) {
            System.out.println(" Blank name entered, taken as you want to quit, bye.");
            return 0;
        }
        if (name.length() > 45) {
            name = name.substring(0,45);
            System.out.println(" Name too long, truncated to [" + name + "].");
        }

        String nric = captureNRIC(" NRIC:", true);

        LocalDate dateDOB = captureDOB(" Date Of Birth:", true);

        String Addr1;
        do {
            System.out.print(" Addr line 1:");
            Addr1 = myObj.nextLine().trim();
            booOK = true;
            if (Addr1.length() == 0) {
                System.out.println(" Blank address line not allowed, input again.");
                booOK = false;
            }
            if (Addr1.length() > 30) {
                Addr1 = Addr1.substring(0,30);
                System.out.println(" Address line too long, truncated to [" + Addr1 + "].");
            }
        } while (!booOK);

        String Addr2;
        do {
            System.out.print(" Addr line 2:");
            Addr2 = myObj.nextLine();
            booOK = true;
            if (Addr2.length() == 0) {
                System.out.println(" Blank address line not allowed, input again.");
                booOK = false;
            }
            if (Addr2.length() > 30) {
                Addr2 = Addr2.substring(0,30);
                System.out.println(" Address line too long, truncated to [" + Addr2 + "].");
            }
        } while (!booOK);

        printHeader();
        Customer thisCust = new Customer(name, nric, Addr1, Addr2, dateDOB);
        //System.out.println(strCustLbl);
        System.out.println(menuLines.getString("HDRC0").length()>0?menuLines.getString("HDRC0"):Customer.strCustLbl);
        System.out.println(strCustUdl);
        System.out.println(thisCust);
        printHeader();
        System.out.print(" About to create this Customer, Y to confirm:");
        String resp = myObj.nextLine();
        if (resp.equalsIgnoreCase("Y")) {
            nxtID = newCustomer(thisCust);
            if (nxtID > 0) {
                System.out.println("Customer created successfully with Customer Id=" + nxtID + ".");
            } else {
                System.out.println("Customer creation failed.");
            }
        } else {
            System.out.println("Customer creation aborted.");
        }
        printFooter();
        
        return 1;
    }

    
}

