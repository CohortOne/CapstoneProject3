package onebank;

import static onebank.Main.menuLines;
import java.time.LocalDate;

public class Customer {
    private int custId;
    private String custName;
    private String nric;
    private String addr1;
    private String addr2;
    private LocalDate custDOB;
    private char custStts;
    private LocalDate dateCrea;
    private LocalDate dateUpd;
    public static final String strCustLbl = "ID     Name                          NRIC      Addr line 1                   Addr line 2                   DOB        Created    Updated    Active java used";
    public static final String strCustUdl = "====== ============================= ========= ============================= ============================= ========== ========== ========== ======";

    public Customer(int custId, String custName, String nric, String addr1, String addr2, LocalDate custDOB, char custStts, LocalDate dateCrea, LocalDate dateUpd) {
        this.custId = custId;
        this.custName = custName;
        this.nric = nric;
        this.addr1 = addr1;
        this.addr2 = addr2;
        this.custDOB = custDOB;
        this.custStts = custStts;
        this.dateCrea = dateCrea;
        this.dateUpd = dateUpd;
    }
    
    
    public Customer(String custName, String nric, String addr1, String addr2, LocalDate custDOB) {
        this.custName = custName;
        this.nric = nric;
        this.addr1 = addr1;
        this.addr2 = addr2;
        this.custDOB = custDOB;
    }

    public int getCustId() {
        return custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getNric() {
        return nric;
    }

    public void setNric(String nric) {
        this.nric = nric;
    }

    public String getAddr1() {
        return addr1;
    }

    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

    public String getAddr2() {
        return addr2;
    }

    public void setAddr2(String addr2) {
        this.addr2 = addr2;
    }

    public LocalDate getCustDOB() {
        return custDOB;
    }

    public void setCustDOB(LocalDate custDOB) {
        this.custDOB = custDOB;
    }

    public char getCustStts() {
        return custStts;
    }

    public String getCustSttsLong() {
        switch (custStts) {
            case ('A'): return ((menuLines.getString("FLDAC").length()>0)?menuLines.getString("FLDAC"):"Active");
            case ('D'): return ((menuLines.getString("FLDDA").length()>0)?menuLines.getString("FLDDA"):"Dormant");
            default: return ((menuLines.getString("FLDAC").length()>0)?menuLines.getString("FLDUK"):"Unknown");
        }
    }

    public LocalDate getDateCrea() {
        return dateCrea;
    }

    public LocalDate getDateUpd() {
        return dateUpd;
    }
    
    @Override
    public String toString() {
        String returnStr = "";
        returnStr = returnStr + ((custId==0)?" ".repeat(7):Utility.fmtInt(custId,7)) + Utility.fmtString(custName,30)+ Utility.fmtString(nric,10) 
                              + Utility.fmtString(addr1,30) + Utility.fmtString(addr2,30) + custDOB + " "
                              + ((dateCrea==null)?" ".repeat(10):dateCrea) + " " + ((dateUpd==null)?" ".repeat(10):dateUpd) + " " + getCustSttsLong();
        
        return returnStr;       
    }
   
    
}
