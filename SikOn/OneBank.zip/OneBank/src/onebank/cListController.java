package onebank;
import java.net.URL;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;

public class cListController implements Initializable {

    @FXML
    private TableView<Customer> cListTbl;
    @FXML
    private TableColumn<Customer, Integer> custId;
    @FXML
    private TableColumn<Customer, String> custName;
    @FXML
    private TableColumn<Customer, String> nric;
    @FXML
    private TableColumn<Customer, String> addr1;
    @FXML
    private TableColumn<Customer, String> addr2;
    @FXML
    private TableColumn<Customer, LocalDate> custDOB;
    @FXML
    private TableColumn<Customer, String> custStts;
    @FXML
    private TableColumn<Customer, LocalDate> dateCrea;
    @FXML
    private TableColumn<Customer, LocalDate> dateUpd;
    
      

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        
    }
    public  void init() {

        Main.menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",Main.myLocale);
          custId.setText(Main.menuLines.getString("FXMBL1").length()>0?Main.menuLines.getString("FXMBL1"):"Cust Id");
        custName.setText(Main.menuLines.getString("FXMBL2").length()>0?Main.menuLines.getString("FXMBL2"):"Name");
            nric.setText(Main.menuLines.getString("FXMBL3").length()>0?Main.menuLines.getString("FXMBL3"):"NRIC");
         custDOB.setText(Main.menuLines.getString("FXMBL4").length()>0?Main.menuLines.getString("FXMBL4"):"DOB");
           addr1.setText(Main.menuLines.getString("FXMBL5").length()>0?Main.menuLines.getString("FXMBL5"):"Address Line 1");
           addr2.setText(Main.menuLines.getString("FXMBL6").length()>0?Main.menuLines.getString("FXMBL6"):"Address Line 2");
        dateCrea.setText(Main.menuLines.getString("FXMBL7").length()>0?Main.menuLines.getString("FXMBL7"):"Created");
         dateUpd.setText(Main.menuLines.getString("FXMBL8").length()>0?Main.menuLines.getString("FXMBL8"):"Updated");
        custStts.setText(Main.menuLines.getString("FXMBL9").length()>0?Main.menuLines.getString("FXMBL9"):"Status");
        
         try {
            
            cListTbl.setStyle("-fx-alignment: CENTER-LEFT;");
            custId.setCellValueFactory(new PropertyValueFactory<Customer, Integer>("custId"));
            custName.setCellValueFactory(new PropertyValueFactory<Customer, String>("custName"));
            nric.setCellValueFactory(new PropertyValueFactory<Customer, String>("nric"));
            addr1.setCellValueFactory(new PropertyValueFactory<Customer, String>("addr1"));
            addr2.setCellValueFactory(new PropertyValueFactory<Customer, String>("addr2"));
            custDOB.setCellValueFactory(new PropertyValueFactory<Customer, LocalDate>("custDOB"));
            custStts.setCellValueFactory(new PropertyValueFactory<Customer, String>("custSttsLong"));
            dateCrea.setCellValueFactory(new PropertyValueFactory<Customer, LocalDate>("dateCrea"));
            dateUpd.setCellValueFactory(new PropertyValueFactory<Customer, LocalDate>("dateUpd"));
            
            cListTbl.setItems(CustomerDAO.listCustomers());
          
        }catch(Exception e){
            System.out.println(" Exception in CustomerListFXML Controller " + e.getMessage());
            e.printStackTrace();
        }
         
    }    

    public static void loadItems() {
        Utility.showDialog("here I am", "what to do?");
    }
}

