USE onebank;

DROP PROCEDURE IF EXISTS maintSysControl;

DELIMITER //

CREATE PROCEDURE maintSysControl(IN i_Action      char,  -- C=create first, R=list curernt, W=update current, L=list all, 
                                 IN i_Sysdate     varchar(8),
                                 IN i_BankName    varchar(45),
                                 IN i_LastAcctNum decimal(10,0),
                                 IN i_SaIntRate   decimal(9,6),
                                 IN i_SaMinBal    decimal(15,2),
                                 IN i_CaOdIntRate decimal(9,6),
                                 IN i_ATMMinWD    decimal(15,2))
BEGIN
    DECLARE c_Sysdate     date DEFAULT 0;
    DECLARE c_RowCnt      int  DEFAULT 0;
    DECLARE c_ErrCnt      int  DEFAULT 0;

    SELECT COUNT(*) INTO c_RowCnt FROM syscontrol;
    SELECT STR_TO_DATE(i_Sysdate, '%Y%m%d') INTO c_Sysdate;
	IF c_Sysdate = STR_TO_DATE('00000000', '%Y%m%d') THEN
       SET c_Sysdate = CURDATE();
    END IF;

    DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg(RetnCode int, RetnMsg varchar(255));
    
    -- create the first control record if table is empty
    IF ((i_Action = 'C') OR (i_Action = 'W')) THEN
	    BEGIN
    		IF i_BankName = ' ' THEN
                INSERT retnmsg SELECT 3001, 'Bank name must not be blank.';
		    END IF;
	        IF i_LastAcctNum < 0 THEN
                INSERT retnmsg SELECT 3002, 'Last accout number must be 0 or higher.';
		    END IF;
	        IF i_SaIntRate < 0 THEN
                INSERT retnmsg SELECT 3003, 'SA interet rate cannot be negative.';
		    END IF;
   	        IF i_SaMinBal < 0 THEN
                INSERT retnmsg SELECT 3004, 'SA minimum balance cannot be negative.';
	    	END IF;
		    IF i_CaOdIntRate <= 0 THEN
                INSERT retnmsg SELECT 3005, 'CA OD interest must be positive.';
		    END IF;
		    IF i_ATMMinWD < 10 THEN
                INSERT retnmsg SELECT 3006, 'ATM minimum withdrwal SA must be 10 or in multiple of 10s.';
		    END IF;
		END;
	END IF;

    IF ((i_Action = 'C') AND ISNULL(c_Sysdate)) THEN
        INSERT retnmsg SELECT 2004, 'Sysdate in argument is not a valid date, use 00000000 for CURDATE().';
	END IF;
    IF ((i_Action <> 'C') AND (i_Action <> 'R') AND (i_Action <> 'W') AND (i_Action <> 'L')) THEN
        INSERT retnmsg SELECT 2001, 'Invalid action code.';
	END IF;
    IF (c_RowCnt = 0 AND i_Action <> 'C') THEN
        INSERT retnmsg SELECT 2002, 'Syscontrol table is empty, use action code C to create the initial record.';
    END IF;
    IF (c_RowCnt > 0 AND i_Action = 'C') THEN
        INSERT retnmsg SELECT 2003, 'Syscontrol table is not empty, cannot create initial record.';
    END IF;

    SELECT COUNT(*) INTO c_ErrCnt FROM retnmsg;
	IF c_ErrCnt = 0 THEN
	    BEGIN
        	IF (i_Action = 'C') THEN
	            BEGIN
                    INSERT syscontrol 
		            SELECT c_Sysdate, 'C' ,i_BankName, 'A', i_LastAcctNum, 
                           0, 0,     i_SaIntRate,          i_SaMinBal,
                           0, 0,     i_CaOdIntRate,        i_ATMMinWD,
			               NOW();
       	            INSERT retnmsg SELECT 0000, 'Control record inserted successfully.';
				    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
				END;
			ELSEIF (i_Action = 'W') THEN
				BEGIN
					UPDATE syscontrol
    	               SET BankName    = i_BankName,
			               LastAcctNum = i_LastAcctNum, 
		                   SaIntRate   = i_SaIntRate,
			               SaMinBal    = i_SaMinBal,
       	                   CaOdIntRate = i_CaOdIntRate,
			               ATMMinWD    = i_ATMMinWD,
			               SysClock    = NOW()
                     WHERE CurrRec = 'C';
	                INSERT retnmsg SELECT 0000, 'Control record updated successfully.';
				    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
    	        END;
			ELSE
				SELECT Sysdate,       CurrRec,     BankName,    SysStts,
					   LastAcctNum,   SaBal,       SaPendBal,   SaIntRate,
					   SaMinBal,      CaBal,       CaPendBal,   CaOdIntRate,
					   ATMMinWD,      SysClock
					   SysClock
				  FROM syscontrol
				 WHERE CurrRec = 'C' OR i_Action = 'L'
				 ORDER BY SysDate;
			END IF;
	    END;
	ELSE
	    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
    END IF;
   	DROP TEMPORARY TABLE retnmsg;
END //


CALL maintSysControl('C', '00000000', 'SG United One Bank', 21000001, 2.5, 50.0, 10.0, 20.0);




DROP PROCEDURE IF EXISTS newCustomer;

DELIMITER //

CREATE PROCEDURE newCustomer(i_CustName varchar(45), i_NRIC varchar(9), 
                             i_Addr1 varchar(30), i_Addr2 varchar(30), 
							 i_CustDOB date)
BEGIN
    DECLARE c_Sysdate     date DEFAULT 0;
    DECLARE c_CustId      int  DEFAULT 0;
    DECLARE c_ErrCnt      int  DEFAULT 0;

    SELECT Sysdate INTO c_Sysdate FROM syscontrol WHERE CurrRec = 'C';
    SELECT CustId  INTO C_CustId  FROM customer   WHERE NRIC = i_NRIC;

    DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg(RetnCode int, RetnMsg varchar(255), CustId int);
    IF i_NRIC = ' ' THEN
        INSERT retnmsg SELECT 2001, 'NRIC must not be blank.', 0;
    END IF;
   	IF C_CustId > 0 THEN
         INSERT retnmsg SELECT 2003, 'Customer with the NRIC already exists.', C_CustId;
    END IF;
    IF i_CustName = ' ' THEN
        INSERT retnmsg SELECT 2004, 'Customer name must not be blank.', 0;
    END IF;
    IF (i_Addr1 = ' ' OR i_Addr2 = ' ') THEN
        INSERT retnmsg SELECT 2005, 'Address line 1 AND 2 must not be blank.', 0;
    END IF;
    IF (((DATEDIFF(c_Sysdate, i_CustDOB) / 365.25) < 12 ) OR
            ((DATEDIFF(c_Sysdate, i_CustDOB) / 365.25) > 120)) THEN
        INSERT retnmsg SELECT 2006, 'Customer age must be between 12 and 120 years old.', 0;
    END IF;
    SELECT COUNT(*) INTO C_ErrCnt FROM retnmsg;
	IF C_ErrCnt = 0 THEN
        BEGIN
        -- validation success, create customer record.
	        INSERT INTO customer(CustName,   NRIC,   Addr1,   Addr2,
                                 CustDOB,    DateCrea,     CustStts,   DateUpd)
                          VALUES(i_CustName, i_NRIC, i_Addr1, i_Addr2,
		                         i_CustDOB,  c_Sysdate,    'A',         c_Sysdate);
            SELECT CustId INTO C_CustId FROM customer WHERE NRIC = i_NRIC;
	        INSERT INTO sysjournal(Sysclock, CustId,  EventType, Sysdate,
                                   EventMsg)
                            VALUES(NOW(),    C_CustId, 'I',       c_Sysdate,
	        	                   'Customer record created.');
            INSERT retnmsg SELECT 0000, 'Customer record successfully created.', C_CustId;
        END;
	END IF;
    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
	DROP TEMPORARY TABLE retnmsg;
END//



DROP PROCEDURE IF EXISTS updCustomer;

DELIMITER //

CREATE PROCEDURE updCustomer(i_CustId int, i_Action char, 
                             i_CustName varchar(45), i_NRIC varchar(9), 
                             i_Addr1 varchar(30), i_Addr2 varchar(30), i_CustDOB date)
BEGIN
    DECLARE c_Sysdate  date    DEFAULT 0;
    DECLARE c_CustId   int     DEFAULT 0;
    DECLARE c_CustStts char(1) DEFAULT 0;
    DECLARE c_CustCnt  int     DEFAULT 0;
    DECLARE c_ErrCnt   int     DEFAULT 0;

    SELECT Sysdate INTO c_Sysdate FROM syscontrol WHERE CurrRec = 'C';

	DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg(RetnCode int, RetnMsg varchar(255), CustId int);

    SET c_CustId = 0;
    SELECT   CustId,   CustStts
	  INTO c_CustId, c_CustStts
	  FROM customer   WHERE CustId = i_CustId;
    IF c_CustId = 0 THEN
        INSERT retnmsg SELECT 2002, 'Customer with the CustId does not exist.', i_CustId;
    END IF;

    IF i_Action = 'U' THEN
        BEGIN
            IF i_NRIC = ' ' THEN
                INSERT retnmsg SELECT 2001, 'NRIC must not be blank.', 0;
            END IF;
        
            SET c_CustId = 0;
            SELECT CustId  INTO c_CustId  FROM customer   WHERE CustId <> i_CustId AND NRIC = i_NRIC;
       	    IF c_CustId > 0 THEN
                 INSERT retnmsg SELECT 2003, 'There is another customer with the same NRIC.', c_CustId;
            END IF;
    	    
            IF i_CustName = ' ' THEN
                INSERT retnmsg SELECT 2004, 'Customer name must not be blank.', 0;
            END IF;
    	    
            IF (i_Addr1 = ' ' OR i_Addr2 = ' ') THEN
                INSERT retnmsg SELECT 2005, 'Address line 1 AND 2 must not be blank.', 0;
            END IF;
    	    
            IF (((DATEDIFF(c_Sysdate, i_CustDOB) / 365.25) < 12 ) OR
                    ((DATEDIFF(c_Sysdate, i_CustDOB) / 365.25) > 120)) THEN
                INSERT retnmsg SELECT 2006, 'Customer age must be between 12 and 120 years old.', 0;
            END IF;
			
			SELECT COUNT(*) INTO c_CustCnt
	          FROM customer
	         WHERE CustId   = i_CustId AND
	               CustName = i_CustName AND
		           NRIC     = i_NRIC    AND
		           Addr1    = i_Addr1   AND
		           Addr2    = i_Addr2   AND
		           CustDOB  = i_CustDOB;
   	        IF c_CustCnt > 0 THEN
                INSERT retnmsg SELECT 2007, 'Supplied customer details are same as in database, no change applied.', i_CustId;
            END IF;
        END;
    ELSEIF  i_Action = 'D' THEN
	    BEGIN
    	    IF c_CustStts <> 'A' THEN
                INSERT retnmsg SELECT 2011, 'Customer is not active.', 0;
            END IF;
		END;
    ELSEIF  i_Action = 'A' THEN
	    BEGIN
    	    IF c_CustStts <> 'D' THEN
                INSERT retnmsg SELECT 2011, 'Customer is not inactive.', 0;
            END IF;
		END;
    ELSE
        INSERT retnmsg SELECT 2099, 'Invalid action code.', 0;
	END IF;
	
    SELECT COUNT(*) INTO c_ErrCnt FROM retnmsg;
	IF c_ErrCnt = 0 THEN
        BEGIN
        -- validation success, update customer record.
		    IF i_Action = 'U' THEN
    	        UPDATE customer
	    		   SET CustName = i_CustName,
		    	       NRIC     = i_NRIC,
			    	   Addr1    = i_Addr1,
				       Addr2    = i_Addr2,
				       CustDOB  = i_CustDOB
		         WHERE CustId = i_CustId;
		    ELSEIF (i_Action = 'A') OR (i_Action = 'D') THEN
    	        UPDATE customer
			       SET CustStts = i_Action,
			           DateUpd  = c_Sysdate
		         WHERE CustId = i_CustId;
            END IF;
	        INSERT INTO sysjournal(Sysclock, CustId,  EventType, Sysdate,
                                   EventMsg)
                            VALUES(NOW(),    c_CustId, i_Action,   c_Sysdate,
	        	                   'Customer record updated.');
            INSERT retnmsg SELECT 0000, 'Customer record successfully updated.', c_CustId;
        END;
	END IF;
    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
	DROP TEMPORARY TABLE retnmsg;
END//





DROP PROCEDURE IF EXISTS findCustomer;

DELIMITER //

CREATE PROCEDURE findCustomer(i_CustId int, i_NRIC varchar(9), i_CustName varchar(45), i_Sort char(1))
BEGIN
    DROP TEMPORARY TABLE IF EXISTS custlist;
    CREATE TEMPORARY TABLE custlist(CustId int);

    IF (i_CustId > 0) THEN
	   INSERT custlist SELECT CustId FROM customer WHERE CustId = i_CustId;
	ELSEIF (IFNULL(i_NRIC,'') <>  '') THEN
	   INSERT custlist SELECT CustId FROM customer WHERE NRIC = i_NRIC;
	ELSE
	   INSERT custlist SELECT CustId FROM customer WHERE (CustName LIKE i_CustName) OR (IFNULL(i_CustName,'') = '');
	END IF;

	DROP TEMPORARY TABLE IF EXISTS temp_customer;
	CREATE TEMPORARY TABLE temp_customer
        SELECT * FROM customer
         WHERE CustId IN (SELECT CustId FROM custlist);

    DROP TEMPORARY TABLE custlist;
    
    IF (i_Sort = 'N') THEN
	    SELECT CustId, CustName, NRIC, Addr1, Addr2, CustDOB, DateCrea, CustStts, DateUpd 
          FROM temp_customer ORDER BY CustName, CustId;
	ELSEIF (i_Sort = 'B') THEN
	    SELECT CustId, CustName, NRIC, Addr1, Addr2, CustDOB, DateCrea, CustStts, DateUpd
          FROM temp_customer ORDER BY CustDOB, CustName, CustId;
	ELSEIF (i_Sort = 'I') THEN
	    SELECT CustId, CustName, NRIC, Addr1, Addr2, CustDOB, DateCrea, CustStts, DateUpd
          FROM temp_customer ORDER BY NRIC;
	ELSE
	    SELECT CustId, CustName, NRIC, Addr1, Addr2, CustDOB, DateCrea, CustStts, DateUpd
          FROM temp_customer ORDER BY CustId;
	END IF;

    DROP TEMPORARY TABLE temp_customer;
	
END//






DROP FUNCTION IF EXISTS getNextAcctNum;

DELIMITER //

CREATE FUNCTION getNextAcctNum() RETURNS decimal(10,0) DETERMINISTIC
BEGIN
    DECLARE c_Sysdate date DEFAULT 0;
    DECLARE c_LastAcctNum decimal(10,0) DEFAULT 0;
    DECLARE c_AcctCnt int DEFAULT 0;
    SELECT Sysdate, LastAcctNum INTO c_Sysdate, c_LastAcctNum FROM syscontrol WHERE CurrRec = 'C';
	label: LOOP
        SET c_LastAcctNum = c_LastAcctNum  + 1;
        SELECT COUNT(*) INTO c_AcctCnt FROM account where AcctNum = c_LastAcctNum;
        IF c_AcctCnt = 0 THEN LEAVE label;
        END IF;
    END LOOP;
	UPDATE syscontrol SET LastAcctNum = c_LastAcctNum WHERE CurrRec = 'C';
    RETURN c_LastAcctNum;
END //







DROP PROCEDURE IF EXISTS newAccount;

DELIMITER //

CREATE PROCEDURE newAccount(i_AcctType char(1), i_CustId int, i_CustIdJoint int, i_OdLimit decimal(15,2))
BEGIN
    DECLARE c_Sysdate     date DEFAULT 0;
    DECLARE c_CustId      int  DEFAULT 0;
    DECLARE c_CustIdJoint int  DEFAULT 0;
    DECLARE c_AcctNum     decimal(10,0) DEFAULT 0;
    DECLARE c_ErrCnt      int  DEFAULT 0;
    
    SELECT Sysdate INTO c_Sysdate      FROM syscontrol WHERE CurrRec = 'C';
    SELECT CustId  INTO c_CustId       FROM customer   WHERE CustId = i_CustId;
    SELECT CustId  INTO c_CustIdJoint  FROM customer   WHERE CustId = i_CustIdJoint;

    DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg(RetnCode int, RetnMsg varchar(255), AcctNum decimal(10,0));
    
    IF IFNULL(c_CustId,0) = 0 THEN
        INSERT retnmsg SELECT 2001, 'Invalid CustId.', i_CustId;
	ELSEIF i_CustId = i_CustIdJoint THEN
        INSERT retnmsg SELECT 2002, 'Joint CustId cannot be the same as CustId.', i_CustIdJoint;
   	ELSEIF ((i_CustIdJoint > 0) AND (IFNULL(c_CustIdJoint,0) = 0)) THEN
        INSERT retnmsg SELECT 2003, 'Invalid Joint Custid.', i_CustIdJoint;
	END IF;
    IF ((i_AcctType <> 'S') AND (i_AcctType <> 'C')) THEN
        INSERT retnmsg SELECT 2004, 'Invalid Account type, only S and C allowed.', 0;
	END IF;
    IF ((i_AcctType = 'S') AND (i_OdLimit <> 0)) THEN
        INSERT retnmsg SELECT 2005, 'OD limit is not allowed for savings account.', 0;
	END IF;
    IF ((i_AcctType = 'C') AND (i_OdLimit < 0)) THEN
        INSERT retnmsg SELECT 2006, 'OD limit cannot be negative.', 0;
	END IF;

    SELECT COUNT(*) INTO c_ErrCnt FROM retnmsg;
	IF c_ErrCnt = 0 THEN
	    BEGIN
		    SELECT getNextAcctNum() INTO c_AcctNum;
	        INSERT INTO account(AcctNum,   AcctType,       CustId,   CustIdJoint,
                                AcctBal,   AcctBalPending, AccrInt,  OdLimit,
                                DateOpen,  AcctStts,       DateUpd)
                         VALUES(c_AcctNum, i_AcctType,     i_CustId, i_CustIdJoint,
				                0,         0,              0,        i_OdLimit,
		                        c_Sysdate, 'O',            c_Sysdate);
	        INSERT INTO acctbalhist(AcctNum,    DateSOM, 
			                        AcctBalSOM, AcctBalPendSOM)
                             VALUES(c_AcctNum,  c_Sysdate,
                                    0,          0);
	        INSERT INTO sysjournal(Sysclock, CustId,   AcctNum,   EventType, Sysdate,
                                   EventMsg)
                            VALUES(NOW(),    c_CustId, c_AcctNum, 'I',       c_Sysdate,
	        	                   'Account created.');
            INSERT retnmsg SELECT 0000, 'Account successfully created.', c_AcctNum;
		END;
	END IF;
    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
	DROP TEMPORARY TABLE retnmsg;
	
END//





DROP PROCEDURE IF EXISTS updAccount;

DELIMITER //

CREATE PROCEDURE updAccount(i_AcctNum decimal(10,0), i_Action char, i_CustId int,  OdLimit decimal(15,2))
							 
BEGIN
    DECLARE c_Sysdate     date    DEFAULT 0;
    DECLARE c_CustId      int     DEFAULT 0;
    DECLARE c_CustIdJoint int     DEFAULT 0;
    DECLARE c_AcctType    char(1) DEFAULT 0;
    DECLARE c_AcctStts    char(1) DEFAULT 0;
    DECLARE c_AcctCnt     int     DEFAULT 0;
    DECLARE c_ErrCnt      int     DEFAULT 0;
    DECLARE c_RecCnt      int     DEFAULT 0;
    DECLARE c_AcctNum     decimal(10,0) DEFAULT 0;
    DECLARE c_OdLimit     decimal(15,0) DEFAULT 0;

    SELECT Sysdate INTO c_Sysdate FROM syscontrol WHERE CurrRec = 'C';

	DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg(RetnCode int, RetnMsg varchar(255), AcctNum decimal(10,0), CustId int);

    SET c_AcctNum = 0;
    SELECT   AcctNum,   AcctType,   AcctStts,   CustId,   CustIdJoint,   OdLimit
	  INTO c_AcctNum, c_ACctType, c_AcctStts, c_CustId, c_CustIdJoint, c_OdLimit
	  FROM Account   WHERE AcctNum = i_AcctNum;
    IF c_AcctNum = 0 THEN
        INSERT retnmsg SELECT 2001, 'Account with the AcctNum does not exist.', i_AcctNum, 0;
    END IF;

    IF i_Action = 'C' THEN -- change principal CustId
        BEGIN
		    IF ((i_CustId = 0) OR (i_CustId = c_CustId)) THEN
                INSERT retnmsg SELECT 2002, 'No new CustId is provided, update by passed.', i_AcctNum, 0;
			END IF;
		    IF (i_CustId <> c_CustId) THEN
	            BEGIN
                    SET c_RecCnt = 0;
		            SELECT COUNT(*) INTO c_RecCnt FROM customer WHERE CustId = i_CustId AND CustStts = 'A';
			        IF (c_RecCnt = 0) THEN
                        INSERT retnmsg SELECT 2003, 'New CustId not found or not an active customer.', 0, i_CustId;
    			    END IF;
				END;
			END IF;
        END;
    ELSEIF i_Action = 'J' THEN  -- change joint CustId
	    BEGIN
    		IF (i_CustId = c_CustIdJoint) THEN
                INSERT retnmsg SELECT 2004, 'Joint CustId supplied is the same, update bypassed.', i_AcctNum, i_CustId;
    		ELSEIF (i_CustId > 0) THEN
	            BEGIN
                    SET c_RecCnt = 0;
		            SELECT COUNT(*) INTO c_RecCnt FROM customer WHERE CustId = i_CustId AND CustStts = 'A';
   			        IF (c_RecCnt = 0) THEN
                        INSERT retnmsg SELECT 2005, 'New Joint CustId not found or not an active customer, update bypassed.', i_AcctNum, i_CustId;
    			    END IF;
		   	    END;
			END IF;
		END;
    ELSEIF i_Action = 'L' THEN  -- change OdLimit
	    BEGIN
    		IF (i_AcctType <> 'C') THEN
                INSERT retnmsg SELECT 2006, 'OD Limit can only be changed for Current accounts.', i_AcctNum, 0;
			END IF;
    		IF (i_OdLimit = c_OdLimit) THEN
                INSERT retnmsg SELECT 2007, 'Same OD Limit on database.', i_AcctNum, 0;
			END IF;
		END;
	ELSE
        INSERT retnmsg SELECT 2099, 'Invalid action code.', i_AcctNum, 0;
	END IF;
	
    SELECT COUNT(*) INTO c_ErrCnt FROM retnmsg;
	IF c_ErrCnt = 0 THEN
        BEGIN
        -- validation success, update Account record.
		    IF i_Action = 'C' THEN
				UPDATE Account
				   SET CustId   = i_CustId,
					   DateUpd  = c_Sysdate
				 WHERE AcctNum = i_AcctNum;
		    ELSEIF (i_Action = 'J') THEN
				UPDATE Account
				   SET CustIdJoint = i_CustId,
					   DateUpd     = c_Sysdate
				 WHERE AcctNum = i_AcctNum;
		    ELSEIF (i_Action = 'L') THEN
				UPDATE Account
				   SET OdLimit = i_OdLimit,
					   DateUpd = c_Sysdate
				 WHERE AcctNum = i_AcctNum;
            END IF;
			INSERT INTO sysjournal(Sysclock,   CustId,   AcctNum,   EventType, Sysdate,
								   EventMsg)
							VALUES(NOW(),    i_CustId, i_AcctNum, i_Action,  c_Sysdate,
								   '[updAccount] Account record updated.');
            INSERT retnmsg SELECT 0000, 'Account record successfully updated.', c_AcctNum, c_CustId;
        END;
	END IF;
    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
	DROP TEMPORARY TABLE retnmsg;
END//




DROP PROCEDURE IF EXISTS findAccount;

DELIMITER //

CREATE PROCEDURE findAccount(i_AcctNum decimal(10,0), i_CustId int, i_CustIdJoint int, i_Sele char(1), i_Sort char(1))
BEGIN
    DECLARE c_DateSOM date default 0;
    SELECT Sysdate INTO c_DateSOM FROM syscontrol WHERE CurrRec = 'C';
	SET c_DateSOM = DATE_SUB(c_DateSOM,INTERVAL (DAY(c_DateSOM) -1) DAY);
	
	SET i_Sele = IFNULL(i_Sele,'');
	SET i_Sort = IFNULL(i_Sort,'');
    DROP TEMPORARY TABLE IF EXISTS acctlist;
    CREATE TEMPORARY TABLE acctlist(AcctNum decimal(10,0));

    IF (i_AcctNum > 0) THEN
	   INSERT acctlist SELECT AcctNum FROM account WHERE AcctNum = i_AcctNum;
	ELSEIF (i_CustId > 0) THEN
	   BEGIN
	        IF (i_Sele =  'P') THEN
	            INSERT acctlist SELECT AcctNum FROM account WHERE CustId = i_CustId;
		    ELSEIF (i_Sele =  'J') THEN
	            INSERT acctlist SELECT AcctNum FROM account WHERE CustIdJoint = i_CustId;
		    ELSE
	            INSERT acctlist SELECT AcctNum FROM account WHERE CustId = i_CustId OR CustIdJoint = i_CustId;
			END IF;
	   END;
	ELSEIF (i_CustIdJoint > 0) THEN
	   INSERT acctlist SELECT AcctNum FROM account WHERE CustIdJoint = i_CustIdJoint;
	ELSEIF ((i_Sele = 'S') OR (i_Sele = 'C')) THEN  -- savings or current accounts still opened
	   INSERT acctlist SELECT AcctNum FROM account WHERE AcctType = i_Sele AND AcctStts = 'O';
	ELSEIF (i_Sele = 'J') THEN  -- Joints account (when both of the i_CustIds are 0)
	   INSERT acctlist SELECT AcctNum FROM account WHERE CustIdJoint > 0;
	ELSEIF (i_Sele = '') THEN
	   INSERT acctlist SELECT AcctNum FROM account;
	ELSEIF (i_Sele = 'O') THEN  -- accounts in OD
	   INSERT acctlist SELECT AcctNum FROM account WHERE AcctBal - AcctBalPending < 0;
	ELSEIF (i_Sele = 'Z') THEN  -- accounts closed
	   INSERT acctlist SELECT AcctNum FROM account WHERE AcctStts = 'C';
	ELSEIF (i_Sele = 'M') THEN  -- accounts closed this month
	   INSERT acctlist SELECT AcctNum FROM account WHERE AcctStts ='C' AND (DATEDIFF(DateUpd, c_DateSOM) >= 0) ;
	END IF;   
	
	
	DROP TEMPORARY TABLE IF EXISTS temp_account;
	CREATE TEMPORARY TABLE temp_account
        SELECT * FROM account
         WHERE AcctNum IN (SELECT AcctNum FROM acctlist);

    DROP TEMPORARY TABLE acctlist;

    IF (i_Sort = 'C') THEN
	    SELECT AcctNum, AcctType, CustId, CustIdJoint, AcctBal, AcctBalPending, AccrInt, OdLimit, DateOpen, DateUpd, AcctStts
   		  FROM temp_account ORDER BY CustId;
	ELSEIF (i_Sort = 'B') THEN
	    SELECT AcctNum, AcctType, CustId, CustIdJoint, AcctBal, AcctBalPending, AccrInt, OdLimit, DateOpen, DateUpd, AcctStts
   		  FROM temp_account ORDER BY AcctBal, AcctNum;
	ELSE
	    SELECT AcctNum, AcctType, CustId, CustIdJoint, AcctBal, AcctBalPending, AccrInt, OdLimit, DateOpen, DateUpd, AcctStts
   		  FROM temp_account ORDER BY AcctNum;
	END IF;

    DROP TEMPORARY TABLE temp_account;

END//







DROP PROCEDURE IF EXISTS genAcctStmt;

DELIMITER //

CREATE PROCEDURE genAcctStmt(i_AcctNum decimal(10,0), i_MthOffset int)
BEGIN
    DECLARE c_Sysdate  DATE;
    DECLARE c_DateSOM  DATE;
    DECLARE c_BankName varchar(45);

    DECLARE c_CustName  varchar(45);
    DECLARE c_Addr1     varchar(30);
    DECLARE c_Addr2     varchar(30);
    DECLARE c_CustNameJ varchar(45);

    DECLARE c_AcctType       char(1);
    DECLARE c_CustId         int;
    DECLARE c_CustIdJoint    int;
    DECLARE c_AcctBal        decimal(15,2);
    DECLARE c_AcctBalPending decimal(15,2);
    DECLARE c_AccrInt        decimal(13,4);
    DECLARE c_OdLimit        decimal(15,2);
    DECLARE c_DateOpen       date;
    DECLARE c_AcctStts       char(1);

    DECLARE c_TranId         int;
    DECLARE c_TranType       char(1);
    DECLARE c_TranDesc       varchar(45);
    DECLARE c_TranAmt        decimal(15,2);
    DECLARE c_TranStts       char(1);
    DECLARE c_ChqNum         int;
    DECLARE c_TranDate       date;
    DECLARE c_EffDate        date;
    DECLARE c_TranIdRel      int;

	DECLARE c_AcctBalSOM     decimal(15,2);
	DECLARE c_AcctBalPendSOM decimal(15,2);
    DECLARE c_LongStr        varchar(45);
    DECLARE c_RptLine        varchar(255);
    DECLARE c_AcctTypeTxt    varchar(8);
    DECLARE c_TranTypeTxt    varchar(8);
	DECLARE c_RecCnt  INT;
    DECLARE c_RunningBal     decimal(15,2);
	DECLARE c_finished INT;
	DECLARE c_LineCnt  INT;
    DECLARE CsrTran CURSOR FOR SELECT TranId, TranType, TranDesc, TranAmt, TranStts, ChqNum, TranDate, EffDate, TranIdRel 
	                             FROM tran
							    WHERE AcctNum = i_AcctNum
								  AND TranDate >= c_DateSOM
								  AND TranDate <= c_Sysdate
								ORDER BY TranDate, TranId;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET c_finished = 1;
	
    DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg (RetnCode int, RetnMsg varchar(255), TranId int, AcctNum decimal(10,0), CustId int);

    SELECT   Sysdate,   BankName
      INTO c_Sysdate, c_BankName
	  FROM syscontrol WHERE CurrRec ='C';
	SET c_DateSOM = DATE_SUB(c_Sysdate,INTERVAL (DAY(c_Sysdate) - 1) DAY);

    IF (i_AcctNum <= 0) THEN
        INSERT retnmsg SELECT 2001, 'Please specify Account Number to generate statement.', 0, 0, 0;
    ELSE
	    BEGIN
			SELECT COUNT(*) INTO c_RecCnt FROM account WHERE AcctNum = i_AcctNum;
			IF (c_RecCnt = 0) THEN
				INSERT retnmsg SELECT 2002, 'Account not found with provided account number.', 0, i_AcctNum, 0;
			END IF;
		END;
	END IF;

    SET c_LongStr = "                                             ";
    SELECT COUNT(*) INTO c_RecCnt FROM retnmsg;
	IF c_RecCnt = 0 THEN
		BEGIN
			SELECT   AcctType,   CustId,   CustIdJoint,   AcctBal,   AcctBalPending,   AccrInt,   OdLimit,   DateOpen,   AcctStts
			  INTO c_AcctType, c_CustId, c_CustIdJoint, c_AcctBal, c_AcctBalPending, c_AccrInt, c_OdLimit, c_DateOpen, c_AcctStts
			  FROM account
			 WHERE AcctNum = i_AcctNum;
			SELECT   CustName,   Addr1,   Addr2
              INTO c_CustName, c_Addr1, c_Addr2
			  FROM customer
			 WHERE CustId = c_CustId;
			IF c_CustIdJoint = 0 THEN
			    SET c_CustNameJ = ' ';
			ELSE
			    SELECT CustName INTO  c_CustNameJ
    			  FROM customer
				 WHERE CustId = c_CustIdJoint;
			END IF;
			SELECT   DateSOM,   AcctBalSOM,   AcctBalPendSOM
			  INTO c_DateSOM, c_AcctBalSOM, c_AcctBalPendSOM
			  FROM acctbalhist
			 WHERE AcctNum = i_AcctNum  AND
			       DateSOM >= c_DateSOM AND
			       DateSOM <= c_Sysdate;
				   
			INSERT retnmsg SELECT 0001, c_BankName,
			                                   1, 0, 0;
			INSERT retnmsg SELECT 0001, CONCAT("STATEMENT OF ACCOUNT", SUBSTR(c_LongStr,1,34), "Statement Date: ",c_Sysdate),
			                                   2, 0, 0;
			SET c_AcctTypeTxt = "Others";
			SELECT TypeDesc INTO c_AcctTypeTxt FROM systype WHERE TypeName = "AcctType" AND Typeval = c_AcctType;
			SET c_AcctTypeTxt = SUBSTRING(CONCAT(c_AcctTypeTxt,c_LongStr),1,7);
											   
			IF c_AcctType = "C" THEN SET c_AcctTypeTxt = "Current"; ELSE SET c_AcctTypeTxt = "Savings"; END IF;
			INSERT retnmsg SELECT 0001, CONCAT("Account Number:",
											   SUBSTRING(CONCAT(10000000000 + i_AcctNum),2,2),"-",
											   SUBSTRING(CONCAT(10000000000 + i_AcctNum),4,4),"-",
											   SUBSTRING(CONCAT(10000000000 + i_AcctNum),8,4),
											   SUBSTR(c_LongStr,1,29), "Account type: ", c_AcctTypeTxt),
											   3,0,0;
			INSERT retnmsg SELECT 0001, CONCAT(SUBSTRING(CONCAT(c_CustName,c_LongStr),1,45), SUBSTR(c_LongStr,1,8), "Current Balance:",
			                                   SUBSTRING(CONCAT(c_LongStr,FORMAT(c_AcctBal,2)),-15)),
											   4, 0, 0;
			INSERT retnmsg SELECT 0001, CONCAT(SUBSTRING(CONCAT(c_CustNameJ,c_LongStr),1,45),SUBSTR(c_LongStr,1,6), "Available Balance:",
			                                   SUBSTRING(CONCAT(c_LongStr,FORMAT(c_AcctBal - c_AcctBalPending,2)),-15)),
											   5, 0, 0;
			SET c_RptLine = SUBSTRING(CONCAT(c_Addr1,c_LongStr),1,30);
			IF c_OdLimit > 0 THEN
			    SET c_RptLine = CONCAT(c_RptLine,SUBSTR(c_LongStr,23), "OD Limit: ", SUBSTRING(CONCAT(c_LongStr,FORMAT(c_OdLimit,0)),-12));
			END IF;
			INSERT retnmsg SELECT 0001, c_RptLine,
											   6, 0, 0;
			SET c_RptLine = SUBSTRING(CONCAT(c_Addr2,c_LongStr),1,30);
			IF (c_OdLimit > 0) AND (c_AcctBal - c_AcctBalPending < 0) THEN
			    SET c_RptLine = CONCAT(c_RptLine,SUBSTR(c_LongStr,1,13), "Available Limit: ",
                                       SUBSTRING(CONCAT(c_LongStr,FORMAT(c_OdLimit + c_AcctBal - c_AcctBalPending,2)),-14));
			END IF;

			INSERT retnmsg SELECT 0001, c_RptLine,
											   7, 0, 0;
			INSERT retnmsg SELECT 0001, " ",   8, 0, 0;
			INSERT retnmsg SELECT 0001, "DATE 	     Description               Type             Debit        Credit       Balance TranId TrnRel",
											   9, 0, 0;
			INSERT retnmsg SELECT 0001, "---------- ------------------------- -------- ------------- ------------- ------------- ------ ------",
											  10, 0, 0;
			INSERT retnmsg SELECT 0001, CONCAT(c_DateSOM, " Balance B/F", SUBSTR(c_LongStr,1,25), SUBSTR(c_LongStr,1,24), SUBSTRING(CONCAT(c_LongStr,FORMAT(c_AcctBalSOM,2)),-15)),
											  11, 0, 0;

            SET c_LineCnt = 12, c_finished = 0, c_RunningBal = c_AcctBalSOM;
			OPEN CsrTran;
			getTran: LOOP
				FETCH CsrTran INTO c_TranId, c_TranType, c_TranDesc, c_TranAmt, c_TranStts, c_ChqNum, c_TranDate, c_EffDate, c_TranIdRel;
				IF c_finished = 1 THEN 
					LEAVE getTran;
				END IF;
                SET c_RunningBal = c_RunningBal  + c_TranAmt;
				CASE c_TranType 
					WHEN "A" THEN SET c_TranTypeTxt = "ATM";
					WHEN "C" THEN SET c_TranTypeTxt = "Cash";
					WHEN "Q" THEN SET c_TranTypeTxt = "Cheque";
					WHEN "I" THEN SET c_TranTypeTxt = "Interest";
					WHEN "D" THEN SET c_TranTypeTxt = "OD Int";
					WHEN "F" THEN SET c_TranTypeTxt = "Fee";
					WHEN "Z" THEN SET c_TranTypeTxt = "Close ac";
                    ELSE          SET c_TranTypeTxt = "Others";
				END CASE;
				SET c_TranTypeTxt = SUBSTRING(CONCAT(c_TranTypeTxt,c_LongStr),1,8);
				SET c_RptLine = CONCAT(c_TranDate, " ", SUBSTRING(CONCAT(c_TranDesc,c_LongStr),1,26), c_TranTypeTxt);
				IF (c_TranAmt < 0) THEN
					SET c_RptLine = CONCAT(c_RptLine, SUBSTRING(CONCAT(c_LongStr,FORMAT(-c_TranAmt,2)),-14), SUBSTR(c_LongStr,1, 14));
				ELSE
					SET c_RptLine = CONCAT(c_RptLine, SUBSTR(c_LongStr,1,14), SUBSTRING(CONCAT(c_LongStr,FORMAT(c_TranAmt,2)),-14));
				END IF;
				SET c_RptLine = CONCAT(c_RptLine, SUBSTRING(CONCAT(c_LongStr,FORMAT(c_RunningBal,2)),-14), " ",
				                                  SUBSTRING(CONCAT(c_TranId,c_LongStr),1,7));
				IF (c_TranIdRel > 0) THEN
					SET c_RptLine = CONCAT(c_RptLine, SUBSTRING(CONCAT(c_TranIdRel,c_LongStr),1,7));
				END IF;
				INSERT retnmsg SELECT 0001, c_RptLine,
												   c_LineCnt, 0, 0;
				SET c_LineCnt = c_LineCnt  + 1;
			END LOOP getTran;
			CLOSE CsrTran;
			INSERT retnmsg SELECT 0001, CONCAT(c_Sysdate, " Closing Balance", SUBSTR(c_LongStr,26), SUBSTR(c_LongStr,1,26), 
                                               SUBSTRING(CONCAT(c_LongStr,FORMAT(c_RunningBal,2)),-15)),
											  c_LineCnt, 0, 0;
			INSERT retnmsg SELECT 0001, "---------- ------------------------- -------- ------------- ------------- ------------- ------ ------",
											  c_LineCnt + 1, 0, 0;
			INSERT retnmsg SELECT 0001, "*** END OF STATEMENT ***",
											  c_LineCnt + 2, 0, 0;
			INSERT retnmsg SELECT 0000, "Statement generation completed successfully.",
											  0, 0, 0;
		END;
	END IF;

    SELECT * FROM retnmsg ORDER BY RetnCode ASC, TranId ASC;
	DROP TEMPORARY TABLE retnmsg;

END//







DROP PROCEDURE IF EXISTS postAccrual;

DELIMITER //

CREATE PROCEDURE postAccrual(i_AcctNum decimal(10,0))
BEGIN
    DECLARE c_Sysdate  date    DEFAULT 0;
    DECLARE c_TranType char(1) DEFAULT ' ';
    DECLARE c_finished int DEFAULT 0;
    DECLARE c_AcctNum decimal(10,0) DEFAULT 0;
    DECLARE c_AccrInt decimal(15,2) DEFAULT 0;
    DECLARE CsrAcct CURSOR FOR SELECT AcctNum, ROUND(AccrInt,2)
                                 FROM account
								WHERE AccrInt <> 0
							      AND ((AcctNum = i_AcctNum) OR (i_AcctNum = 0))
								ORDER BY AcctNum;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET c_finished = 1;
    SELECT Sysdate INTO c_Sysdate FROM syscontrol WHERE CurRec = 'C';

	OPEN CsrAcct;
    getAcct: LOOP
        FETCH CsrAcct INTO c_AcctNum, c_AccrInt;
        IF c_finished = 1 THEN 
			LEAVE getAcct;
		END IF;
        IF (c_AccrInt > 0) THEN
            SET c_TranType = 'I';
        ELSE
            SET c_TranType = 'D';
		END IF;
	    INSERT INTO tran(AcctNum,   TranType,   TranAmt,   TranStts,
                         TranDate,  EffDate,    SysClock,  TranDesc)
                  VALUES(c_AcctNum, c_TranType, c_AccrInt, 'F',
						 c_Sysdate, c_Sysdate,  NOW(),     'Interest Capitalization');
		UPDATE account
		   SET AcctBal = AcctBal + c_AccrInt,
               AccrInt = 0
		 WHERE AcctNum = c_AcctNum;
    END LOOP getAcct;
	CLOSE CsrAcct;
    SELECT 0000, 'Accrued interest successfully posted.', c_AcctNum;
END//





DROP PROCEDURE IF EXISTS endOfDay;

DELIMITER //

CREATE PROCEDURE endOfDay()
BEGIN
    DECLARE c_Sysdate     date    DEFAULT 0;
    DECLARE c_SysStts     char(1) DEFAULT 0;
    DECLARE c_RecCnt      int     DEFAULT 0;
    DECLARE c_ErrCnt      int     DEFAULT 0;
	DECLARE c_SysNextday  date    DEFAULT 0;
	DECLARE c_SaIntRate   decimal(9,6) DEFAULT 0;
	DECLARE c_CaOdIntRate decimal(9,6) DEFAULT 0;
	
    SET c_SysStts = ' ';
    SELECT COUNT(*), SysStts INTO c_RecCnt, c_SysStts FROM syscontrol WHERE CurrRec = 'C';
	
    DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg(RetnCode int, RetnMsg varchar(255));
    
    IF (c_RecCnt = 0) THEN
        INSERT retnmsg SELECT 4001, 'Syscontrol reccord not found, cannot run EOD.';
	ELSEIF (c_SysStts <> 'A') THEN
        INSERT retnmsg SELECT 4002, 'Syscontrol status must be A to commence, cannot run EOD.';
    END IF;
	
    SELECT COUNT(*) INTO c_ErrCnt FROM retnmsg;
	IF c_ErrCnt = 0 THEN
	    BEGIN
	        SELECT Sysdate,   DATE_ADD(Sysdate, INTERVAL 1 DAY), SaIntRate,   CaOdIntRate
              INTO c_Sysdate, c_SysNextday,                      c_SaIntRate, c_CaOdIntRate
		     FROM syscontrol WHERE CurrRec = 'C';
           -- Signal begin of EOD
	       UPDATE syscontrol
		      SET SysStts = 'E'
 		    WHERE CurrRec = 'C';
           -- For all Savings accounts, update interest accrued:
		   UPDATE account
		      SET AccrInt = AccrInt + (AcctBal - AcctBalPending) * c_SaIntRate / 36500
			WHERE AcctType = 'S'
			  AND (AcctBal - AcctBalPending > 0);
           -- For all current accounts, update OD interest accrued:
		   UPDATE account
		      SET AccrInt = AccrInt + (AcctBal - AcctBalPending) * c_CaOdIntRate / 36500
			WHERE AcctType = 'C'
			  AND (AcctBal - AcctBalPending < 0);
           -- Update control total balances to control record
           UPDATE syscontrol,
                 (SELECT c_Sysdate            AS Sysdate,
                         SUM(AcctBal)        AS SumBal,
                         SUM(AcctBalPending) AS SumBalPending
   		            FROM account
	               WHERE AcctType = 'S') AS sums
              SET SaBal     = IFNULL(sums.SumBal,0),
                  SaPendBal = IFNULL(sums.SumBalPending,0)
            WHERE syscontrol.Sysdate = sums.SysDate;
           UPDATE syscontrol,
                 (SELECT c_Sysdate            AS Sysdate,
                         SUM(AcctBal)        AS SumBal,
                         SUM(AcctBalPending) AS SumBalPending
   		            FROM account
	               WHERE AcctType = 'C') AS sums
              SET CaBal     = IFNULL(sums.SumBal,0),
                  CaPendBal = IFNULL(sums.SumBalPending,0)
            WHERE syscontrol.Sysdate = sums.SysDate;
            -- 7. if last day of the month:
			IF MONTH(c_Sysdate) <> MONTH(c_SysNextday) THEN
			    BEGIN
                    --  Capitalise accrued by invoking postAccrual(AcctNum) AcctNum=0 means to post all accounts.
                    CALL postAccrual(0);
                    --  Generate Account balance history record for accounts not closed, 
                    --  as opening balance from next day onward.
					DELETE FROM acctbalhist WHERE DateSOM = c_SysNextday;
					INSERT acctbalhist
                           SELECT AcctNum,
                                  c_SysNextday,
                                  AcctBal,
								  AcctBalPend
                             FROM account
							WHERE AcctStts <> 'C'; 
				END;
			END IF;
            -- 8. Create a new syscontrol record from today's record
            UPDATE syscontrol SET CurrRec ='X' WHERE CurrRec = 'C';
            INSERT syscontrol 
                   SELECT c_SysNextday, 'C',        BankName,   'A',       LastAcctNum, 
                          SaBal,       SaPendBal,  SaIntRate, SaMinBal,
                          CaBal,       CaPendBal,  CaOdIntRate,
                          ATMMinWD,    NOW()
			         FROM syscontrol
					WHERE CurrRec = 'X';
            UPDATE syscontrol SET CurrRec =' ' WHERE CurrRec = 'X';
        INSERT retnmsg SELECT 0000, 'EOD completed successfully.';
	   END;
	END IF;

    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
	DROP TEMPORARY TABLE retnmsg;
END //





DROP PROCEDURE IF EXISTS newCashTran;

DELIMITER //

CREATE PROCEDURE newCashTran(i_AcctNum decimal(10,0), i_TranType char(1), i_TranAmt decimal(15,2), i_AcctNum2 decimal(10,0), i_CustName varchar(45))
BEGIN
   DECLARE c_Sysdate DATE;
   DECLARE c_SaMinBal DECIMAL(15,2);
   DECLARE c_AcctCnt INT;
   DECLARE c_AcctNum INT;
   DECLARE c_AcctType CHAR(1);
   DECLARE c_CustId INT;
   DECLARE c_AcctStts CHAR(1);
   DECLARE c_AcctBal DECIMAL(15,2);
   DECLARE c_AcctBalPending DECIMAL(15,2);
   DECLARE c_OdLimit DECIMAL(15,2);
   DECLARE c_AcctCnt2 INT;
   DECLARE c_AcctNum2 INT;
   DECLARE c_AcctType2 CHAR(1);
   DECLARE c_CustId2 INT;
   DECLARE c_AcctStts2 CHAR(1);
   DECLARE c_AcctBal2 DECIMAL(15,2);
   DECLARE c_AcctBalPending2 DECIMAL(15,2);
   DECLARE c_OdLimit2 DECIMAL(15,2);
   DECLARE c_TranId1 INT;
   DECLARE c_TranId2 INT;

    SELECT   Sysdate,   SaMinBal
	  INTO c_Sysdate, c_SaMinBal
	  FROM syscontrol WHERE CurrRec = 'C';
    SELECT  COUNT(*),   AcctNum,   AcctType,   CustId,   AcctStts,   AcctBal,   AcctBalPending,   OdLimit
      INTO c_AcctCnt, c_AcctNum, c_AcctType, c_CustId, c_AcctStts, c_AcctBal, c_AcctBalPending, c_OdLimit
	  FROM account
     WHERE AcctNum = i_AcctNum;
    SELECT  COUNT(*),    AcctNum,    AcctType,    CustId,    AcctStts,    AcctBal,    AcctBalPending,    OdLimit
      INTO c_AcctCnt2, c_AcctNum2, c_AcctType2, c_CustId2, c_AcctStts2, c_AcctBal2, c_AcctBalPending2, c_OdLimit2
	  FROM account
     WHERE AcctNum = i_AcctNum2;

    DROP TEMPORARY TABLE IF EXISTS retnmsg;
    CREATE TEMPORARY TABLE retnmsg (RetnCode int, RetnMsg varchar(255), TranId int, AcctNum decimal(10,0), CustId int);

    IF (i_TranAmt = 0) THEN
        INSERT retnmsg SELECT 2001, 'Transaction amount cannot be 0.', 0, i_AcctNum, @CustId;
	ELSEIF (c_AcctCnt = 0) THEN
		INSERT retnmsg SELECT 2001, 'Account does not exist.', 0, i_AcctNum, 0;
	ELSE
		BEGIN
			IF (c_AcctStts = 'C') THEN
				INSERT retnmsg SELECT 2002, 'Account closed, transaction not allowed.', 0, i_AcctNum, 0;
			ELSEIF (i_TranAmt < 0) AND (c_AcctStts = 'S') THEN
				INSERT retnmsg SELECT 2002, 'Account suspended, withdrawal not allowed.', 0, i_AcctNum, 0;
			ELSE
			    BEGIN
					IF ((i_TranAmt < 0) AND (c_AcctType = 'S') AND
						(c_AcctBal - c_AcctBalPending + i_TranAmt < c_SaMinBal)) THEN
						INSERT retnmsg SELECT 2006, 'Withdrawal rejected due to SA minimum balance limit breached.', 0, i_AcctNum, 0;
					END IF;
					IF ((i_TranAmt < 0) AND (c_AcctType = 'C') AND
						(c_AcctBalPending - c_AcctBal - i_TranAmt > c_OdLimit)) THEN
						INSERT retnmsg SELECT 2006, 'Withdrawal rejected due to CA OD limit breached.', 0, i_AcctNum, 0;
					END IF;
				END;
			END IF;
		    SELECT COUNT(*) INTO @ErrCnt FROM retnmsg;
			IF (@ErrCnt = 0) AND (i_AcctNum2 > 0) THEN
				BEGIN
					IF (c_AcctCnt2 = 0) THEN
						INSERT retnmsg SELECT 2001, 'Counter-party Account does not exist.', 0, i_AcctNum2, 0;
					ELSE
						BEGIN
							IF (c_AcctStts2 = 'C') THEN
								INSERT retnmsg SELECT 2002, 'Counter-party Account closed, transaction not allowed.', 0, i_AcctNum2, 0;
							ELSEIF (i_TranAmt > 0) AND (c_AcctStts2 = 'S') THEN
								INSERT retnmsg SELECT 2002, 'Counter-party Account suspended, withdrawal not allowed.', 0, i_AcctNum2, 0;
							ELSE
							    BEGIN
									IF ((i_TranAmt > 0) AND (c_AcctType2 = 'S') AND
										(c_AcctBal2 - c_AcctBalPending2 - i_TranAmt < c_SaMinBal)) THEN
										INSERT retnmsg SELECT 2006, 'Withdrawal rejected due to Counter-party Account SA minimum balance limit breached.', 0, i_AcctNum2, 0;
									END IF;
									IF ((i_TranAmt > 0) AND (c_AcctType2 = 'C') AND
										(c_AcctBalPending2 - c_AcctBal2 + i_TranAmt > c_OdLimit2)) THEN
										INSERT retnmsg SELECT 2006, 'Withdrawal rejected due to Counter-party Account CA OD limit breached.', 0, i_AcctNum2, 0;
									END IF;
								END;
							END IF;
						END;
					END IF;
				END;
			END IF;
	    END;
	END IF ;

	
    SELECT COUNT(*) INTO @ErrCnt FROM retnmsg;
	IF @ErrCnt = 0 THEN
		BEGIN
			IF i_AcctNum2 > 0 THEN
				SET i_TranType = 'T';
			ELSE
				SET i_TranType = 'C';
			END IF;
			INSERT INTO tran(AcctNum,   TranType,   TranAmt,   TranStts,
							 TranDate,  EffDate,    SysClock,
							 TranDesc)
					  VALUES(i_AcctNum, i_TranType, i_TranAmt, 'I',
							 c_Sysdate, c_Sysdate,  NOW(),
							 ' ');
			SELECT LAST_INSERT_ID() INTO c_TranId1;
			UPDATE account
			   SET AcctBal = AcctBal + i_TranAmt
			 WHERE AcctNum = i_AcctNum;
			IF i_AcctNum2 > 0 THEN
			    BEGIN
					INSERT INTO tran(AcctNum,    TranType,   TranAmt,    TranStts,
									 TranDate,   EffDate,    SysClock,
									 TranDesc,   TranIdRel)
							  VALUES(i_AcctNum2, i_TranType, -i_TranAmt, 'F',
									 c_Sysdate,  c_Sysdate,  NOW(), 
									 ' ',       c_TranId1);
					SELECT LAST_INSERT_ID() INTO c_TranId2;
					UPDATE account
					   SET AcctBal = AcctBal - i_TranAmt
					 WHERE AcctNum = i_AcctNum2;
					UPDATE tran
					   SET TranStts = 'F',
					       TranIdRel = C_TranId2
					 WHERE TranId = c_TranId1;
				END;
			END IF;
			INSERT retnmsg SELECT 0000, 'Transaction(s) successfully posted.', c_TranId1, i_AcctNum, 0;
		END;
	END IF;
    SELECT * FROM retnmsg ORDER BY RetnCode ASC;
	DROP TEMPORARY TABLE retnmsg;
	
END//




DROP PROCEDURE IF EXISTS findTran;

DELIMITER //

CREATE PROCEDURE findTran(i_TranId int, i_AcctNum decimal(10,0), i_CustId int, i_Sele char(1), i_Sort char(1))
BEGIN
	SET i_Sele = IFNULL(i_Sele,'');
	SET i_Sort = IFNULL(i_Sort,'');
    DROP TEMPORARY TABLE IF EXISTS tranlist;
    CREATE TEMPORARY TABLE tranlist(TranId int);

    IF (i_TranId > 0) THEN
	   INSERT tranlist SELECT TranId FROM tran WHERE TranId = i_TranId;
	ELSEIF (i_AcctNum > 0) THEN
	   INSERT tranlist SELECT TranId FROM tran WHERE AcctNum = i_AcctNum;
	ELSEIF (i_CustId > 0) THEN
	   INSERT tranlist SELECT TranId FROM tran
 	    WHERE AcctNum IN (SELECT AcctNum FROM account WHERE (CustId = i_CustId) OR (CustIdJoint = i_CustId));
	END IF;   
	
	DROP TEMPORARY TABLE IF EXISTS temp_Tran;
	CREATE TEMPORARY TABLE temp_Tran
        SELECT * FROM Tran
         WHERE TranId IN (SELECT TranId FROM tranlist);

    DROP TEMPORARY TABLE tranlist;

    SELECT TranId, AcctNum, TranType, TranDesc, TranAmt, TranStts, ChqNum, TranDate, EffDate, TranIdRel, SysClock
   		  FROM temp_Tran ORDER BY TranId;

    DROP TEMPORARY TABLE temp_Tran;

END//





