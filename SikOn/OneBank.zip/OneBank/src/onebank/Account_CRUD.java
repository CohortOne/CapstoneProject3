package onebank;
import static onebank.Main.*;
import static onebank.Account.*;
import static onebank.AccountDAO.*;
import static onebank.Customer_CRUD.*;
import static onebank.Tran_CRUD.listTrans;
import static onebank.Tran_CRUD.newCashTransaction;
import static onebank.Utility.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

public class Account_CRUD {
    
    
    public static int acctMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("***********************************************");
            System.out.println("*** Account Menu ::: ");
            System.out.println("***********************************************");
            System.out.println("*** 1 Retrive by Acct Num ");
            System.out.println("*** 2 List for a Customer Id ");
            System.out.println("*** 4 List all Savings accounts"); 
            System.out.println("*** 5 List all Current accounts"); 
            System.out.println("*** 6 List all Joint accounts"); 
            System.out.println("*** 8 List all "); 
            System.out.println("*** 0 Return");
            System.out.println("***********************************************");
            optionVal = readlnInt(" Enter menu option number:");
            if ((optionVal == 1) || (optionVal == 2) || (optionVal == 4) || (optionVal == 5) || (optionVal == 6) || (optionVal == 8) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
    
    public static int acctSortMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("***********************************************");
            System.out.println("****** How do you want to list of Accounts sorted:");
            System.out.println("****** 1 By Account number "); 
            System.out.println("****** 2 By Principal Customer name");
            System.out.println("***********************************************");
            optionVal = readlnInt(" Enter number of your choice : ");
            if ((optionVal == 1) || (optionVal == 2)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
    
    public static int acctActionMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("********************************************************");
            System.out.println("********* Account Action Menu");
            System.out.println("********************************************************");
            System.out.println("********* Perform Transactions");
            System.out.println("*********  1 Cash Deposit/Withdrawal");
            System.out.println("*********  2 Fund transfer to/from pinned Account");
            System.out.println("*********  7 Preview MTD account statment");
            System.out.println("*********  8 Generate historical account statment");
            System.out.println("*********  9 Close Account");
            System.out.println("********* Account management");
            System.out.println("********* 11 Modify/revoke Overdraft limit");
            System.out.println("********* 12 Grant Joint ownership to pined Customer");
            System.out.println("********* 13 Revoke Joint ownership");
            System.out.println("********* 18 Pin this Account");
            System.out.println("********* Navigation");
            System.out.println("*********  3 Work with transactions in this Account");
            System.out.println("********* 19 Work with pinned Account");
            System.out.println("********* 21 Work with Principal account holder");
            System.out.println("********* 22 Work with Joint account holder");
            System.out.println("********************************************************");
            System.out.println("*********  0 Return");
            System.out.println("********************************************************");
            optionVal = readlnInt(" Enter a number to carry out the operation:");
            if ((optionVal >= 1) && (optionVal <= 3)   ||   (optionVal >= 7) && (optionVal <= 9) ||
                (optionVal >= 11) && (optionVal <= 13) || (optionVal == 18) || (optionVal == 19) || (optionVal == 21) || (optionVal == 21) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
    
        } while (!booOK);
        return optionVal;
    }
    

    public static int listAccts(int aid, int cid) throws Exception {  // return 0 if called with specific aid/cid but failed to find any Acct for processing
        String strSele = " ";
        String strSort = "N";
        int intAcctNum = 0;
        int intCustId = 0;
        int optVal = -1;
        int optSort = 1;
        List <Account> myAcctList = new ArrayList<>();
        Account myAcct = null;

        menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",myLocale);
        
        if (aid > 0) {
            myAcctList = findAccount(aid, 0, 0, " ", " ");
            if (myAcctList.isEmpty()) {
                System.out.println(" No Account found with Account number=" + aid + ".");
                pause4Enter();
                return 0;
            }
        } else {
            if (cid > 0) {
                myAcctList = findAccount(0, cid, 0, " ", " ");
                if (myAcctList.isEmpty()) {
                    System.out.println(" No Account found for Customer Id=" + cid + ".");
                    pause4Enter();
                    return 0;
                }
            }
        }
        do { // this loop will run once only if aid/cid is not 0, otherwise loop until user decides to exit method
            int aidFound;
            do {
                aidFound = 0;
                while (myAcctList.isEmpty()) {
                    optVal = acctMenu();
                    if (optVal == 0) { return 1;}

                    intAcctNum = 0;
                    if (optVal == 1) {
                        intAcctNum = readlnInt(" Enter Account number, 0 to list all :   ");
                    }

                    intCustId = 0;
                    if (optVal == 2) {
                        intCustId = readlnInt(" Enter CustId, 0 to list all :   ");
                    }

                    strSele = "";
                    if (optVal == 4) {
                        strSele = "S";
                    }
                    
                    if (optVal == 5) {
                        strSele = "C";
                    }
                    if (optVal == 6) {
                        strSele = "J";
                    }

                    myAcctList = findAccount(intAcctNum, intCustId, 0, strSele, " ");
                    if (myAcctList.isEmpty()) {
                        System.out.println(" No Account found matching the criteria, try again.");
                    }
                }

                if (myAcctList.size() == 1) {
                    myAcct = myAcctList.get(0);
                    aidFound = myAcct.getAcctNum();
                } else {
                    optSort = acctSortMenu();
                    String strPrompt = " Pick an account to operate on by entering the account number, 0 to exit:";
                    do {
                        int aidSele;
                        printHeader();
                        if (optSort == 1) {System.out.println("Sorting by Account number:");}
                        if (optSort == 2) {System.out.println("Sorting by Principal Customer name:");}
                        System.out.println(strAcctLbl);
                        System.out.println(strAcctUdl);
                        if (optSort == 1) {myAcctList.stream().sorted((c1, c2) -> c1.getAcctNum()-(c2.getAcctNum())).forEach(System.out::println);}
                        if (optSort == 2) {myAcctList.stream().sorted((c1, c2) -> CustomerDAO.getCustomer(c1.getCustId()).getCustName().compareTo(CustomerDAO.getCustomer(c2.getCustId()).getCustName())).forEach(System.out::println);}
                        System.out.println(strAcctUdl);
                        aidSele = readlnInt(strPrompt);
                        if (aidSele == 0) {
                            break;
                        }

                        Iterator<Account> myAcctIterator = myAcctList.iterator();
                        while (myAcctIterator.hasNext()) {
                            myAcct = myAcctIterator.next();
                            if (myAcct.getAcctNum() == aidSele) {
                                aidFound = aidSele;
                                break;
                            }
                        }

                        if (aidFound == 0) {
                            strPrompt =" No Account found with account number=" + aidSele + ", pick again, or 0 to exit...";
                            continue;
                        }
                    } while (aidFound == 0);
                }
                myAcctList.clear();
            } while ((aidFound == 0) && (aid == 0) && (cid ==0));
            
            optVal = 1;
            while ((optVal != 0) && (myAcct != null)) {
                myAcct = AccountDAO.getAccount(myAcct.getAcctNum());
                printHeader();
                System.out.println(strAcctLbl);
                System.out.println(strAcctUdl);
                System.out.println(myAcct.toString());
                System.out.println(strAcctUdl);
                optVal = acctActionMenu();

                if (optVal == 1) {
                    newCashTransaction(myAcct, false);
                }

                if (optVal == 2) {
                    newCashTransaction(myAcct, true);
                }

                if (optVal == 3) {
                    listTrans(0, myAcct.getAcctNum(), 0);
                }

                if (optVal == 7) {
                    printStatement(myAcct.getAcctNum());
                }

                if (optVal == 8) {
                    System.out.println(" *** function not jet implemented ***");
                }

                if (optVal == 9) {
                    System.out.println(" *** function not jet implemented ***");
                }

                if (optVal == 11) {
                    updAcct(myAcct,'L',0);
                }

                if (optVal == 12) {
                    updAcct(myAcct,'J',pinCust.getCustId());
                }

                if (optVal == 13) {
                    updAcct(myAcct,'J',0);
                }

                if (optVal == 18) {
                    pinAcct = myAcct;
                    optVal = 0;
                }

                if (optVal == 21) {
                    if (listCusts(myAcct.getCustId()) > 0) {
                        optVal = 0;
                    }
                }

                if (optVal == 19) {
                    if (pinAcct == null) {
                        System.out.println("There is no pinned Account.");
                    } else {
                        listAccts(pinAcct.getAcctNum(), 0);
                        optVal = 0;
                    }
                }

                if (optVal == 22) {
                    if (myAcct.getCustIdJoint()  == 0) {
                        System.out.println(" This account has no joint account holder.");
                    } else {
                        if (listCusts(myAcct.getCustIdJoint()) > 0) {
                            optVal = 0;
                        }
                    }
                }
            }
            myAcctList.clear();
        } while ((aid == 0) && (cid == 0));
        return 1;
    }    
    
    public static int insAcct(Customer myCust) throws Exception {
    Account thisAcct;
    int nxtAN;
        if (myCust.getCustStts() != 'A') {
            System.out.println(" Customer is not activated, cannot create account.");
            return 0;
        }
        System.out.println(" Enter details to open new Account:");
        printFooter();
        
        char chrAcctType;
        do {
            System.out.print(" Account type ([S]avings / [C]urrent:");
            chrAcctType = myObj.nextLine().trim().toUpperCase().charAt(0);
        } while ((chrAcctType != 'S') && (chrAcctType != 'C'));
        
        int intOD = 0;
        if (chrAcctType == 'C') {
            intOD = readlnInt(" OD limit to be assigned to this Current account:");
        }
        
        thisAcct = new Account(chrAcctType, myCust.getCustId(), 0, intOD);
        System.out.println(strAcctLbl);
        System.out.println(strAcctUdl);
        System.out.println(thisAcct);
        Utility.printHeader();
        System.out.print(" About to create this account for current Customer, Y to confirm:");
        String resp = myObj.nextLine();
        if (resp.equalsIgnoreCase("Y")) {
            nxtAN = newAccount(thisAcct);
            if (nxtAN > 0) {
                System.out.println("Account created successfully with Account number=" + nxtAN + ".");
            } else {
                System.out.println("Account creation failed.");
            }
        } else {
            System.out.println("Account creation aborted.");
        }
        printFooter();
        
        return 1;
    }
    
    
    
    public static int updAcct(Account myAcct, char chrAction, int i_CustId) throws Exception {
    boolean booOK = true;
    int intOdLimit = 0;
    
        System.out.println(" The following account has been selected for update:");
        System.out.println(strAcctLbl);
        System.out.println(strAcctUdl);
        System.out.println(myAcct);
        printFooter();

        if (chrAction == 'C') {
            if (i_CustId == 0) {
                System.out.println(" No proposed new Principal Customer Id, update by-passed.");
            } else {
                if (i_CustId == myAcct.getCustId()) {
                    System.out.println(" Proposed Principal Customer Id is the same as current, update by-passed.");
                } else {
                    System.out.println(" Proceeding to update Principal Customer Id from [" + myAcct.getCustId() + "] to [" + i_CustId + "]...");
                    updAccount(myAcct.getAcctNum(), 'C', i_CustId, 0 );
                }
            }
        }
        
        if (chrAction == 'J') {
            booOK = true;
            if ((i_CustId == 0) && (myAcct.getCustIdJoint() == 0)) {
                System.out.println(" Not a Joint Account, no Joint account holder to revoke, update by-passed.");
                booOK = false;
            }
            if (booOK && (i_CustId == myAcct.getCustId())) {
                System.out.println(" Proposed Joint Customer Id is the same as Principal Customer Id, update by-passed.");
                booOK = false;
            }
            if (booOK && (i_CustId == myAcct.getCustIdJoint())) {
                System.out.println(" Proposed Joint Customer Id is the same as current, update by-passed.");
                booOK = false;
            }
            if (booOK) {
                if (i_CustId == 0) {
                    System.out.println(" Proceeding to revoke Joint ownership of Customer Id [" + myAcct.getCustIdJoint() + "] on the Account...");
                } else {
                    if (myAcct.getCustIdJoint() == 0) {
                        System.out.println(" Proceeding to grant Customer [" + i_CustId + "] the Joint ownership of on the Account...");
                    } else {
                        System.out.println(" Proceeding to transfer Joint ownership from Customer Id [" + myAcct.getCustIdJoint() + "] to [" + i_CustId + "] on the Account...");
                    }
                }
                updAccount(myAcct.getAcctNum(), 'J', i_CustId, 0 );
            }
        }

        if (chrAction == 'L') {
            booOK = true;
            if (myAcct.getAcctType() != 'C' ) {
                System.out.println(" Change of OD limit is only for Current accounts, update by-passed.");
                booOK = false;
            }
            if (booOK) {
                intOdLimit = readlnInt(" Current OD Limit:" + myAcct.getOdLimit() + "\n     New OD Limit:");
                if (intOdLimit == Math.round(myAcct.getOdLimit())) {
                    System.out.println(" OD Limit entered is the same as current OD Limit, update by passed.");
                booOK = false;
                }
            }
            if (booOK && (intOdLimit == 0)) {
                System.out.println(" 0 entered as new OD Limit, this will revoke the OD limit from the account.");
                System.out.print(" Enter [Y] to confirm:");
                String strYoN = myObj.nextLine().trim().toUpperCase();
                if (!(strYoN.equalsIgnoreCase("Y"))) {
                    booOK = false;
                }
            }
            if (booOK) {
                if (intOdLimit == 0) {
                    System.out.println(" proceeding to revoke OD limit of the accouint...");
                } else {
                    System.out.println(" proceeding to update OD limit of the accouint...");
                }
                updAccount(myAcct.getAcctNum(), 'L', 0, intOdLimit);
            }
        }
        
        printFooter();
        return 1;
    }    
}
