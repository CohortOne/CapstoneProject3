package onebank;
import static onebank.AccountDAO.*;
import static onebank.Account_CRUD.listAccts;
import static onebank.Customer_CRUD.listCusts;
import static onebank.Main.*;
import static onebank.Tran.*;
import static onebank.TranDAO.*;
import static onebank.Utility.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;

public class Tran_CRUD {

    public static int tranMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("***********************************************");
            System.out.println("*** Transaction Menu ::: ");
            System.out.println("***********************************************");
            System.out.println("*** 1 Retrive by Tran Id ");
            System.out.println("*** 2 Retrive by Account number");
            System.out.println("*** 3 Retrive by Customer Id");
            System.out.println("*** 0 Return");
            System.out.println("***********************************************");
            optionVal = readlnInt(" Enter menu option number:");
            if ((optionVal == 1) || (optionVal == 2) || (optionVal == 3) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
    
    public static int tranSortMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("********************************************************");
            System.out.println("****** How do you want your list of Transactions sorted:");
            System.out.println("****** 1 By Transaction Id"); 
            System.out.println("****** 2 By Transaction Amount");
            System.out.println("********************************************************");
            optionVal = readlnInt(" Enter number of your choice : ");
            if ((optionVal == 1) || (optionVal == 2)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
    
    public static int tranActionMenu() {
    boolean booOK;
    int optionVal;
        do {
            booOK = false;
            printPinned();
            System.out.println("********************************************************");
            System.out.println("********* Transaction Action Menu");
            System.out.println("********************************************************");
            System.out.println("*********  1 Reverse the transaction");
            System.out.println("*********  2 Clear the transaction");
            System.out.println("********* Navigation");
            System.out.println("********* 21 Work with Account of this Transaction");
            System.out.println("********* 22 Work with principal holder of Account of this Transaction");
            System.out.println("********* 23 Work with joint holder of Account of this Transaction");
            System.out.println("*********  0 Return");
            System.out.println("********************************************************");
            optionVal = readlnInt(" Enter a number to carry out the operation:");
            if ((optionVal == 1) || (optionVal == 2) || (optionVal >= 21) && (optionVal <= 23) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(" Invalid option, please try again.");
            }
    
        } while (!booOK);
        return optionVal;
    }
    

    public static int listTrans(int tid, int aid, int cid) throws Exception {  // return 0 if called with specific tid/aid/cid but failed to find any Acct for processing
        int intTranId;
        int intAcctNum;
        int intCustId;
        int optVal;
        int optSort;
        List <Tran> myTranList = new ArrayList<>();
        Tran myTran = null;

        menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",myLocale);
        
        if (tid > 0) {
            myTranList = findTran(tid, 0, 0, ' ', ' ');
            if (myTranList.isEmpty()) {
                System.out.println(" No Transaction found with Transaction Id=" + tid + ".");
                pause4Enter();
                return 0;
            }
	} else {
            if (aid > 0) {
		myTranList = findTran(0, aid, 0, ' ', ' ');
		if (myTranList.isEmpty()) {
                    System.out.println(" No Transaction found for Account number=" + aid + ".");
                    pause4Enter();
                    return 0;
		}
            } else {
		if (cid > 0) {
                    myTranList = findTran(0, 0, cid, ' ', ' ' );
                    if (myTranList.isEmpty()) {
                        System.out.println(" No Transaction found for Customer Id=" + cid + ".");
			pause4Enter();
			return 0;
                    }
		}
            }
        }

        do { // this loop will run once only if tid/aid/cid is not 0, otherwise loop until user decides to exit method
            int tidFound;
            do {
                tidFound = 0;
                while (myTranList.isEmpty()) {
                    optVal = tranMenu();
                    if (optVal == 0) { return 1;}

                    intTranId = 0;
                    if (optVal == 1) {
                        intTranId = readlnInt(" Enter Transaction Id, 0 to list all :   ");
                    }

                    intAcctNum = 0;
                    if (optVal == 2) {
                        do {intAcctNum = readlnInt(" Enter Account number: ");
                            if (intAcctNum == 0) {
				System.out.println("You must enter an Account number.");
                            }
			} while (intAcctNum == 0);
                    }

                    intCustId = 0;
                    if (optVal == 3) {
                        do {intCustId = readlnInt(" Enter Customer Id:");
                            if (intCustId == 0) {
				System.out.println("You must enter a Customer Id.");
                            }
			} while (intCustId == 0);
                    }

                    myTranList = findTran(intTranId, intAcctNum, intCustId, ' ', ' ');
                    if (myTranList.isEmpty()) {
                        System.out.println(" No Transaction matching the criteria, try again.");
                    }
                }

                if (myTranList.size() == 1) {
                    myTran = myTranList.get(0);
                    tidFound = myTran.getAcctNum();
                } else {
                    optSort = tranSortMenu();
                    String strPrompt = " Pick a Transaction to operate on by entering the TranId, 0 to exit:";
                    do {
                        int aidSele;
                        printHeader();
                        if (optSort == 1) {System.out.println("Sorting by Trnasaction Id:");}
                        if (optSort == 2) {System.out.println("Sorting by Transaction Amount:");}
                        System.out.println(strTranLbl);
                        System.out.println(strTranUdl);
                        if (optSort == 1) {myTranList.stream().sorted((c1, c2) -> c1.getTranId()-(c2.getTranId())).forEach(System.out::println);}
                        if (optSort == 2) {
                            Comparator <Tran> byTranAmt = Comparator.comparing(tran -> tran.getTranAmt());
                            myTranList.stream().sorted(byTranAmt).forEach(System.out::println);
                        }
                        System.out.println(strTranUdl);
                        aidSele = readlnInt(strPrompt);
                        if (aidSele == 0) {
                            break;
                        }

                        Iterator<Tran> myIterator = myTranList.iterator();
                        while (myIterator.hasNext()) {
                            myTran = myIterator.next();
                            if (myTran.getTranId() == aidSele) {
                                tidFound = aidSele;
                                break;
                            }
                        }

                        if (tidFound == 0) {
                            strPrompt =" No Transaction found with TranId=" + aidSele + ", pick again, or 0 to exit...";
                            continue;
                        }
                    } while (tidFound == 0);
                }
                myTranList.clear();
            } while ((tidFound == 0) && (tid == 0) && (aid == 0) && (cid ==0));
            
            optVal = 1;
            while ((optVal != 0) && (myTran != null)) {
                myTran = getTran(myTran.getTranId());
                printHeader();
                System.out.println(strTranLbl);
                System.out.println(strTranUdl);
                System.out.println(myTran.toString());
                System.out.println(strTranUdl);
                optVal = tranActionMenu();

                if (optVal == 1) {
                    System.out.println("   **** function not yet implemented. ***");
                    myTran = getTran(tidFound);
                }

                if (optVal == 2) {
                    System.out.println("   **** function not yet implemented. ***");
                    myTran = getTran(tidFound);
                }

                if (optVal == 21) {
                    listAccts(myTran.getAcctNum(), 0);
                    optVal = 0;
                }

                if (optVal == 22) {
                    var tmpAcct = getAccount(myTran.getAcctNum());
                    listCusts(tmpAcct.getCustId());
                    optVal = 0;
                }

                if (optVal == 23) {
                    var tmpAcct = getAccount(myTran.getAcctNum());
                    if (tmpAcct.getCustIdJoint() != 0) {
                        listCusts(tmpAcct.getCustIdJoint());
                        optVal = 0;
                    } else {
                        System.out.println(" Account has no joint holder.");
                        myTran = getTran(tidFound);
                    }
                }
            }
            myTranList.clear();
        } while ((tid == 0) && (aid == 0) && (cid == 0));
        return 1;
    }
    
    
    public static int newCashTransaction(Account myAcct, boolean booWithPin) throws Exception {
    List<Tran> myTrans = new ArrayList<>();
    int nxtAN;
        if (myAcct.getAcctStts() != 'O') {
            System.out.println(" Account is not opened, cannot deposit/withdraw.");
            return 0;
        }
        if (booWithPin && (pinAcct == null)) {
            System.out.println(" No pinned Account, cannot transfer.");
            return 0;
        }
        if (booWithPin && (pinAcct.getAcctStts() != 'O')) {
            System.out.println(" Pinned Account is not opened, cannot transfer.");
            return 0;
        }
        System.out.println(" Enter deposit/withdrawal details:");
        printFooter();
        
        char chrTranType;
        do {
            System.out.print(" Is this a [D]eposit to / [W]ithdrawal from Account[" + myAcct.getAcctNum() + "]:");
            chrTranType = myObj.nextLine().trim().toUpperCase().charAt(0);
        } while ((chrTranType != 'D') && (chrTranType != 'W'));
        
        float tranAmt = readlnFloat("Enter the transaction amount, 0 to cancel.");
        
        if (tranAmt == 0) {
            System.out.println(" 0 amount entered, transaction cancelled.");
            return 0;
        }

        if (chrTranType == 'W') {
            float newBal = myAcct.getAcctBal() - myAcct.getAcctBalPending() + myAcct.getOdLimit() - tranAmt;
            if (newBal < 0) {
                System.out.println(" Account [" + myAcct.getAcctNum() + "] has insufficient balance for the withdrawal/transfer, withdrawal cancelled.");
                return 0;
            }
        }
        if (booWithPin && (chrTranType == 'D')) {
            float newBal = pinAcct.getAcctBal() - pinAcct.getAcctBalPending() + pinAcct.getOdLimit() - tranAmt;
            if (newBal < 0) {
                System.out.println(" Account [" + pinAcct.getAcctNum() + "] has insufficient balance for the transfer, transaction cancelled.");
                return 0;
            }
        }        

        // myTrans = null;
        if (!booWithPin) {
            myTrans.add(new Tran(myAcct.getAcctNum(), 'C', " ", (chrTranType=='D')?tranAmt:(-tranAmt), 'F', 0));
        } else {
            myTrans.add(new Tran(myAcct.getAcctNum(), 'T', " ", chrTranType=='D'?tranAmt:(-tranAmt), 'F', 0));
            myTrans.add(new Tran(pinAcct.getAcctNum(), 'T', " ", chrTranType=='D'?(-tranAmt):tranAmt, 'F', 0));
        }

        System.out.println(strTranLbl);
        System.out.println(strTranUdl);
        myTrans.stream().forEach(System.out::println);
        Utility.printHeader();
        System.out.print(" About to create the above transactions, Y to confirm:");
        String resp = myObj.nextLine();
        if (resp.equalsIgnoreCase("Y")) {
            if (!booWithPin) {
                nxtAN = newCashTran(myTrans.get(0).getAcctNum(), myTrans.get(0).getTranAmt(), 0, " ");
                if (nxtAN > 0) {
                    System.out.println("Transactions created successfully.");
                } else {
                    System.out.println("Transactions creation failed.");
                }
            } else {
                nxtAN = newCashTran(myTrans.get(0).getAcctNum(), myTrans.get(0).getTranAmt(), myTrans.get(1).getAcctNum(), " ");
                if (nxtAN > 0) {
                    System.out.println("Transfer created successfully.");
                } else {
                    System.out.println("Transfer failed.");
                }
            }
        } else {
            System.out.println("Transactions creation aborted.");
        }
        printFooter();
        
        return 1;
    }
    
}
