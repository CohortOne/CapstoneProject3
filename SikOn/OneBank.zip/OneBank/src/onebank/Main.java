package onebank;


import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.util.Scanner;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.Formatter;
import java.util.logging.SimpleFormatter;
import java.util.logging.XMLFormatter;




public class Main extends Application {
    public static Customer pinCust;
    public static Scanner myObj = new Scanner(System.in);
    public static Locale myLocale;
    public static ResourceBundle menuLines;

    public static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    public static Handler fileHandler = null;
    public static Formatter messageFormatter = null;
    public static boolean pgmMode; // true=text mode, false=GUI mode

   @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(new StackPane());

        FXMLLoader loader = new FXMLLoader(getClass().getResource("rootPane.fxml"));
        scene.setRoot(loader.load());
        rootPaneController controller = loader.getController();
        controller.init();

        primaryStage.setScene(scene);
        primaryStage.setTitle(" One Bank ");
        primaryStage.show();
    }

    public static void main(String[] args) {
        prepLogger();
        myLocale = new Locale("en", "UK");
        LOGGER.log(Level.INFO, "Language set to en_UK by default.");

        launch(args);
    }

    private static void prepLogger() {
        
       try{
            LOGGER.setUseParentHandlers(false);

            //Creating fileHandler
            fileHandler  = new FileHandler("./javacodegeeks.log");
            
            //Assigning handlers to LOGGER object
            LOGGER.addHandler(fileHandler);
             
            //Setting levels to handlers and LOGGER
            // fileHandler.setLevel(Level.ALL);
            LOGGER.setLevel(Level.ALL);
            
            LOGGER.info("Finnest message: Logger with DEFAULT FORMATTER");

            messageFormatter = new SimpleFormatter();
            fileHandler.setFormatter(messageFormatter);
            LOGGER.info("Finnest message: Logger with SIMPLE FORMATTER");

            messageFormatter = new XMLFormatter();
            fileHandler.setFormatter(messageFormatter);
            LOGGER.info("Finnest message: Logger with XML FORMATTER");

            LOGGER.log(Level.INFO, "Logger Name: {0}", LOGGER.getName());
             
             
        }catch(IOException exception){
            LOGGER.log(Level.SEVERE, "Error occur in FileHandler.", exception);
        }
        LOGGER.config("Configuration done.");
    }
    
}
