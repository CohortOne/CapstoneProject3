package onebank;


import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.util.Scanner;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.Formatter;
import java.util.logging.SimpleFormatter;
import java.util.logging.XMLFormatter;
import static onebank.Account_CRUD.listAccts;
import static onebank.Customer_CRUD.insCust;
import static onebank.Customer_CRUD.listCusts;
import static onebank.Tran_CRUD.listTrans;
import static onebank.Utility.printFooter;
import static onebank.Utility.printHeader;
import static onebank.Utility.printPinned;
import static onebank.Utility.readlnInt;




public class Main extends Application {
    public static Customer pinCust;
    public static Account pinAcct;

    public static Scanner myObj = new Scanner(System.in);
    public static Locale myLocale;
    public static ResourceBundle menuLines;

    public static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    public static Handler fileHandler = null;
    public static Formatter messageFormatter = null;
    public static boolean pgmMode; // true=text mode, false=GUI mode

   @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(new StackPane());

        FXMLLoader loader = new FXMLLoader(getClass().getResource("rootPane.fxml"));
        scene.setRoot(loader.load());
        rootPaneController controller = loader.getController();
        controller.init();

        primaryStage.setScene(scene);
        primaryStage.setTitle(" One Bank ");
        primaryStage.show();
    }

    public static int mainMenu() {
        String strDivider = "*".repeat(30);
        String strPrintln;
        boolean booOK;
        int optionVal;
        
        do {
            booOK = false;
            printPinned();
            menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",myLocale);
            System.out.println(strDivider);
            System.out.println(menuLines.getString("M0M00").length()>0?menuLines.getString("M0M00"):" Main Menu");
            System.out.println(strDivider);
            System.out.println(menuLines.getString("M0M01").length()>0?menuLines.getString("M0M01"):"  1 Create new Customer");
            System.out.println(menuLines.getString("M0M02").length()>0?menuLines.getString("M0M02"):"  2 Customers Menu"); 
            System.out.println(menuLines.getString("M0M03").length()>0?menuLines.getString("M0M03"):"  3 Accounts Menu"); 
            System.out.println(menuLines.getString("M0M04").length()>0?menuLines.getString("M0M04"):"  4 Transactions Menu"); 
            System.out.println(strDivider);
            System.out.println(menuLines.getString("M0M07").length()>0?menuLines.getString("M0M07"):"  7 Lanuch FXML interface"); 
            System.out.println(menuLines.getString("M0M08").length()>0?menuLines.getString("M0M08"):"  8 Switch Language"); 
            System.out.println(menuLines.getString("M0M99").length()>0?menuLines.getString("M0M99"):"  0 Exit"); 
            System.out.println(strDivider);
            strPrintln = menuLines.getString("M0MP0").length()>0?menuLines.getString("M0MP0"):" Enter menu option number:";
            optionVal = readlnInt(strPrintln);
            if (optionVal == 8) {
                System.out.println(myLocale.getLanguage());
                if ("en".equals(myLocale.getLanguage())) {
                    myLocale = new Locale("cn", "ZH");
                } else {
                    myLocale = new Locale("en", "UK");
                }
                continue;
            }

            if ((optionVal == 1) || (optionVal == 2) || (optionVal == 3) || (optionVal == 4) || (optionVal == 7) || (optionVal == 0)) {
                booOK = true;
            }
            else {
                System.out.println(menuLines.getString("M0MP9").length()>0?menuLines.getString("M0MP9"):" Invalid option, please try again.");
            }
        } while (!booOK);
        return optionVal;
    }
    
    
    
    public static void main(String[] args) throws Exception  {
        prepLogger();
        myLocale = new Locale("en", "UK");
        LOGGER.log(Level.INFO, "Language set to en_UK by default.");
        int optionVal;
        do {
            optionVal = mainMenu();
            LOGGER.log(Level.INFO, "User selected from main menu the option {0}",new Object[]{optionVal});
            printHeader();
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {
                case 1:
                    System.out.println("Insert Customer  ");
                    printFooter();
                    insCust();
                    break;
                case 2:
                    System.out.println("List Customers ::: ");
                    listCusts(0);
                    break;
                case 3:
                    System.out.println("List Accounts ::: ");
                    listAccts(0, 0);
                    break;
                case 4:
                    System.out.println("Launch FXML mode ::: ");
                    listTrans(0, 0, 0);
                    break;
                case 7:
                    System.out.println("List Transactions ::: ");
                    launch(args);
                    break;
                case 0:
                    System.out.println("Exit");
                    printFooter();
                    LOGGER.log(Level.INFO, "Application terminated peacefully");
                    System.exit(0);
                    break;
            }
            printFooter();
            //System.out.print(" Press any key to continue.....");
            //myObj.nextLine();
        } while (optionVal != 99);

    }

    private static void prepLogger() {
        
       try{
            LOGGER.setUseParentHandlers(false);

            //Creating fileHandler
            fileHandler  = new FileHandler("./javacodegeeks.log");
            
            //Assigning handlers to LOGGER object
            LOGGER.addHandler(fileHandler);
             
            //Setting levels to handlers and LOGGER
            // fileHandler.setLevel(Level.ALL);
            LOGGER.setLevel(Level.ALL);
            
            LOGGER.info("Finnest message: Logger with DEFAULT FORMATTER");

            messageFormatter = new SimpleFormatter();
            fileHandler.setFormatter(messageFormatter);
            LOGGER.info("Finnest message: Logger with SIMPLE FORMATTER");

            messageFormatter = new XMLFormatter();
            fileHandler.setFormatter(messageFormatter);
            LOGGER.info("Finnest message: Logger with XML FORMATTER");

            LOGGER.log(Level.INFO, "Logger Name: {0}", LOGGER.getName());
             
             
        }catch(IOException exception){
            LOGGER.log(Level.SEVERE, "Error occur in FileHandler.", exception);
        }
        LOGGER.config("Configuration done.");
    }
    
}
