package onebank;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TranDAO {

    public static int newCashTran(int i_AcctNum, float i_TranAmt, int i_AcctNum2, String i_CustName) throws Exception{
        
        Connection conn = Utility.initConn();
        String qStmt = "{CALL newCashTran(" + i_AcctNum + ", ' ', " + String.format("%.02f", i_TranAmt) + ", " + i_AcctNum2 + ", '" + i_CustName + "')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        int retnCode = 9999;
        String retnMsg = "";
        int tranId = 0;
        int acctNum = 0;
        int custId = 0;
        
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            retnCode = rs.getInt("RetnCode");
            retnMsg = rs.getString("RetnMsg");
            tranId = rs.getInt("TranId");
            acctNum = rs.getInt("AcctNum");
            custId = rs.getInt("CustId");
            break;
        }

        if (retnCode == 0) {
            System.out.println(" Insert Success ");
        }else {
            System.out.println("Insert Failed: " + retnMsg 
                    + (tranId>0?("(" + Integer.toString(tranId) + ")"):"")
                    + (acctNum>0?("(" + Integer.toString(acctNum) + ")"):"")
                    + (custId>0?("(" + Integer.toString(custId) + ")"):""));
        }
        return tranId;
    }
    
    

    public static List <Tran> findTran(int intTranId, int intAcctNum, int intCustId, char chrSele, char chrSort) throws Exception{
        List <Tran> tranList = new ArrayList<>();

        Connection conn = Utility.initConn();
        String qStmt = "{CALL findTran(" + intTranId + "," + intAcctNum + "," + intCustId + ",'" + chrSele + "', '" + chrSort + "')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
                tranList.add(new Tran(rs.getInt("TranId"), rs.getInt("AcctNum"), rs.getString("TranType").charAt(0), rs.getString("TranDesc"),
                                      rs.getFloat("TranAmt"), rs.getString("TranStts").charAt(0), rs.getInt("ChqNum"), 
                                      rs.getDate("TranDate").toLocalDate(), rs.getDate("EffDate").toLocalDate(), rs.getInt("TranIdRel"), rs.getTimestamp("Sysclock").toLocalDateTime()));
        }
        return tranList;
    }  


    public static Tran getTran(int tid) throws Exception{
        Tran myTran = null;
        Connection conn = Utility.initConn();
        String qStmt = "{CALL findTran(" + tid + ",0,0,'','')}";
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();

        while(rs.next()){
            myTran = new Tran(rs.getInt("TranId"), rs.getInt("AcctNum"), rs.getString("TranType").charAt(0), rs.getString("TranDesc"), rs.getFloat("TranAmt"),
                    rs.getString("TranStts").charAt(0), rs.getInt("ChqNum"), rs.getDate("TranDate").toLocalDate(), rs.getDate("EffDate").toLocalDate(),
                    rs.getInt("TranIdRel"), rs.getTimestamp("SysClock").toLocalDateTime());
            break;
        }
        return myTran;
        
    }
    
}


