package onebank;

import java.net.URL;
import java.time.LocalDate;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;

public class cOpsController implements Initializable {

    private static int status = 0;
    private Customer cust;
    
    @FXML
    private Button insertBtn;
    @FXML
    private Button updateBtn;
    @FXML
    private Button deactBtn;
    @FXML
    private Button resetBtn;
    @FXML
    private TextField custId;
    @FXML
    private TextField custName;
    @FXML
    private DatePicker custDOB;
    @FXML
    private TextField nric;
    @FXML
    private TextField addr1;
    @FXML
    private TextField addr2;
    @FXML
    private Pane dataPane;
    @FXML
    private Label lblCustName;
    @FXML
    private CheckBox isActive;
    @FXML
    private Button submitBtn;
    @FXML
    private Button fetchDetails;
    @FXML
    private Button cancelBtn;
    @FXML
    private Label lblLang;
    @FXML
    private RadioButton rbtnLang1;
    @FXML
    private RadioButton rbtnLang2;

    public void handleTab2ButtonBar() {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
            Main.menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",Main.myLocale);
        
            ToggleGroup radioGroup = new ToggleGroup();

            //to group radio buttons
            rbtnLang1.setToggleGroup(radioGroup);
            rbtnLang2.setToggleGroup(radioGroup);
            rbtnLang1.setSelected(true);
            lblLang.setText(Main.menuLines.getString("FXML00").length()>0?Main.menuLines.getString("FXML00"):"Switch Language");
            rbtnLang1.setText(Main.menuLines.getString("FXML01").length()>0?Main.menuLines.getString("FXML01"):"English");
            rbtnLang2.setText(Main.menuLines.getString("FXML02").length()>0?Main.menuLines.getString("FXML02"):"Chinese");
        
    }

    @FXML
    private void onCancel(ActionEvent event) {
        cleanupRight();
        backToLeft();
    }

    private void reset() {
        cleanupRight();
    }

    @FXML
    private void onSubmit(ActionEvent event) throws Exception {
        boolean booOK;
        boolean booOK1;
        switch (status) {
            case (1) :
                booOK = chkCustName();
                booOK1 = chkNric(); booOK = booOK && booOK1;
                booOK1 = chkCustDOB(); booOK = booOK && booOK1;
                booOK1 = chkAddr1(); booOK = booOK && booOK1;
                booOK1 = chkAddr2(); booOK = booOK && booOK1;
                if (booOK) {
                    cust = new Customer(custName.getText().trim(), nric.getText().trim(), addr1.getText().trim(), addr2.getText().trim(), custDOB.getValue());
                    int newCustId = CustomerDAO.newCustomer(cust);
                    cust = null;
                    if (newCustId == 0) {
                        Utility.showDialog("Insert failed", "Please check and corect flagged data and try again.");
                    } else {
                        Utility.showDialog("Insert success", "New Cust Id ".concat(Integer.toString(newCustId)));
                        fetchToPane(newCustId);
                        backToLeft();
                    }
                } else {
                    Utility.showDialog("Insert rejected", " Please correct high-lighted error.");
                }
                return;
            case (3) :
                booOK = chkCustName();
                booOK1 = chkNric(); booOK = booOK && booOK1;
                booOK1 = chkCustDOB(); booOK = booOK && booOK1;
                booOK1 = chkAddr1(); booOK = booOK && booOK1;
                booOK1 = chkAddr2(); booOK = booOK && booOK1;
                if (booOK) {
                    cust.setCustName(custName.getText());
                    cust.setCustDOB(custDOB.getValue());
                    cust.setNric(nric.getText());
                    cust.setAddr1(addr1.getText());
                    cust.setAddr2(addr2.getText());
                    if (CustomerDAO.updCustomer(cust)) {
                        Utility.showDialog("Update successful", "Customer record updated successfully.");
                        fetchToPane(cust.getCustId());
                    } else {
                        Utility.showDialog("Update failed", "Database error encountered, please report to IT.");
                    }
                    backToLeft();
                } else {
                    Utility.showDialog("Update rejected", "Please correct the flagged error");
                }
                break;
            case (4) : 
                char chrAnD = 'A';
                if (cust.getIsActive()) {
                    chrAnD = 'D';
                }
                if (CustomerDAO.andCustomer(cust.getCustId(), chrAnD)) { 
                    Utility.showDialog("Operation successful", (cust.getIsActive()?"D":"R").concat("e-activation is successful."));
                    fetchToPane(cust.getCustId());
                    backToLeft();
                } else {
                   Utility.showDialog(" Status Msg !!!", " De/Rec -activation Failed ");
                }
                break;
        }
    }

    @FXML
    private void onInsert(ActionEvent event) {
        cleanupRight();
        status = 1;
        fetchDetails.setDisable(true);
        submitBtn.setText("Insert");
        submitBtn.setDisable(false);
        cancelBtn.setDisable(false);
        custId.setDisable(true);
        custName.setDisable(false);
        nric.setDisable(false);
        custDOB.setDisable(false);
        addr1.setDisable(false);
        addr2.setDisable(false);
        dataPane.setDisable(false);
        insertBtn.setDisable(true);
        updateBtn.setDisable(true);
        deactBtn.setDisable(true);
        resetBtn.setDisable(true);
        
    }

    @FXML
    private void onUpdate(ActionEvent event) {
        cleanupRight();
        status = 2;
        fetchDetails.setDisable(false);
        custId.setDisable(false);
        custId.setPromptText("Enter Customer number to retrieve for update...");
        custName.setDisable(true);
        nric.setDisable(true);
        custDOB.setDisable(true);
        addr1.setDisable(true);
        addr2.setDisable(true);
        dataPane.setDisable(false);
        cancelBtn.setDisable(false);
        insertBtn.setDisable(true);
        updateBtn.setDisable(true);
        deactBtn.setDisable(true);
        resetBtn.setDisable(true);
    }

    @FXML
    private void onDactivate(ActionEvent event) {
        cleanupRight();
        status = 4;
        fetchDetails.setDisable(false);
        custId.setDisable(false);
        custId.setPromptText("Enter Customer number to retrieve to activate/deactivate...");
        cancelBtn.setDisable(false);
        dataPane.setDisable(false);
        insertBtn.setDisable(true);
        updateBtn.setDisable(true);
        deactBtn.setDisable(true);
        resetBtn.setDisable(true);
    }

    @FXML
    private void onReset(ActionEvent event) {
        status = 0;
        cleanupRight();
        backToLeft();
    }

    @FXML
    private void fetchDetails(ActionEvent event) throws Exception {
        int cID = Utility.myParseInt(custId.getText());
        if (cID <= 0) {
            Utility.showDialog("Invalid Customer Id[".concat(custId.getText()).concat("]"), "Customer Id are positive integers.");
            return;
        }        
        
        cust = CustomerDAO.getCustomer(cID);
        if (cust == null) {
            Utility.showDialog("Customer not found", " Customer " + Integer.toString(cID) + " not Found.");
            return;
        }
        
        custId.setText(Integer.toString(cust.getCustId()));
        custName.setText(cust.getCustName());
        nric.setText(cust.getNric());
        custDOB.setValue(cust.getCustDOB());
        addr1.setText(cust.getAddr1());
        addr2.setText(cust.getAddr2());
        isActive.setSelected(cust.getIsActive());
        fetchDetails.setDisable(true);

        if (status == 2) {
            status = 3;
            submitBtn.setText("Update");
            submitBtn.setDisable(false);
            custId.setDisable(true);
            custName.setDisable(false);
            nric.setDisable(false);
            custDOB.setDisable(false);
            addr1.setDisable(false);
            addr2.setDisable(false);
        } else {
            if (status == 4) {
                if (cust.getIsActive()) {
                    submitBtn.setText("De-activate");
                } else {
                    submitBtn.setText("Re-activate");
                }
                submitBtn.setDisable(false);
                custId.setDisable(true);
            }
        }
    }

    
    @FXML
    private void onChoiLang(ActionEvent event) throws Exception {
        if (event.getSource().toString().contains("Lang1")) {
            Main.myLocale = new Locale("en", "UK");
        } else {
            Main.myLocale = new Locale("cn", "ZH");
        }
        Main.menuLines = ResourceBundle.getBundle("bundles.menu_Bundle",Main.myLocale);
        lblLang.setText(Main.menuLines.getString("FXML00").length()>0?Main.menuLines.getString("FXML00"):"Switch Language");

        insertBtn.setText(Main.menuLines.getString("FXMABI").length()>0?Main.menuLines.getString("FXMABI"):"Insert");
        updateBtn.setText(Main.menuLines.getString("FXMABU").length()>0?Main.menuLines.getString("FXMABU"):"Update");
        deactBtn.setText(Main.menuLines.getString("FXMABD").length()>0?Main.menuLines.getString("FXMABD"):"De/Re -activate");
        resetBtn.setText(Main.menuLines.getString("FXMABR").length()>0?Main.menuLines.getString("FXMABR"):"Reset");
        lblCustName.setText(Main.menuLines.getString("FXMAL2").length()>0?Main.menuLines.getString("FXMAL2"):"Name");
        
    }

    private boolean chkCustName() {
        String cName = custName.getText().trim();
        if ((cName.length() == 0) || (cName.length() > 45)) {
            custName.setStyle("-fx-background-color: pink;");
            return false;
        } else {
            custName.setStyle("");
            return true;
        }
    }

    private boolean chkNric() {
        String cNric = nric.getText().trim();
        if (cNric.length() == 9) {
            nric.setStyle("");
            return true;
        } else {
            nric.setStyle("-fx-background-color: pink;");
            return false;
        }
    }
    
    private boolean chkCustDOB() {
        return true;
    }

    private boolean chkAddr1() {
        String cAddr1 = addr1.getText().trim();
        if ((cAddr1.length() == 0) || (cAddr1.length() > 30)) {
            addr1.setStyle("-fx-background-color: pink;");
            return false;
        } else {
            addr1.setStyle("");
            return true;
        }
    }
    
    private boolean chkAddr2() {
        String cAddr2 = addr2.getText().trim();
        if ((cAddr2.length() == 0) || (cAddr2.length() > 30)) {
            addr2.setStyle("-fx-background-color: pink;");
            return false;
        } else {
            addr2.setStyle("");
            return true;
        }
    }

    private void backToLeft() {
        dataPane.setDisable(true);
        fetchDetails.setDisable(true);
        custId.setStyle("");
        custName.setStyle("");
        nric.setStyle("");
        custDOB.setStyle("");
        addr1.setStyle("");
        addr2.setStyle("");
        custId.setDisable(true);
        custName.setDisable(true);
        nric.setDisable(true);
        custDOB.setDisable(true);
        addr1.setDisable(true);
        addr2.setDisable(true);
        submitBtn.setDisable(true);
        submitBtn.setText("Submit");
        cancelBtn.setDisable(true);
        insertBtn.setDisable(false);
        updateBtn.setDisable(false);
        deactBtn.setDisable(false);
        resetBtn.setDisable(false);
        status = 0;
        cust = null;
    }
    
    private void cleanupRight(){
        custId.setText("");
        custName.setText("");
        custName.setPromptText(" ");
        custDOB.setValue(LocalDate.now().minusYears(20));
        custDOB.setPromptText(" ");
        nric.setText("");
        nric.setPromptText(" ");
        addr1.setText("");
        addr1.setPromptText(" ");
        addr2.setText("");
        addr2.setPromptText(" ");
        isActive.setSelected(false);
    }

    private void fetchToPane(int cID) {
        Customer cust = CustomerDAO.getCustomer(cID);
        custId.setText(Integer.toString(cust.getCustId()));
        custName.setText(cust.getCustName());
        nric.setText(cust.getNric());
        custDOB.setValue(cust.getCustDOB());
        addr1.setText(cust.getAddr1());
        addr2.setText(cust.getAddr2());
        isActive.setSelected(cust.getIsActive());
    }
}
