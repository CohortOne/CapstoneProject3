package onebank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import static onebank.Main.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;

public class Utility {
    private static final String strDBhost = "localhost";
    private static final String strDBport = "3306";
    private static final String strDBschm = "onebank";
    private static final String strDBuser = "allrounder";
    private static final String strDBpass = "password";
    private static final String strDBconn = "jdbc:mysql://" + strDBhost + ":" + strDBport + "/" 
                                          + strDBschm + "?useTimezone=true&serverTimezone=UTC&"
                                          + "user=" + strDBuser + "&password=" + strDBpass;

    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn = null;

        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection(strDBconn);

        return conn;
    }

    public static String fmtString(String inStr, int inLen) {
        String returnStr = "";
        returnStr = returnStr + inStr;
            if (inLen > 0) {
                if (returnStr.length() > inLen) {
                    returnStr = returnStr.substring(0,inLen);
                } else {
                    returnStr = returnStr + " ".repeat(inLen - returnStr.length()) ;
                }
            } else {
                inLen = - inLen;
                if (returnStr.length() > inLen) {
                    returnStr = returnStr.substring(returnStr.length() - inLen,returnStr.length());
                } else {
                    returnStr = " ".repeat(inLen - returnStr.length()) + returnStr ;
                }
            }
        return returnStr;
    }


    public static String fmtInt(int inInt, int inLen) {
    String returnStr = "";
        returnStr = returnStr + inInt;
        if (inLen > 0) {
            if (returnStr.length() > inLen) {
                returnStr = returnStr.substring(0,inLen);
            } else {
                returnStr = returnStr + " ".repeat(inLen - returnStr.length()) ;
            }
        } else {
            inLen = - inLen;
            if (returnStr.length() > inLen) {
                returnStr = returnStr.substring(returnStr.length() - inLen,returnStr.length());
            } else {
                returnStr = " ".repeat(inLen - returnStr.length()) + returnStr ;
            }
        }
        return returnStr;
    }

    public static String fmtFloat(float inFloat, int inLen, int inDec) {
    String returnStr;
        if (inDec == 2) {
            returnStr = String.format("%,.02f", inFloat);
        }
        else {
            returnStr = String.format("%,.00f", inFloat);
        }
        if (inLen > 0) {
            if (returnStr.length() > inLen) {
                returnStr = returnStr.substring(0,inLen);
            } else {
                returnStr = returnStr + " ".repeat(inLen - returnStr.length()) ;
            }
        } else {
            inLen = - inLen;
            if (returnStr.length() > inLen) {
                returnStr = returnStr.substring(returnStr.length() - inLen,returnStr.length());
            } else {
                returnStr = " ".repeat(inLen - returnStr.length()) + returnStr ;
            }
        }
        return returnStr;
    }

        
    public static void pause4Enter() {
        //String strInput = null;
        //System.out.print("Press <Enter> to continue.....:");
        //strInput = myObj.nextLine();
    }
    
    public static int readlnInt(String strPrompt) {
        String strInput = null;
        int intOpt = 0;
        do {
            System.out.print(strPrompt);
            try {
                intOpt = -1;
                strInput = myObj.nextLine().trim();
                intOpt = Integer.parseInt(strInput);
            } catch (Exception e) {
                    System.out.println("[" + strInput + "] is not a valid input, please try again...");
            }
        } while (intOpt < 0);
        return intOpt;
    }

        
    public static int myParseInt(String strInp) {
        int intOpt = 0;
        try {intOpt = Integer.parseInt(strInp);} catch (Exception e) {intOpt = -1;}
        return intOpt;
    }
    

    public static void showDialog(String title, String msg) {
        Dialog<String> dialog = new Dialog<String>();
        dialog.setTitle(title);
        ButtonType type = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.setContentText(msg);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    

    public static float readlnFloat(String strPrompt) {
        String strInput;
        float floatInp = 0;
        boolean booOK;
        do {
            booOK = true;
            System.out.print(strPrompt);
            strInput = myObj.nextLine().trim();
            try {
                floatInp = Float.parseFloat(strInput);
            } catch (Exception e) {
                System.out.println("[" + strInput + "] is not a valid amount, please try again...");
                booOK = false;
                continue;
            }
            if (booOK && (floatInp < 0)) {
                System.out.println("Only positive amount allowed, please try again...");
                booOK = false;
                continue;
            }
            floatInp = floatInp * 100;
            if (booOK && (floatInp != Math.round(floatInp))) {
                System.out.println("Only two decimal places allowed, please try again...");
                booOK = false;
                continue;
            }
            floatInp = floatInp / 100;
        } while (!booOK);
        return floatInp;
    }

    public static void printHeader() throws Exception {
        //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println("\n".repeat(4));
        System.out.println(" " + "=".repeat(126));
        printFooter();

    }

    public static void printFooter() {
        System.out.println("=".repeat(126));
    }

    
}
