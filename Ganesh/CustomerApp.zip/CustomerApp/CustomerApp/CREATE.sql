CREATE TABLE `Accounts` (
  `accID` int NOT NULL,
  `NRIC` varchar(45) NOT NULL,
  `accStartDate` date DEFAULT NULL,
  `accountNo` int NOT NULL,
  `interestRate` double DEFAULT NULL,
  `cDeposit` double DEFAULT NULL,
  `cWithdraw` double DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `active` tinyint DEFAULT NULL,
  PRIMARY KEY (`NRIC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci