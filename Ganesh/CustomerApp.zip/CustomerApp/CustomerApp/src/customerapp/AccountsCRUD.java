
package customerapp;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class AccountsCRUD {

    public static Scanner myObj = new Scanner(System.in);
    public static int iteration = 1;

    public static void toContinue() {
        myObj.next();
    }

    public static String printPretty() {
        String s = "\n  |";
        for (int i = 0; i <= iteration; i++) {
            s += "---";
        }

        return s + " >> ";
    }

    public static int listAccounts() throws Exception {
        printHeader();
        System.out.println("\taccID   \tNRIC \taccStartDate \taccountNo \tinterestRate \tcDeposit \tcWithdrawal \tbalance \tStatus");
        printFooter();
        AccountsDAO.listAccounts().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }    
    
    public static int listAccountsByaccStartDate() throws Exception {
        printHeader();
        System.out.println("\taccID   \tNRIC \taccStartDate \taccountNo \tinterestRate \tcDeposit \tcWithdrawal \tbalance \tStatus");
        printFooter();
        AccountsDAO.listAccountsOrderByaccStartDate().stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
/*
    public static int findCustomerByaccountNo() throws Exception {
        printHeader();
        System.out.print(" \tEnter the accountNo to Find :: ");
        int accountNo = myObj.nextInt();
        
        printHeader();
        System.out.println("\taccID \tNRIC \t\t\taccStartDate  \t\taccountNo \tinterestRate \tcDeposit \tcWithdrawal \tbalance \tStatus");
        printFooter();
        AccountsDAO.getAccounts(accountNo).stream().forEach(System.out::println);
        printFooter();
        return 1;
    }
    
    public static int Withdraw() throws Exception {
        listAccounts();
        System.out.print(" \tEnter the Customer ID to Delete :: ");
        int wid = myObj.nextInt();
        //System.out.print(" \tAre you sure [y/n][Y/N]:: ");
       // String resp = myObj.next();
        if (wid == AccountsDAO.getAccounts(accountNo)) {
            System.out.println(" Initiating Withdrawal from Account No::" + wid);
            printHeader();
            AccountsDAO.withdrawAccounts(wid);
            printFooter();
        }
        return 1;
    }

    public static int Deposit() throws Exception {
        listAccounts();
        System.out.print(" \tEnter the Account No to Deposit :: ");
        int did = myObj.nextInt();
        //System.out.print(" \t You can only update Email and PhoneNo [Y/N][y/n]:: ");
        //String resp = myObj.next();
        if (did == AccountsDAO.getAccounts(accountNo)) {
            System.out.println(" Initiating Deposit for Account No::" + did);
            printHeader();
            AccountsDAO.depositAccounts(did);
            //System.out.println(" Select Customer ::: ");
            //System.out.print(c);
            printFooter();
            }
        return 1;
    }
    */
/*
            System.out.println(" \n\t\t   Current Email   \t : " + c.getEmail());
            System.out.print(" \n\t\t   New Email       \t : ");
            c.setEmail(myObj.next());
            System.out.println(" \n\t\t    Current Phone    \t : " + c.getPhoneNo());
            System.out.print(" \n\t\t    New  Phone          \t : ");
            c.setPhoneNo(myObj.next());
            AccountsDAO.updateCustomer(c);
            printFooter();*/
        

    public static int addAccounts() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        int nxtID = AccountsDAO.getNextID();
        System.out.println(" \tEnter the following details  :: ");
        printFooter();
        System.out.println(" \n\t\t        Account ID    \t : " + nxtID);
        System.out.print(" \n\t\t        NRIC     \t : ");
        String NRIC = myObj.next();
        System.out.print(" \n\t\t  Account Start Date  \t : ");
        String accStartDate = myObj.next();
        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse(accStartDate, sourceFormatter);
        System.out.print(" \n\t\t        Account No          \t : ");
        int accountNo = myObj.nextInt();
        System.out.print(" \n\t\t        Interest Rate          \t : ");
        double interestRate = myObj.nextDouble();
        System.out.print(" \n\t\t        Deposit          \t : ");
        double cDeposit = myObj.nextDouble();
        System.out.print(" \n\t\t        Withdrawal          \t : ");
        double cWithdraw = myObj.nextDouble();
        System.out.print(" \n\t\t        Balance          \t : ");
        double balance = myObj.nextDouble();
        printHeader();
        if (AccountsDAO.addAccounts(new Accounts(nxtID, NRIC, date, accountNo, interestRate, cDeposit, cWithdraw, balance, (byte) 1))) {
            printFooter();
        }
        return 1;
    }

    public static int DisplayOptions() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\t Customer CRUD Operations ::: ");
        System.out.println(" \t----------------------------------");
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \tFollowing are the options :: ");
        System.out.println(" \n\t\t1 >> Add Account ");
        System.out.println(" \n\t\t2 >> Deposit ");
        System.out.println(" \n\t\t3 >> Withdraw ");
        System.out.println(" \n\t\t4 >> List Accounts "); 
        System.out.println(" \n\t\t5 >> List Accounts Order By accStartDate ");
        System.out.println(" \n\t\t6 >> Find Accounts By AccountNo ");
        System.out.println(" \n\t\t0 >> Exit ");

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" Enter a number to carry out the operation  :   ");
        int optVal;
        try {
            optVal = myObj.nextInt();
        } catch (Exception e) {

            optVal = -1;
        }
        return optVal;
    }

    public static void printHeader() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" ==============================================================================================================================");

    }

    public static void printFooter() {
        System.out.println(" ==============================================================================================================================");
    }

    public static void main(String[] args) throws Exception {
        while (true) {
            int optionVal = DisplayOptions();

            printHeader();
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {

                case 1:
                    System.out.println("Add Account  ");
                    printFooter();
                    addAccounts();
                    break;
              /*
                case 2:
                    System.out.println("Update Customer ::: ");
                    Deposit();
                    break;
                case 3:
                    System.out.println("Delete Customer ::: ");
                    Withdraw();
                    break;
*/
                case 4:
                    System.out.println("List Accounts ::: ");
                    listAccounts();
                    break;
                case 5:
                    System.out.println("List Accounts ::: ");
                    listAccountsByaccStartDate();
                    break;
                 /*   
                case 6:
                    System.out.println("Find Accounts By account No::: ");
                    findCustomerByaccountNo();
                    break;
*/
                case 0:
                    System.out.println("Exit");
                    printFooter();
                    Thread.sleep(4000);
                    System.exit(0);
                    break;
                default:
                    //printHeader();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    printFooter();
                    Thread.sleep(4000);
                    break;
            }

            printFooter();
            System.out.print(" Press any key to continue.....");
            toContinue();
        }
    }

}
