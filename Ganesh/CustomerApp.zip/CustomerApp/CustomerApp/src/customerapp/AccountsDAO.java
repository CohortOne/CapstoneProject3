/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

//import com.mysql.cj.jdbc.CallableStatement;
import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;

/**
 *
 * @author chand
 */
public class AccountsDAO {

    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql_2020");

        return conn;
    }
    
    public static int getNextID(){
        int nxtID = 0;
        try{
            Statement stmt = AccountsDAO.init();
            String nxID = "select max(accID) from bank.Accounts;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;        
        }catch(Exception e){
            System.out.println(" Exception from AccountsDAO :: " + e.getMessage());
            e.printStackTrace();
        }
        return nxtID;
    }
    
    public static boolean addAccounts(Accounts c) throws Exception{
        Statement stmt = AccountsDAO.init();
        
        String insStmt = "insert into Accounts (accID, NRIC, accStartDate, accountNo, phoneNo, active) "
                + " values(" + c.getAccID()+ 
                ",\"" + c.getNRIC() + "\",DATE(\"" + c.getAccStartDate().toString() +"\"),"
                + "\"" + c.getAccountNo()+ "\"," + c.getInterestRate() + "\"," + c.getcDeposit() + "\"," 
                + c.getcWithdraw() + "\"," + c.getBalance() + "," + c.getStatus()+");";
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }   
    
        public static boolean depositAccounts(int did) throws Exception{
        Statement stmt = AccountsDAO.init();
        String updStmt = "Add from bank.Accounts where accountNo = balance + did;"; 
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Deposi Success ");
        }else {
           System.out.println(" Deposit Failed ");
        }
        return true;
    }
        
    public static boolean withdrawAccounts(int wid) throws Exception{
        Statement stmt = AccountsDAO.init();     
        String delStmt = "Subtract from bank.Accounts where accountNo = balance - wid;";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Withdrawal Success ");
        }else {
            System.out.println(" Withdrawal  Fail ");
        }
        return true;
    }
    
    public static List <Accounts> listAccounts() throws Exception{
        Statement stmt = AccountsDAO.init();
        List <Accounts> accList = new ArrayList<>();
        String qStmt = "Select * from bank.Accounts;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            accList.add(new Accounts(rs.getInt("accID"),rs.getString("NRIC"),rs.getDate("accStartDate").toLocalDate(),rs.getInt("accountNo"),rs.getDouble("interestRate"),rs.getDouble("cDeposit"),rs.getDouble("cWithdraw"),rs.getDouble("balance"),rs.getByte("Status")));
        }
        return accList;
    }  
    
    public static List <Accounts> listAccountsOrderByaccStartDate() throws Exception{
        Connection conn = AccountsDAO.initConn();
        List <Accounts> accList = new ArrayList<>();
        String qStmt = "{CALL GetAccounts()}";
        
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            Accounts c = new Accounts(rs.getInt("accID"),rs.getString("NRIC"),rs.getDate("accStartDate").toLocalDate(),rs.getInt("accountNo"),rs.getDouble("interestRate"),rs.getDouble("cDeposit"),rs.getDouble("cWithdraw"),rs.getDouble("balance"),(byte)1);
            accList.add(c);
        }
        return accList;
    }
    
    public static Accounts getAccounts(int accID) throws Exception{
        Statement stmt = AccountsDAO.init();
        Accounts acc = null;
        String qStmt = "Select * from bank.Accounts where accID = " + accID + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            acc = new Accounts(rs.getInt("accID"),rs.getString("NRIC"),rs.getDate("accStartDate").toLocalDate(),rs.getInt("accountNo"),rs.getDouble("interestRate"),rs.getDouble("cDeposit"),rs.getDouble("cWithdraw"),rs.getDouble("balance"),rs.getByte("Status"));
        }
        return acc;
    }
    
    public static List <Accounts> getAccounts(String accountNo) throws Exception{
        Connection conn = AccountsDAO.initConn();
        List <Accounts> accList = new ArrayList<>();
        String qStmt = "Select * from bank.Accounts where accountNo = ? ";
        
        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, accountNo);
        ResultSet rs = pStmt.executeQuery();
        while(rs.next()){
            accList.add(new Accounts(rs.getInt("accID"),rs.getString("NRIC"),rs.getDate("accStartDate").toLocalDate(),rs.getInt("accountNo"),rs.getDouble("interestRate"),rs.getDouble("cDeposit"),rs.getDouble("cWithdraw"),rs.getDouble("balance"),rs.getByte("Status")));
        }
        return accList;
    }

}
