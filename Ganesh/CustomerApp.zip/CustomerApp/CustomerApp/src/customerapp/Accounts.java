/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerapp;

import java.time.LocalDate;

/**
 *
 * @author gnsna
 */
public class Accounts {
        
    private int accID;
    private String NRIC;
    private LocalDate accStartDate; 
    private int accountNo;
    private double interestRate;
    private double cDeposit;
    private double cWithdraw;
    private double balance;
    private byte Status;

    Accounts(int nxtID, String NRIC, LocalDate date, int accountNo, double interestRate, double cDeposit, double balance, byte b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "\t" + accID + "\t " + NRIC + "\t " + accStartDate + "\t" + accountNo + "\t" + interestRate  + " \t" + cDeposit + "\t " + cWithdraw + "\t" + balance + " \t" + (Status==1 ? true : false);
        //return "Accounts{" + "accStartDate=" + accStartDate + ", accountNo=" + accountNo + ", interestRate=" + interestRate + ", Balance=" + Balance + '}';
    }

    public Accounts(int accID, String NRIC, LocalDate accStartDate, int accountNo, double interestRate, double cDeposit, double cWithdraw, double balance, byte Status) {
        this.accID = accID;
        this.NRIC = NRIC;
        this.accStartDate = accStartDate;
        this.accountNo = accountNo;
        this.interestRate = interestRate;
        this.cDeposit = cDeposit;
        this.cWithdraw = cWithdraw;
        this.balance = balance;
        this.Status = Status;
    }

    public String getNRIC() {
        return NRIC;
    }

    public void setNRIC(String NRIC) {
        this.NRIC = NRIC;
    }

    public double getcDeposit() {
        return cDeposit;
    }

    public void setcDeposit(double cDeposit) {
        this.cDeposit = cDeposit;
    }

    public double getcWithdraw() {
        return cWithdraw;
    }

    public void setcWithdraw(double cWithdraw) {
        this.cWithdraw = cWithdraw;
    }
    
    public int getAccID() {
        return accID;
    }

    public void setAccID(int accID) {
        this.accID = accID;
    }
    
    public LocalDate getAccStartDate() {
        return accStartDate;
    }

    public void setAccStartDate(LocalDate accStartDate) {
        this.accStartDate = accStartDate;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getBalance() {
        return balance;
    }

    public byte getStatus() {
        return Status;
    }

    public void setStatus(byte Status) {
        this.Status = Status;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

}
