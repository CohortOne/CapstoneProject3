INSERT INTO `bank`.`accounts`
(`accID`,`NRIC`,`accStartDate`,`accountNo`,`interestRate`)
VALUES
(4,
'T4563456H',
'2019-11-25',
112344,
'0.1')
