DELIMITER $$

CREATE procedure GetCustomers()
BEGIN
	select custID, custName, DOB, phoneNo, email
	from bank.customer
	order by DOB;
END$$
DELIMITER ;


call GetCustomers();
