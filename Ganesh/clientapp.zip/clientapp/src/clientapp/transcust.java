
package clientapp;

import java.time.LocalDate;

 
public class transcust {
    private String name;
    private LocalDate Date;
    private int Amount;
    private String Desc;
    //private String NRIC;
    private byte status;
    private int Ref;

    public transcust(int Ref, String name, LocalDate Date, String Desc, int Amount, byte status) {
        this.Ref = Ref;
        this.name = name;
        this.Date = Date;
        this.Desc = Desc;
        this.Amount = Amount;
        this.status = status;
        
    }

    
    @Override
    public String toString() {
        return "\t" + Ref + "\t " + name + "\t\t" + Date + "\t" + Desc  + " \t " + Amount + " \t" + (status==1 ? true : false);
        //return "cust{" + "name=" + name + ", Date=" + Date + ", Amount=" + Amount + ", Desc=" + Desc + ", status=" + status + ", Ref=" + Ref + '}';
    }

   

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDate() {
        return Date;
    }

    public void setDate(LocalDate Date) {
        this.Date = Date;
    }

    public int getAmount() {
        return Amount;
    }

    public void setAmount(int Amount) {
        this.Amount = Amount;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String Desc) {
        this.Desc = Desc;
    }
/*
    public String getNRIC() {
        return NRIC;
    }

    public void setNRIC(String NRIC) {
        this.NRIC = NRIC;
    }
*/
    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public int getRef() {
        return Ref;
    }

    public void setRef(int Ref) {
        this.Ref = Ref;
    }

    
}
