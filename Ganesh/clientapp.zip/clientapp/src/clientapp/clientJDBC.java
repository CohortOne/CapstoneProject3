
package clientapp;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class clientJDBC {
     public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql_2020");

        return conn;
    }
    
    public static int getNextID(){
        int nxtID = 20201120;
        try{
            Statement stmt = clientJDBC.init();
            String nxID = "select max(Ref) from bank.transcust;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;        
        }catch(Exception e){
            System.out.println(" Exception from clientJDBC :: " + e.getMessage());
        }
        return nxtID;
    }
    
    public static boolean insertCustomer(transcust c) throws Exception{
        Statement stmt = clientJDBC.init();
        
        String insStmt = "insert into bank.transcust (Ref, cName, cDate, cDesc, Amount) "
                + " values(" + c.getRef() + 
                ",\"" + c.getName() + "\",DATE(\"" + c.getDate().toString() +"\"),"
                + "\"" + c.getDesc() + "\"," + c.getAmount() + "," + c.getStatus() +");";
        System.out.println(insStmt);
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }    
    
    public static boolean delCustomer(int cid) throws Exception{
        Statement stmt = clientJDBC.init();     
        String delStmt = "delete from bank.transcust where Ref = " + cid + ";";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Delete Success ");
        }else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }
    
    public static List <transcust> listCustomer() throws Exception{
        Statement stmt = clientJDBC.init();
        List <transcust> custList = new ArrayList<>();
        String qStmt = "Select * from bank.transcust;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            custList.add(new transcust(rs.getInt("Ref"),rs.getString("name"),rs.getDate("Date").toLocalDate(),rs.getString("Desc"),rs.getInt("Amount"),rs.getByte("status"))            );
        }
        return custList;
    }  
    
    public static List <transcust> listCustomerOrderByDate() throws Exception{
        Connection conn = clientJDBC.initConn();
        List <transcust> custList = new ArrayList<>();
        String qStmt = "{CALL GetCustomer()}";
        
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            transcust c = new transcust(rs.getInt("Ref"),rs.getString("name"),rs.getDate("Date").toLocalDate(),rs.getString("Desc"),rs.getInt("Amount"),(byte)1);
            custList.add(c);
        }
        return custList;
    }
    
    public static transcust getCustomer(int Ref) throws Exception{
        Statement stmt = clientJDBC.init();
        transcust cust = null;
        String qStmt = "Select * from bank.transcust where Ref = " + Ref + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            cust = new transcust(rs.getInt("Ref"),rs.getString("name"),rs.getDate("Date").toLocalDate(),rs.getString("Desc"),rs.getInt("Amount"),rs.getByte("status"));
        }
        return cust;
    }
    
    public static List <transcust> getCustomer(String Amount) throws Exception{
        Connection conn = clientJDBC.initConn();
        List <transcust> custList = new ArrayList<>();
        String qStmt = "Select * from bank.transcust where Amount = ? ";
        
        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, Amount);
        ResultSet rs = pStmt.executeQuery();
        while(rs.next()){
            custList.add(new transcust(rs.getInt("Ref"),rs.getString("name"),rs.getDate("Date").toLocalDate(),rs.getString("Desc"),rs.getInt("Amount"),rs.getByte("status")));
        }
        return custList;
    }
    
    public static boolean updateCustomer(transcust c) throws Exception{
        Statement stmt = clientJDBC.init();
        String updStmt = "Update bank.transcust set Desc = '" + c.getDesc() + "', Amount = '" + c.getAmount()+ "' where Ref = " + c.getRef() + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
    
    
}
