/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.FileInputStream;
import java.util.logging.*;


public class LogUtil {
     private static final Logger LOGGER = Logger.getLogger(LogUtil.class.getName());
//     static{
//         try {
//             LogUtil.loadLogConfig();
//         } catch (Exception ex) {
//            LogUtil.doExceptionLog(Level.SEVERE, "Failed to initialize logger configs", ex);
//         }
//     }
     
    
    public static void doInfoLog(String s){
        LOGGER.info(s);
    }
    
    public static void doErrorLog(String s){
    
    }
    
    public static void doWarnLog(String s){
    
    }
    
    public static void doSevereLog(String s){
    
    }
    
    public static void doExceptionLog(Level x, String s, Exception e){
        LOGGER.log(x, s, e);
    }
    
//    public static void loadLogConfig () {
//        
////        LogManager.getLogManager().readConfiguration(new FileInputStream("C:\\Users\\wakar\\OneDrive\\Desktop\\log_vRJ2.properties"));
//        
//        
////        LOGGER.setUseParentHandlers(false);
//
////        Handler consoleHandler = new ConsoleHandler();
////        Handler fileHandler = new FileHandler("./bank.log", 10000, 2);
////        LOGGER.addHandler(fileHandler);
////        LOGGER.addHandler(consoleHandler);
////        
////        consoleHandler.setLevel(Level.SEVERE);
////        fileHandler.setLevel(Level.ALL);
//        LogUtil.doInfoLog("Logger Configuration Done");
        

    }

