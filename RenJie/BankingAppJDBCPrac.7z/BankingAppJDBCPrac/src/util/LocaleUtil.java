/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import static bankingappjdbcprac.BankingAppJDBCPrac.sc;

public class LocaleUtil {
    public static ResourceBundle msgs;
    static {
       LocaleUtil.initLocale();
        System.out.println("<<<<<<<<<<<<<<<<<<<<<<initLocale runs!!>>>>>>>>>>>>>>>>>");
    }
    
    public static void initLocale(){
        System.out.println("default english selected, to switch to chinese -> press any key, to choose default -> press 1");
        String country = "SG";
        int input = Integer.parseInt(sc.next());
        String language ="";
        if(input == 1){
            language = "en";
        }
        else{
            language = "zh";
        }
        
        
        Locale locale = new Locale(language, country);
        msgs = ResourceBundle.getBundle("bundles.Msg_Bundle", locale);
    }
    

    
    


    

}
