/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;

import static bankingappjdbcprac.BankingAppJDBCPrac.sc;
import static util.PrintingUtil.padRight;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author wakar
 */
public class SavingAccountMenu {
    public static void displayAcctMenu() throws Exception{
        while (true) {
            System.out.println("Account Operations Menu: ");
            
            System.out.println("1: Insert Account");
            System.out.println("2: List Accounts");
            System.out.println("3: Delete Account by accNo");
            System.out.println("4: Update Account's minBalance by accNo");
            System.out.println("0: Back to Main Menu");
            
            System.out.println("\nOption Selected : \t");
            int input = Integer.parseInt(sc.next());
            switch (input) {
                case 4:
                    System.out.println("Updating Account's minBalance");
                    UpdAccounts();
                    break;
                case 3:
                    System.out.println("Choosing Account to Delete... ");
                    DelAccounts();
                    break;
                case 2:
                    System.out.println("Listing Account... ");
                    ListAccounts();
                    break;
                case 1:
                    System.out.println("Inserting Account...  ");
                    insAccount();
                    break;
                
                case 0:
                    System.out.println("Returning...");
                    return;
                default:
                    //printHeader();
                    System.out.println(" \n\n #### Invalid Option ####");
                    Thread.sleep(2000);
                    break;
            }

            
            System.out.println(" Awaiting next operation...");
            
        }
    }
    
    public static int insAccount() throws Exception{
        
//        int nxtID = CustomerDAO.getNextID();
        System.out.println("Enter the following details  :: ");
        
//        System.out.println(" \n\t\t        Customer ID    \t : " + nxtID);
        System.out.println("accNo: ");
        int accNo = Integer.parseInt(sc.next());
        System.out.println("balance: ");
        Double balance = Double.parseDouble(sc.next());
        System.out.println("interestRate: ");
        Double interestRate = Double.parseDouble(sc.next());
        System.out.println("minBalance: ");
        Double minBalance = Double.parseDouble(sc.next());
        System.out.println("accountTypeID: ");
        int accountTypeID = Integer.parseInt(sc.next());


        LocalDateTime accountOpenDate = LocalDateTime.now();
        LocalDateTime accountClosedDate = null;
       
        if (SavingAccountDAO.insertAccount(new SavingAccount(accNo, balance, interestRate, accountOpenDate, accountClosedDate, minBalance, accountTypeID))){
            
        }
        return 1;
    }

    
    public static int ListAccounts() throws Exception{
        System.out.println(padRight("accNo", 20, ' ') + padRight("balance", 20, ' ') + padRight("interestRate", 20, ' ') + padRight("accountOpenDate", 20,  ' ') + padRight("accountClosedDate", 20, ' ') + padRight("minBalance", 20, ' ') + padRight("accountTypeID", 20, ' '));
        SavingAccountDAO.listAccounts().stream().forEach(System.out::println);
        return 1;
    }
    
    public static int DelAccounts() throws Exception{
        ListAccounts();
        System.out.print("\tEnter the accNo to Delete :: ");
        int accNo = Integer.parseInt(sc.next());
        System.out.print("\tAre you sure [y/n][Y/N]:: ");
        String resp = sc.next();
        if (resp.equalsIgnoreCase("y")){
            System.out.println(" Initiating delete for Account with accNo ::" + accNo);
            SavingAccountDAO.delAccount(accNo);
        }
        return 1;
    }
    
    public static int UpdAccounts() throws Exception{
        ListAccounts();
        System.out.println("\tEnter the accNo to Update :: ");
        int accNo = Integer.parseInt(sc.next());
        
        System.out.println(" Initiating update for Account with accNo ::" + accNo);
        SavingAccount s = SavingAccountDAO.getSavingAccount(accNo);
        System.out.println("\nCurrent minBalance  \t : " + s.getMinBalance());
        System.out.print("\nNew minBalance       \t : ");
        s.setMinBalance(Double.parseDouble(sc.next()));
        SavingAccountDAO.updAccount(s);
        
        return 1;
    }
}
