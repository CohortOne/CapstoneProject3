/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;

import static bankingappjdbcprac.BankingAppJDBCPrac.sc;
import static util.PrintingUtil.padRight;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author wakar
 */
public class CustomerMenu {
    
    public static void displayCustMenu() throws Exception{
        while (true) {
            System.out.println("Customer Operations Menu: ");
            
            System.out.println("1: Insert Customer");
            System.out.println("2: List Customer by DOB");
            System.out.println("3: Delete Customer by NRIC");
            System.out.println("4: Update Customer");
            
            System.out.println("0: Back to Main Menu");
            
            System.out.println("\nOption Selected : \t");
            int input = Integer.parseInt(sc.next());
            switch (input) {
                case 4:
                    System.out.println("Updating Customer by NRIC... ");
                    updCustomers();
                    break;
                case 3:
                    System.out.println("Deleting Customers by NRIC... ");
                    delCustomers();
                    break;
                case 2:
                    System.out.println("Listing Customers by DOB... ");
                    listCustomersByDOB();
                    break;
                case 1:
                    System.out.println("Inserting Customer...  ");
                    insCustomer();
                    break;
                
                case 0:
                    System.out.println("Returning...");
                    return;
                default:
                    //printHeader();
                    System.out.println(" \n\n #### Invalid Option ####");
                    Thread.sleep(2000);
                    break;
            }

            
            System.out.println(" Awaiting next operation...");
            
        }
    }
    
    
    
    public static int insCustomer() throws Exception{
        
//        int nxtID = CustomerDAO.getNextID();
        System.out.println("Enter the following details  :: ");
        
//        System.out.println(" \n\t\t        Customer ID    \t : " + nxtID);
        System.out.println("NRIC: ");
        int NRIC = Integer.parseInt(sc.next());
        System.out.println("name: ");
        String name = sc.next();
        System.out.println("address: ");
        String address = sc.next();
        System.out.println("mobileNo: ");
        int mobileNo = Integer.parseInt(sc.next());
        System.out.println("PIN: ");
        int PIN = Integer.parseInt(sc.next());
        System.out.println("emailID: ");
        String emailID = sc.next();
        System.out.println("DOB: ");
        String DOB = sc.next();
//        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//        LocalDate date = LocalDate.parse(DOB, sourceFormatter);
        
//        System.out.println("startDate: ");
//        String startDate = sc.next();

        LocalDateTime startDateNow = LocalDateTime.now();
//        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
       
        
                
        System.out.println("status: ");
        byte status = Byte.parseByte(sc.next());
        System.out.println("TokenID: ");
        String TokenID = sc.next();
        
       
        
        if (CustomerDAO.insertCustomer(new Customer(NRIC, name, address, mobileNo, PIN, emailID, 
                LocalDate.parse(DOB, DateTimeFormatter.ISO_DATE), startDateNow , 
                status, TokenID))) {
                    
        }
        return 1;
    }
    
    public static int listCustomersByDOB()throws Exception{
        
        System.out.println(padRight("NRIC", 20, ' ')  + padRight("name", 20, ' ')  + padRight("address", 20, ' ') +padRight("mobileNo", 20, ' ')  + padRight("PIN", 20, ' ') + 
                padRight("emailID", 20, ' ') + padRight("DOB", 20, ' ') + padRight("startDate", 20, ' ') + padRight("status", 20, ' ') + padRight("TokenID", 20, ' '));
        CustomerDAO.listCustomerOrderByDOB().stream().forEach(System.out::println);
        return 1;
    }
    
    public static int delCustomers() throws Exception {
        listCustomersByDOB();
        System.out.print("\tEnter the Customer ID to Delete :: ");
        int cid = sc.nextInt();
        System.out.print("\tAre you sure [y/n][Y/N]:: ");
        String resp = sc.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating delete for Customer ID ::" + cid);
           
            CustomerDAO.delCustomer(cid);
            
        }
        return 1;
    }
    
    public static int updCustomers() throws Exception {
        listCustomersByDOB();
        System.out.print("Enter the Customer NRIC to Update :: ");
        int cid = sc.nextInt();
        System.out.print("You can only update Email and PhoneNo [Y/N][y/n]:: ");
        String resp = sc.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println("Initiating update for Customer with NRIC:: " + cid);
            
            Customer c = CustomerDAO.getCustomer(cid);
            System.out.println("Selecting Customer ... ");
            System.out.print(c);

            System.out.println("\nCurrent emailID  \t : " + c.getEmailID());
            System.out.print("\nNew Email       \t : ");
            c.setEmailID(sc.next());
            System.out.println("\nCurrent mobileNo  \t : " + c.getMobileNo());
            System.out.print("\nNew mobileNo          \t : ");
            c.setMobileNo(Integer.parseInt(sc.next()));
            CustomerDAO.updateCustomer(c);
        }
        
        return 1;
    }
    
}
