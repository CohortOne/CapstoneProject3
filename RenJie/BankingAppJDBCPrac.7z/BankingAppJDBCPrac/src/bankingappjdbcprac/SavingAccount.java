/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;


import static util.PrintingUtil.padRight;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import util.LocaleUtil;
/**
 *
 * @author wakar
 */
public class SavingAccount {
    
    private int accNo;
    private double balance;
    private double interestRate;
    private LocalDateTime accountOpenDate;
    private LocalDateTime accountClosedDate;
    private double minBalance;
    private int accountTypeID;
    
    public SavingAccount(int accNo, double balance, double interestRate, LocalDateTime accountOpenDate, LocalDateTime accountClosedDate, double minBalance, int accountTypeID) {
        
        this.accNo = accNo;
        this.balance = balance;
        this.interestRate = interestRate;
        this.accountOpenDate = accountOpenDate;
        this.accountClosedDate = accountClosedDate;
        this.minBalance = minBalance;
        this.accountTypeID = accountTypeID;
        
    }
    
    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public LocalDateTime getAccountOpenDate() {
        return accountOpenDate;
    }

    public void setAccountOpenDate(LocalDateTime accountOpenDate) {
        this.accountOpenDate = accountOpenDate;
    }

    public LocalDateTime getAccountClosedDate() {
        return accountClosedDate;
    }

    public void setAccountClosedDate(LocalDateTime accountClosedDate) {
        this.accountClosedDate = accountClosedDate;
    }

    public double getMinBalance() {
        return minBalance;
    }

    public void setMinBalance(double minBalance) {
        this.minBalance = minBalance;
    }

    public int getAccountTypeID() {
        return accountTypeID;
    }

    public void setAccountTypeID(int accountTypeID) {
        this.accountTypeID = accountTypeID;
    }
    
    @Override
    public String toString() {
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss");
        String formattedDate1 = accountOpenDate.format(myFormatObj); 
         String formattedDate2;
        
        if(accountClosedDate == null){
            formattedDate2 = "null";
        } else{
            formattedDate2 = accountClosedDate.format(myFormatObj);
        }
        return padRight(String.valueOf(accNo), 20, ' ')  + padRight(String.valueOf(balance), 20, ' ')  + padRight(String.valueOf(interestRate), 20, ' ') +padRight(formattedDate1, 20, ' ')  + padRight(formattedDate2, 20, ' ') + 
                padRight(String.valueOf(minBalance), 20, ' ') + padRight(String.valueOf(accountTypeID), 20, ' ') ;
    }
}
