/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;

import util.LogUtil;
import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.sql.Timestamp;
import java.util.logging.Level;
import util.LocaleUtil;

/**
 *
 * @author wakar
 */
public class SavingAccountDAO {
    public static Statement init() throws Exception {
        Connection conn = initConn();
        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        LogUtil.doInfoLog("Creating Connection with DB...");
        Connection conn = null;
        try{
           
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/banking?useTimezone=true&serverTimezone=UTC&"
                            + "user=root&password=mysql");
            LogUtil.doInfoLog("Successfully connected to DB");
        }
        catch(Exception e){
            LogUtil.doExceptionLog(Level.SEVERE, "Failed to establish connection with DB", e);
        }
        return conn;
    }
    
    public static boolean insertAccount(SavingAccount s) throws Exception {
        Statement stmt = SavingAccountDAO.init();
        
        String insStmt = "INSERT INTO `banking`.`savingaccount` (`accNo`, `balance`, `interestRate`, `accountOpenDate`, `minBalance`, `accountTypeID`) "
                + "VALUES ('" + s.getAccNo() + "', '" + s.getBalance()+ "', '" + s.getInterestRate()+ "',' " + s.getAccountOpenDate()+ "', '" + s.getMinBalance()+ "', '" + s.getAccountTypeID() + "');";
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
            LogUtil.doInfoLog("account successfully added");
        }else {
            System.out.println(" Insert Fail ");
            LogUtil.doInfoLog("account failed to be added");
        }
        
        return true;
    }
    
    public static List <SavingAccount> listAccounts() throws Exception{

        Statement stmt = SavingAccountDAO.init();
        List <SavingAccount> lst = new ArrayList();
        String qStmt = "Select * from banking.savingaccount;";
        ResultSet rs = stmt.executeQuery(qStmt);
        System.out.print(LocaleUtil.msgs.getObject("phone")+ " : "); //delete
        
//        int iVal = 0;
//        if (rs.next()) {
//            iVal = rs.getInt("ID_PARENT");
//            if (rs.wasNull()) {
//                // handle NULL field value
//            }
//        }

        while (rs.next()) {
            Timestamp x = rs.getTimestamp("accountClosedDate");
            if (x == null){
                lst.add(new SavingAccount(rs.getInt("accNo"), rs.getDouble("balance"), rs.getDouble("interestRate"), rs.getTimestamp("accountOpenDate").toLocalDateTime(), null , rs.getDouble("minBalance"), rs.getInt("accountTypeID")));
            } else{
                lst.add(new SavingAccount(rs.getInt("accNo"), rs.getDouble("balance"), rs.getDouble("interestRate"), rs.getTimestamp("accountOpenDate").toLocalDateTime(), rs.getTimestamp("accountClosedDate").toLocalDateTime(), rs.getDouble("minBalance"), rs.getInt("accountTypeID")));
            }
            
            
        }
        LogUtil.doInfoLog("account list successfully retrieved");
        return lst;
    }
    
    
    public static boolean delAccount(int accNo) throws Exception{
        Statement stmt = SavingAccountDAO.init();
        String delStmt = "delete from banking.savingaccount where accNo = " + accNo + ";"; 
        int result = stmt.executeUpdate(delStmt);
        
        if(result > 0){
            System.out.println(" Delete Success ");
            LogUtil.doInfoLog("account deleted successfully");
        }else {
            System.out.println(" Delete Fail ");
            LogUtil.doInfoLog("account failed to be deleted");
        }
        return true;
    } 
    
    
    public static boolean updAccount(SavingAccount s) throws Exception{
        Statement stmt = SavingAccountDAO.init();
        String qstmt = "update banking.savingaccount set minBalance = '" + s.getMinBalance() + "' where accNo ="+ s.getAccNo() + ";";
        
        if(stmt.executeUpdate(qstmt) > 0){
           System.out.println(" Update Success ");
           LogUtil.doInfoLog("account successfully updated");
        }else {
            System.out.println(" Update Failed ");
            LogUtil.doInfoLog("account failed to be updated");
        }
        return true;
    }   
    
    public static SavingAccount getSavingAccount(int accNo) throws Exception{
        Statement stmt = CustomerDAO.init();
        SavingAccount acct = null;
        String qStmt = "Select * from Banking.savingaccount where accNo = " + accNo + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        
        while(rs.next()){
            Timestamp x = rs.getTimestamp("accountClosedDate");
            if (x == null){
                acct = new SavingAccount(rs.getInt("accNo"), rs.getDouble("balance"), rs.getDouble("interestRate"), rs.getTimestamp("accountOpenDate").toLocalDateTime(), null, rs.getDouble("minBalance"), rs.getInt("accountTypeID"));
            } else {
                acct = new SavingAccount(rs.getInt("accNo"), rs.getDouble("balance"), rs.getDouble("interestRate"), rs.getTimestamp("accountOpenDate").toLocalDateTime(), rs.getTimestamp("accountClosedDate").toLocalDateTime(), rs.getDouble("minBalance"), rs.getInt("accountTypeID"));
            }
        }
        LogUtil.doInfoLog("account successfully retrieved");
        return acct;
    }
    
}

