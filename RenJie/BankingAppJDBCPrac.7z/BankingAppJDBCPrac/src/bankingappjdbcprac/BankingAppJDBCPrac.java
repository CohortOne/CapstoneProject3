/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;


import static util.PrintingUtil.padRight;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import util.LocaleUtil;


/**
 *
 * @author wakar
 */
public class BankingAppJDBCPrac {
    public static Scanner sc = new Scanner(System.in);
    // use this line -> sc.useDelimiter("\n");
    
    
    
    
    public static void main(String[] args) throws Exception{
        // TODO code application logic here
//        LocaleUtil.initLocale();
        System.out.print(LocaleUtil.msgs.getObject("phone")+ " : ");
//         fname += " or at " + myObj.next();
        
        while (true) {
            System.out.println("General Operations Menu: ");
            
            System.out.println("1: Customer Operations");
            System.out.println("2: Saving Account Operations");
            
            System.out.println("0: Exit");
            
            System.out.println("\nOption Selected : \t");
            int input = Integer.parseInt(sc.next());
            switch (input) {
                
                case 2:
                    System.out.println("\nInitializing Account Menu... ");
                    SavingAccountMenu.displayAcctMenu();
                    break;
                case 1:
                    System.out.println("\nInitializing Customer Menu...  ");
                    CustomerMenu.displayCustMenu();
                    break;
                
                case 0:
                    System.out.println("Exiting...");
                    
                    Thread.sleep(2000);
                    System.exit(0);
                    break;
                default:
                    //printHeader();
                    System.out.println("\n\n#### Invalid Option ####\n");
                    Thread.sleep(2000);
                    break;
            }

            
            System.out.println("Awaiting next operation...");
            
        }
    }
    
}
