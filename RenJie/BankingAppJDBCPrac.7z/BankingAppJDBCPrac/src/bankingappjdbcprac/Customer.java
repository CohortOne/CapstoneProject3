/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;
import static util.PrintingUtil.padRight;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 *
 * @author wakar
 */
public class Customer {

    private int NRIC;
    private String name;
    private String address;
    private int mobileNo;
    private int PIN;
    private String emailID;
    private LocalDate DOB;
    private LocalDateTime startDate;
    private byte status;
    private String TokenID; 
    
    
    public int getNRIC() {
        return NRIC;
    }

    public void setNRIC(int NRIC) {
        this.NRIC = NRIC;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(int mobileNo) {
        this.mobileNo = mobileNo;
    }

    public int getPIN() {
        return PIN;
    }

    public void setPIN(int PIN) {
        this.PIN = PIN;
    }

    public String getEmailID() {
        return emailID;
    }

    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }

    public LocalDate getDOB() {
        return DOB;
    }

    public void setDOB(LocalDate DOB) {
        this.DOB = DOB;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public String getTokenID() {
        return TokenID;
    }

    public void setTokenID(String TokenID) {
        this.TokenID = TokenID;
    }

    public Customer(int NRIC, String name, String address, int mobileNo, int PIN, String emailID, LocalDate DOB, LocalDateTime startDate, byte status, String TokenID) {
        this.NRIC = NRIC;
        this.name = name;
        this.address = address;
        this.mobileNo = mobileNo;
        this.PIN = PIN;
        this.emailID = emailID;
        this.DOB = DOB;
        this.startDate = startDate;
        this.status = status;
        this.TokenID = TokenID;
    }
    
    
    
    @Override
    public String toString() {
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss");  
        String formattedDate = startDate.format(myFormatObj); 
        
        return padRight(String.valueOf(NRIC), 20, ' ')  + padRight(name, 20, ' ')  + padRight(address, 20, ' ') +padRight(String.valueOf(mobileNo), 20, ' ')  + padRight(String.valueOf(PIN), 20, ' ') + 
                padRight(emailID, 20, ' ') + padRight(String.valueOf(DOB), 20, ' ') + padRight(formattedDate, 20, ' ') + padRight(String.valueOf(status), 20, ' ') + padRight(TokenID, 20, ' ');
    }
    
    
    
    
    
}
 