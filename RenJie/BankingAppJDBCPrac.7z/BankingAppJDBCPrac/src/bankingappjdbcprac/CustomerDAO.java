/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingappjdbcprac;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author wakar
 */
public class CustomerDAO {
    public static Statement init() throws Exception {
        Connection conn = initConn();
        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Connection conn;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/banking?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");

        return conn;
    }
    
//    public static int getNextID(){
//        int nxtID = 0;
//        try{
//            Statement stmt = CustomerDAO.init();
//            String nxID = "select max(custID) from banking.customer;";
//            ResultSet rs = stmt.executeQuery(nxID);
//            rs.next();
//            nxtID = rs.getInt(1) + 1 ;        
//        }catch(Exception e){
//            System.out.println(" Exception from CustomerDAO :: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return nxtID;
//    }
    
    public static boolean insertCustomer(Customer c) throws Exception {
        Statement stmt = CustomerDAO.init();
        String insStmt = "INSERT INTO `banking`.`customer` (`NRIC`, `name`, `address`, `mobileNo`, `PIN`, `emailID`, `DOB`, `startDate`, `status`, `TokenID`) "
                + "VALUES ('" + c.getNRIC() + "', '" + c.getName()+ "', '" + c.getAddress()+ "', '" + c.getMobileNo()+ "', '" + c.getPIN()+ "', '" + c.getEmailID()+ "', '" + c.getDOB()+ "', '" + c.getStartDate()+ "', '" + c.getStatus()+ "', '" + c.getTokenID() + "');";
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }
    
    public static List <Customer> listCustomerOrderByDOB() throws Exception{
        Connection conn = CustomerDAO.initConn();
        List <Customer> custList = new ArrayList<>();
        String qStmt = "{CALL GetCustomers()}";
        
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        
        
        while(rs.next()){
            Customer c = new Customer(rs.getInt("NRIC"), rs.getString("name"), rs.getString("address"), rs.getInt("mobileNo"), rs.getInt("PIN"), rs.getString("emailID"), rs.getDate("DOB").toLocalDate(), rs.getTimestamp("startDate").toLocalDateTime(), rs.getByte("status"), rs.getString("TokenID"));
            custList.add(c);
        }
        return custList;
        
        
    }
    
    public static boolean delCustomer(int cid) throws Exception{
        Statement stmt = CustomerDAO.init();     
        String delStmt = "delete from banking.customer where NRIC = " + cid + ";";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Delete Success ");
        }else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }
    
    public static Customer getCustomer(int NRIC) throws Exception{
        Statement stmt = CustomerDAO.init();
        Customer cust = null;
        String qStmt = "Select * from Banking.Customer where NRIC = " + NRIC + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            cust = new Customer(rs.getInt("NRIC"), rs.getString("name"), rs.getString("address"), rs.getInt("mobileNo"), rs.getInt("PIN"), rs.getString("emailID"), rs.getDate("DOB").toLocalDate(), rs.getTimestamp("startDate").toLocalDateTime(), rs.getByte("status"), rs.getString("TokenID"));
        }
        return cust;
    }
    
    public static boolean updateCustomer(Customer c) throws Exception{
        Statement stmt = CustomerDAO.init();
        String updStmt = "Update Banking.Customer set emailID = '" + c.getEmailID()+ "', mobileNo = '" + c.getMobileNo()+ "' where NRIC = " + c.getNRIC()+ ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
}
