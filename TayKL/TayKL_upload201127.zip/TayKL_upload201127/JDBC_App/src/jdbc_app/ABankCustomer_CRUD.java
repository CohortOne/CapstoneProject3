
package jdbc_app;

//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.Optional;
import java.util.Scanner;
import static jdbc_app.ABankCustomer_CRUD.printStrBldr;

public class ABankCustomer_CRUD {
    
    public static Scanner readInput = new Scanner(System.in);
//    public static int iteration = 1;

//    public static void toContinue() {
//        readInput.next();
//    }

//    public static String printPretty() {
//        String s = "\n  |";
//        for (int i = 0; i <= iteration; i++) {
//            s += "---";
//        }
//        return s + " >> ";
//    }
    
    public static StringBuilder strBldr = new StringBuilder("");
    public static void initStrBldr(String s) {
        for (int i = 0; i <= 130; i++) { strBldr.append(s); }
    }
    
    public static void deleteStrBldr() {
        if (strBldr.length() > 0) {
                strBldr.delete(0, strBldr.length());
        }
    }
    
    public static void printStrBldr() {
        initStrBldr(" ");
        strBldr.insert(1,"UINum");
        strBldr.insert(13,"LastName");
        strBldr.insert(30,"GivenName");
        strBldr.insert(47,"EmailAddr");
        strBldr.insert(69,"custPhone");
        strBldr.insert(86,"Status");
        strBldr.insert(94,"LastUpdate");
        strBldr.insert(111,"CreateDateTime");
        System.out.println(strBldr.toString().trim());
        deleteStrBldr();
    }
    
    public static int listCustomers() throws Exception {
        clearScreen(); print1Line("=");
        printStrBldr();
        print1Line("=");
        ABankCustomerDAO.listCustomer().stream().forEach(System.out::println);
        print1Line("_");
        return 1;
    }    
    
    public static int listCustomersByDOB() throws Exception {
        clearScreen(); print1Line("=");
        printStrBldr();
        print1Line("=");
        ABankCustomerDAO.listCustomerOrderByDOB().stream().forEach(System.out::println);
        print1Line("_");
        return 1;
    }
    
    public static int findCustomerByPhoneNo() throws Exception {
        //clearScreen(); 
        print1Line("=");
        System.out.print(" \tEnter the PhoneNo to Find :: ");
        String phoneNo = readInput.next();
        
        clearScreen(); print1Line("=");
        printStrBldr();
        print1Line("=");
        ABankCustomerDAO.getCustomer2(phoneNo).stream().forEach(System.out::println);
        print1Line("_");
        return 1;
    }

    public static int delCustomers() throws Exception {
        listCustomers();
        System.out.print(" \tEnter the Customer ID to Delete :: ");
        String cid = readInput.next().trim();
        System.out.print(" \tAre you sure [y/n][Y/N]:: ");
        String resp = readInput.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating delete for Customer ID ::" + cid);
            clearScreen(); print1Line("=");
            ABankCustomerDAO.delCustomer(cid);
            print1Line("_");
        }
        return 1;
    }

    public static int updCustomers() throws Exception {
        listCustomers();
        System.out.print(" \tEnter the Customer ID to Update :: ");
        String cid = readInput.next().trim();
        System.out.print(" \t You can only update Email and PhoneNo [Y/N][y/n]:: ");
        String resp = readInput.next().trim();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating update for Customer ID :: " + cid);
            clearScreen(); 
            print1Line("=");
            ABankCustomer c = ABankCustomerDAO.getCustomer(cid);
            //--- Check: customer exist? process change : skip
            if (c != null) {
                System.out.println(" Select Customer ::: ");
                System.out.print(c);
                print1Line("_");

                System.out.println(" \n\t\t   Current Email   \t : " + c.getCustEmailAddr());
                System.out.print(" \n\t\t   New Email       \t : ");
                c.setCustEmailAddr(readInput.next().trim());
                System.out.println(" \n\t\t    Current Phone    \t : " + c.getCustPhone());
                System.out.print(" \n\t\t    New  Phone          \t : ");
                c.setCustPhone(readInput.next().trim());
                ABankCustomerDAO.updateCustomer(c);
                print1Line("_");
            }
            else {
                System.out.println("\t\t Customer UINum " + cid + " not found.");
            }
        }
        return 1;
    }

    public static int insCustomer() throws Exception {
        //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        //int nxtID = ABankCustomerDAO.getNextID();
        print1Line("_");
        System.out.println(" \tEnter the following details  :: ");
        print1Line("-");
        String nxtID = "";
        
        //System.out.println(" \n\t\t        Customer ID    \t : " + nxtID);
        System.out.print(" \n\t\t        Given Name     \t : ");
        String givenName = readInput.next().trim();
        
        System.out.print(" \n\t\t        Last Name     \t : ");
        String lastName = readInput.next().trim();    //name = readInput.nextLine();
        
        //System.out.print(" \n\t\t        Date Of Birth  \t : ");
        //String dob = readInput.next();
        //DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        //LocalDate date = LocalDate.parse(dob, sourceFormatter);
        
        System.out.print(" \n\t\t        Email          \t : ");
        String eAddr = readInput.next().trim();
        
        System.out.print(" \n\t\t        Phone          \t : ");
        String cPhone = readInput.next().trim();

        nxtID = genAcctNum(lastName.substring(0,1));
        
        clearScreen(); print1Line("=");
        if (ABankCustomerDAO.insertCustomer(new ABankCustomer(nxtID, 
                lastName, givenName, eAddr, cPhone,
                (Boolean) true, "", ""  ) ) ) {
            print1Line("=");
        }
        return 1;
    }

    public static int DisplayOptions() throws Exception {
        clearScreen(); print1Line("_");
        System.out.println("\n\t ::: Customer CRUD Operations ::: ");
        print1Line("_");
        
        System.out.println(" \tFollowing are the menu options :: ");
        System.out.println(" \n\t\t1 >> Insert Customer ");
        System.out.println(" \n\t\t2 >> Update Customer ");
        System.out.println(" \n\t\t3 >> Delete Customer ");
        System.out.println(" \n\t\t4 >> List Customer "); 
        System.out.println(" \n\t\t5 >> List Customers Order By Status ");
        System.out.println(" \n\t\t6 >> Find Customers By PhoneNo ");
        System.out.println(" \n\t\t0 >> Exit ");       
        print1Line("-");

        // Create a Scanner object
        System.out.print(" Enter the menu number to carry out the operation  :   ");
        int optVal;
        try {
            optVal = readInput.nextInt();
        } catch (Exception e) {
            optVal = -1;
        }
        return optVal;
    }

    public static void print1Line(String s) {
        initStrBldr(s);
        System.out.println(strBldr.toString().trim());
        deleteStrBldr();
    }
    
//    public static void printFooter(String s) {
//        initStrBldr(s);
//        System.out.println(strBldr.toString().trim());
//        deleteStrBldr();
//    }
    
    public static void clearScreen() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println();
    }
    
    //--- Start main ---//
    public static void main(String[] args) throws Exception {
        boolean xTerminate = false; 
        while (!xTerminate) {
            int optionVal = DisplayOptions();

            print1Line("=");
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {
                case 1:
                    System.out.println("Insert Customer  ");
                    print1Line(".");
                    insCustomer();
                    break;
                case 2:
                    System.out.println("Update Customer ::: ");
                    updCustomers();
                    break;
                case 3:
                    System.out.println("Delete Customer ::: ");
                    delCustomers();
                    break;
                case 4:
                    System.out.println("List all Customers  ::: ");
                    listCustomers();
                    break;
                case 5:
                    System.out.println("List Customers by Status ::: ");
                    listCustomersByDOB();
                    break;
                case 6:
                    System.out.println("Find Customer By Phone No ::: ");
                    findCustomerByPhoneNo();
                    break;
                case 0:
                    System.out.println("Exit");
                    print1Line("-");
                    //Thread.sleep(1500);
                    //System.exit(0);
                    xTerminate = true;
                    break;
                default:
                    //print1Line();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    print1Line("-");
                    //Thread.sleep(1500);
                    break;
            }
            
            Thread.sleep(1500);
            //print1Line("_");   
            //System.out.println(" Press any key to continue ...");
            //readInput.nextLine();
            //toContinue();
        }
        
    }//- ends public static void main

    
    static String genAcctNum(String s) {
        //String s is the 1st char [a-zA-Z] in lastName
        //convert s to its representative ascii value, which is also a positive integer;
        byte[] n = s.getBytes();
        int m = (int) (n[0] - 1) % 10;
        //auto-generate a random number between 0.0 and 1.0
        double r = Math.random();
        //calc an integer using values of n[0] and r above (between 0 and n-1), 
        //add 100 to get 3-digit number
        //then prefix the modulus of 10 on n[0]-1
        int i = (int) (r * n[0]) + 100;
        return (s.toUpperCase() + String.valueOf(m) + String.valueOf(i)); 
    }    
        
    public static boolean vetLettersInStr(String s) { 
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= 'a' && ch <= 'z')) {
                    System.out.println("This does not looked like a good Last/Given Name.");
                    return false;
                }
            }
            return true;
        } 
        System.out.println("This does not looked like a good Last/Given Name.");
        return false;
    }
    
    public static boolean vetDigitsInStr(String s) {   
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= '0' && ch <= '9')) {
                    System.out.println("This does not looked like an acceptable initial deposit amount.");
                    return false;
                }
            }
            if(Integer.parseInt(s) > 9) { 
                return true;
            }
        } 
        System.out.println("This does not looked like an acceptable initial deposit amount.");
        return false;
    }
    
}//-ends public class ABankCustomer_CRUD
