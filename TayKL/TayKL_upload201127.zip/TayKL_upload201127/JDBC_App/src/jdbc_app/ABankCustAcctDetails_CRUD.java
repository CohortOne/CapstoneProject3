
package jdbc_app;

//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.Optional;
import java.util.Scanner;
import static jdbc_app.ABankCustAcctDetails_CRUD.printStrBldr;

public class ABankCustAcctDetails_CRUD {
    
    public static Scanner readInput = new Scanner(System.in);
//    public static int iteration = 1;

//    public static void toContinue() {
//        readInput.next();
//    }

//    public static String printPretty() {
//        String s = "\n  |";
//        for (int i = 0; i <= iteration; i++) {
//            s += "---";
//        }
//        return s + " >> ";
//    }
    
    public static StringBuilder strBldr = new StringBuilder("");
    public static void initStrBldr(String s) {
        for (int i = 0; i <= 130; i++) { strBldr.append(s); }
    }
    
    public static void deleteStrBldr() {
        if (strBldr.length() > 0) {
                strBldr.delete(0, strBldr.length());
        }
    }
    
    public static void printStrBldr() {
        initStrBldr(" ");
        strBldr.insert(1,"AcctNum");
        strBldr.insert(11,"UINum");
        strBldr.insert(21,"Balance");
        strBldr.insert(34,"MinBal");
        strBldr.insert(42,"Limit");
        strBldr.insert(49,"Status");
        strBldr.insert(57,"RenewalPref");
        strBldr.insert(70,"LastUpdate");
        strBldr.insert(87,"CreateDate");
        System.out.println(strBldr.toString().trim());
        deleteStrBldr();
    }
    
    public static int listCustomers() throws Exception {
        clearScreen(); print1Line("=");
        printStrBldr();
        print1Line("=");
        ABankCustAcctDetailsDAO.listCustomer().stream().forEach(System.out::println);
        print1Line("_");
        return 1;
    }    
    
    public static int listCustomersByDOB() throws Exception {
        clearScreen(); print1Line("=");
        printStrBldr();
        print1Line("=");
        ABankCustAcctDetailsDAO.listCustomerOrderByDOB().stream().forEach(System.out::println);
        print1Line("_");
        return 1;
    }
    
    public static int findCustomerByPhoneNo() throws Exception {
        clearScreen(); print1Line("=");
        System.out.print(" \tEnter the Account No. to Find :: ");
        String acctNum = readInput.next();
        
        clearScreen(); print1Line("=");
        printStrBldr();
        print1Line("=");        
        ABankCustAcctDetailsDAO.getCustomer2(acctNum).stream().forEach(System.out::println);
        print1Line("_");
        return 1;
    }

    public static int delCustomers() throws Exception {
        listCustomers();
        System.out.print(" \tEnter the Account No. to Delete :: ");
        String acctNum = readInput.next().trim();
        System.out.print(" \tAre you sure [y/n][Y/N]:: ");
        String resp = readInput.next();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating delete for Customer ID ::" + acctNum);
            clearScreen(); print1Line("=");
            ABankCustAcctDetailsDAO.delCustomer(acctNum);
            print1Line("_");
        }
        return 1;
    }

    public static int updCustomers() throws Exception {
        listCustomers();
        System.out.print(" \tEnter the Account No. to Update :: ");
        String acctNum = readInput.next().trim();
        //Reminder: add coding to deny further action for FixedDeposit (acctType = "2")
        System.out.print(" \t You can only update MinimumBal/SpendLimit and  "
                + "TransactionNotificationLimit [Y/N][y/n]:: ");
        String resp = readInput.next().trim();
        if (resp.equalsIgnoreCase("y")) {
            System.out.println(" Initiating update for Account No. :: " + acctNum);
            clearScreen(); print1Line("=");
            ABankCustAcctDetails d = ABankCustAcctDetailsDAO.getCustomer(acctNum);
            //--- Check: customer exist? process change : skip
            if (d != null) {
                System.out.println(" Select Account Number ::: ");
                System.out.print(d);
                print1Line("_");

                System.out.println(" \n\t\t CurrentMinimumBalance \t : " + 
                        d.getCustAcctMinBal());
                System.out.print(" \n\t\t New Minimum Balance \t : ");
                double minBal = readInput.nextDouble();
                d.setCustAcctMinBal(minBal);
                
                System.out.println(" \n\t\t Current TransactionNotificationLimit \t : " + 
                        d.getCustAcctTxnLimit());
                System.out.print(" \n\t\t New  Transaction Notification Limit \t : ");
                d.setCustAcctTxnLimit(readInput.nextDouble());
                
                ABankCustAcctDetailsDAO.updateCustomer(d);
                print1Line("_");
            }
            else {
                System.out.println("\t\t Account Number " + acctNum + " not found.");
            }
        }
        return 1;
    }

    public static int insCustomer() throws Exception {
        //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        //int nxtID = ABankCustAcctDetailsDAO.getNextID();
        print1Line("_");
        System.out.println(" \tEnter the following details  :: ");
        print1Line("-");
        String nxtID = "";
        
        System.out.print(" \n\t\t Customer UINumber  \t : ");
        String UINum = readInput.next().trim();
        ABankCustomer c = ABankCustomerDAO.findCustomerByUINum(UINum);
        if (c != null) {
            System.out.print(" \n\t\t Account Type [1]Savings, [2]Fixed Deposit, [3]Credit Card \t : ");
            String acctType = readInput.next().trim();
            
            double acctBal=0.0, acctTxnLimit=0.0, acctMinBal = 0.0;
            String acctRenewalPref = "0";
            switch (acctType) {
            case "1":
                System.out.print(" \n\t\t Initial Deposit \t : ");
                acctBal = readInput.nextDouble();
                System.out.print(" \n\t\t Transaction Notification Limit \t : ");
                acctTxnLimit = readInput.nextDouble();    //name = readInput.nextLine();
                acctMinBal = 500.0;
                break;
            case "2":
                System.out.print(" \n\t\t Fixed Deposit Amount \t : ");
                acctBal = readInput.nextDouble();
                System.out.print(" \n\t\t Renewal Preference at expiry \t : ");
                acctRenewalPref = readInput.next().trim();    //name = readInput.nextLine();
                acctMinBal = acctBal;
                break;
            case "3":
                System.out.print(" \n\t\t Set Spend Limit \t : ");
                acctBal = readInput.nextDouble();
                System.out.print(" \n\t\t Transaction Notification Limit \t : ");
                acctTxnLimit = readInput.nextDouble();    //name = readInput.nextLine();
                acctMinBal = acctBal;
                break; 
            default:
                System.out.println("Invalid Account Type ...");
                break;
            }
            //System.out.print(" \n\t\t        Date Of Birth  \t : ");
            //String dob = readInput.next();
            //DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            //LocalDate date = LocalDate.parse(dob, sourceFormatter);

            UINum = c.getCustUINum().trim();
            String lastName = c.getCustLastName().trim();
            nxtID = genAcctNum(lastName.substring(0,1), acctType);
            
            //double acctTxnLimit = 1000;
            String acctStatus = "1";
            //acctRenewalPref = "0";

            clearScreen(); print1Line("=");
            if (ABankCustAcctDetailsDAO.insertCustomer(new ABankCustAcctDetails(nxtID, 
                    UINum, acctBal, acctMinBal, acctTxnLimit,
                    acctStatus, acctRenewalPref, "", ""  ) ) ) {
                print1Line("=");
            }
        }
        else {
            System.out.println("\t\t Customer UINum " + UINum + " not found.");
        }
        return 1;
    }

    public static int DisplayOptions() throws Exception {
        clearScreen(); print1Line("_");
        System.out.println("\n\t ::: Account CRUD Operations ::: ");
        print1Line("_");
        
        System.out.println(" \tFollowing are the menu options :: ");
        System.out.println(" \n\t\t1 >> Insert Account ");
        System.out.println(" \n\t\t2 >> Update Account ");
        System.out.println(" \n\t\t3 >> Delete Account ");
        System.out.println(" \n\t\t4 >> List all Accounts "); 
        System.out.println(" \n\t\t5 >> List Accounts Order By Customer UIN ");
        System.out.println(" \n\t\t6 >> Find Account By Account No. ");
        System.out.println(" \n\t\t0 >> Exit ");       
        print1Line("-");

        // Create a Scanner object
        System.out.print(" Enter the menu number to carry out the operation  :   ");
        int optVal;
        try {
            optVal = readInput.nextInt();
        } catch (Exception e) {
            optVal = -1;
        }
        return optVal;
    }

    public static void print1Line(String s) {
        initStrBldr(s);
        System.out.println(strBldr.toString().trim());
        deleteStrBldr();
    }
    
//    public static void printFooter(String s) {
//        initStrBldr(s);
//        System.out.println(strBldr.toString().trim());
//        deleteStrBldr();
//    }
    
    public static void clearScreen() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println();
    }
    
    //--- Start main ---//
    public static void main(String[] args) throws Exception {
        boolean xTerminate = false; 
        while (!xTerminate) {
            int optionVal = DisplayOptions();

            print1Line("=");
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {
                case 1:
                    System.out.println("Insert New Account  ");
                    print1Line(".");
                    insCustomer();
                    break;
                case 2:
                    System.out.println("Update Account ::: ");
                    updCustomers();
                    break;
                case 3:
                    System.out.println("Delete Account ::: ");
                    delCustomers();
                    break;
                case 4:
                    System.out.println("List all Accounts  ::: ");
                    listCustomers();
                    break;
                case 5:
                    System.out.println("List Accounts by Customer UIN ::: ");
                    listCustomersByDOB();
                    break;
                case 6:
                    System.out.println("Find Account By Account Number ::: ");
                    findCustomerByPhoneNo();
                    break;
                case 0:
                    System.out.println("Exit");
                    print1Line("-");
                    //Thread.sleep(1500);
                    //System.exit(0);
                    xTerminate = true;
                    break;
                default:
                    //print1Line();
                    System.out.println(" \n\n \t\t #### Invalid Option ####");
                    print1Line("-");
                    //Thread.sleep(1500);
                    break;
            }
            
            Thread.sleep(1500);
            //print1Line("_");   
            //System.out.println(" Press any key to continue ...");
            //toContinue();
        }
        
    }//- ends public static void main

    
    static String genAcctNum(String s, String acctType) {
        //String s is the 1st char [a-zA-Z] in lastName
        //convert s to its representative ascii value, which is also a positive integer;
        byte[] n = s.getBytes();
        int m = (int) (2.618 * (n[0] - 3)) % 10;
        //auto-generate a random number between 0.0 and 1.0
        double r = Math.random();
        //calc an integer using values of n[0] and r above (between 0 and n-1), 
        //add 100 to get 3-digit number
        //then prefix the modulus of 10 on n[0]-3
        int i = (int) (r * n[0]) + 100;
        return (acctType + s.toUpperCase() + String.valueOf(m) + String.valueOf(i)); 
    }    
        
    public static boolean vetLettersInStr(String s) { 
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= 'a' && ch <= 'z')) {
                    System.out.println("This does not looked like a good Last/Given Name.");
                    return false;
                }
            }
            return true;
        } 
        System.out.println("This does not looked like a good Last/Given Name.");
        return false;
    }
    
    public static boolean vetDigitsInStr(String s) {   
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= '0' && ch <= '9')) {
                    System.out.println("This does not looked like an acceptable initial deposit amount.");
                    return false;
                }
            }
            if(Integer.parseInt(s) > 9) { 
                return true;
            }
        } 
        System.out.println("This does not looked like an acceptable initial deposit amount.");
        return false;
    }
    
}//-ends public class ABankCustomer_CRUD
