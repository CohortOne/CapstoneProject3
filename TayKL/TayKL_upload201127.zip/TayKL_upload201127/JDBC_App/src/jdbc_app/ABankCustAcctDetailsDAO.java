
package jdbc_app;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
//import java.sql.Timestamp;
//import java.time.LocalDateTime;
//import java.time.LocalTime;

public class ABankCustAcctDetailsDAO {

    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/world?useTimezone=true&serverTimezone=UTC&"
                + "user=root&password=mysql");
        /*
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");
        */
        return conn;
    }
    
    /*
    public static int getNextID(){
        int nxtID = 0;
        try{
            Statement stmt = ABankCustAcctDetailsDAO.init();
            String nxID = "select max(custAcctNum) from world.abankcustacctdetails;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;        
        }catch(Exception e){
            System.out.println(" Exception from ABankCustAcctDetailsDAO :: " + e.getMessage());
            //e.printStackTrace();
        }
        return nxtID;
    }
    */
    public static boolean insertCustomer(ABankCustAcctDetails d) throws Exception{
        Statement stmt = ABankCustAcctDetailsDAO.init();

        String insStmt = "insert into world.abankcustacctdetails (custAcctNum, custAcctUINum, " + 
                "custAcctBal, custAcctMinBal, custAcctTxnLimit, custAcctStatus, custAcctRenewalPref, " +
                "LastUpdate, CreateDate) " + " values(" + 
                "'" + d.getCustAcctNum() + "'" +
                "," + "'" + d.getCustAcctUINum() + "'" + 
                "," + d.getCustAcctBal() + 
                "," + d.getCustAcctMinBal() + 
                "," + d.getCustAcctTxnLimit() + 
                "," + "'" + d.getCustAcctStatus() + "'" +
                "," + "'" + d.getCustAcctRenewalPref() + "'" +
                "," + "'" + d.getLastUpdate() + "'" +
                "," + "'" + d.getCreateDate() + "'" +
                ");";
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }    
    
    public static boolean delCustomer(String acctNum) throws Exception{
        Statement stmt = ABankCustAcctDetailsDAO.init();     
        String delStmt = "delete from world.abankcustacctdetails where custAcctNum = " + 
                "'" + acctNum + "'" + ";";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Delete Success ");
        }else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }
    
    public static List <ABankCustAcctDetails> listCustomer() throws Exception{
        Statement stmt = ABankCustAcctDetailsDAO.init();
        List <ABankCustAcctDetails> acctList = new ArrayList<>();
        String qStmt = "Select * from world.abankcustacctdetails;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            acctList.add(new ABankCustAcctDetails(rs.getString("custAcctNum"),
                    rs.getString("custAcctUINum"), rs.getDouble("custAcctBal"),
                    rs.getDouble("custAcctMinBal"), rs.getDouble("custAcctTxnLimit"), 
                    rs.getString("custAcctStatus"), rs.getString("custAcctRenewalPref"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate") 
            )            
            );
        }
        return acctList;
    }  
    
    public static List <ABankCustAcctDetails> listCustomerOrderByDOB() throws Exception{
        Connection conn = ABankCustAcctDetailsDAO.initConn();
        List <ABankCustAcctDetails> acctList = new ArrayList<>();
        String qStmt = "{CALL GetABankCustAcctDetails()}";
        
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            ABankCustAcctDetails d = new ABankCustAcctDetails(rs.getString("custAcctNum"),                    
                    rs.getString("custAcctUINum"), rs.getDouble("custAcctBal"),
                    rs.getDouble("custAcctMinBal"), rs.getDouble("custAcctTxnLimit"), 
                    rs.getString("custAcctStatus"), rs.getString("custAcctRenewalPref"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate")
            );
            acctList.add(d);
        }
        return acctList;
    }
    
    public static ABankCustAcctDetails getCustomer(String acctNum) throws Exception{
        Statement stmt = ABankCustAcctDetailsDAO.init();
        ABankCustAcctDetails acct = null;
        String qStmt = "Select * from world.abankcustacctdetails where " + 
                "custAcctNum = " + "'" + acctNum + "'" + ";";
//                "custAcctUINum = " + "'" + custAcctUINum + "'" + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            acct = new ABankCustAcctDetails(rs.getString("custAcctNum"),
                    rs.getString("custAcctUINum"), rs.getDouble("custAcctBal"),
                    rs.getDouble("custAcctMinBal"), rs.getDouble("custAcctTxnLimit"), 
                    rs.getString("custAcctStatus"), rs.getString("custAcctRenewalPref"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate")
            );
        }
        return acct;
    }
    
    public static List <ABankCustAcctDetails> getCustomer2(String acctNum) throws Exception{
        Connection conn = ABankCustAcctDetailsDAO.initConn();
        List <ABankCustAcctDetails> acctList = new ArrayList<>();
        String qStmt = "Select * from world.abankcustacctdetails where custAcctNum = ? ";
        
        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, acctNum);
        ResultSet rs = pStmt.executeQuery();
        while(rs.next()){
            acctList.add(new ABankCustAcctDetails(rs.getString("custAcctNum"),
                    rs.getString("custAcctUINum"), rs.getDouble("custAcctBal"),
                    rs.getDouble("custAcctMinBal"), rs.getDouble("custAcctTxnLimit"), 
                    rs.getString("custAcctStatus"), rs.getString("custAcctRenewalPref"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate")
            )
            );
        }
        return acctList;
    }
    
    public static boolean updateCustomer2(ABankCustAcctDetails d) throws Exception{
        Statement stmt = ABankCustAcctDetailsDAO.init();
        String updStmt = "Update world.abankcustacctdetails set" +
                " custAcctBal = " + d.getCustAcctBal() + 
                " where custAcctNum = " + "'" + d.getCustAcctNum() + "'" + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Customer Account Balance Update Success ");
        }else {
            System.out.println(" Customer Account Balance Update Failed ");
        }
        return true;
    }
    
    public static boolean updateCustomer(ABankCustAcctDetails d) throws Exception{
        Statement stmt = ABankCustAcctDetailsDAO.init();
        String updStmt = "Update world.abankcustacctdetails set" +
                " custAcctMinBal = " + d.getCustAcctMinBal() + "," +
                " custAcctTxnLimit = " + d.getCustAcctTxnLimit() + 
                " where custAcctNum = " + "'" + d.getCustAcctNum() + "'" + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
}//- ends public class ABankCustAcctDetailsDAO
