
package jdbc_app;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
//import java.sql.Timestamp;
//import java.time.LocalDateTime;
//import java.time.LocalTime;

public class ABankCustAcctTransDAO {

    public static Statement init() throws Exception {
        Connection conn = initConn();

        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/world?useTimezone=true&serverTimezone=UTC&"
                + "user=root&password=mysql");
        /*
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");
        */
        return conn;
    }
    
    /*
    public static int getNextID(){
        int nxtID = 0;
        try{
            Statement stmt = ABankCustAcctDetailsDAO.init();
            String nxID = "select max(custAcctNum) from world.abankcustacctdetails;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;        
        }catch(Exception e){
            System.out.println(" Exception from ABankCustAcctDetailsDAO :: " + e.getMessage());
            //e.printStackTrace();
        }
        return nxtID;
    }
    */
    
    static String genDateTime() {
        ZonedDateTime today = ZonedDateTime.now();
        System.out.println("\t"+"Today is " + today.format(DateTimeFormatter.ofPattern("uuuuMMddHHMMSSz")));
        String transDateTime = today.format(DateTimeFormatter.ofPattern("uuuuMMddHHMMSSz"));
        return transDateTime;
    }
    
    
    public static boolean insertCustomer(ABankCustAcctTrans d) throws Exception{
        Statement stmt = ABankCustAcctTransDAO.init();

        String insStmt = "insert into world.abankcustaccttrans (custAcctTransNum, " + 
                "custAcctTransAmt, custAcctTransType, custAcctTransDesc, " +
                "CreateDate) " + " values(" + 
                "'" + d.getCustAcctTransNum() + "'" + 
                "," + d.getCustAcctTransAmt() +  
                "," + "'" + d.getCustAcctTransType() + "'" +
                "," + "'" + d.getCustAcctTransDesc() + "'" +
                "," + "'" + d.getCreateDate() + "'" +
                ");";
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }    
    
    public static boolean delCustomer(String acctNum) throws Exception{
        Statement stmt = ABankCustAcctTransDAO.init();     
        String delStmt = "delete from world.abankcustaccttrans where custAcctTransNum = " + 
                "'" + acctNum + "'" + ";";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Delete Success ");
        }else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }
    
    public static List <ABankCustAcctTrans> listCustomer() throws Exception{
        Statement stmt = ABankCustAcctTransDAO.init();
        List <ABankCustAcctTrans> acctList = new ArrayList<>();
        String qStmt = "Select * from world.abankcustaccttrans;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            acctList.add(new ABankCustAcctTrans(rs.getString("custAcctTransNum"),
                    rs.getDouble("custAcctTransAmt"),  
                    rs.getString("custAcctTransType"), 
                    rs.getString("custAcctTransDesc"), 
                    rs.getString("CreateDate") 
            )            
            );
        }
        return acctList;
    }  
    
    public static List <ABankCustAcctTrans> listCustomerOrderByDOB() throws Exception{
        Connection conn = ABankCustAcctTransDAO.initConn();
        List <ABankCustAcctTrans> acctList = new ArrayList<>();
        String qStmt = "{CALL GetABankCustAcctTrans()}";
        
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            ABankCustAcctTrans d = new ABankCustAcctTrans(rs.getString("custAcctTransNum"),                    
                    rs.getDouble("custAcctTransAmt"),  
                    rs.getString("custAcctTransType"), 
                    rs.getString("custAcctTransDesc"), 
                    rs.getString("CreateDate") 
            );
            acctList.add(d);
        }
        return acctList;
    }
    
    public static ABankCustAcctTrans getCustomer(String custAcctUINum) throws Exception{
        Statement stmt = ABankCustAcctTransDAO.init();
        ABankCustAcctTrans acct = null;
        String qStmt = "Select * from world.abankcustaccttrans where " + 
                "custAcctTransNum = " + "'" + custAcctUINum + "'" + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            acct = new ABankCustAcctTrans(rs.getString("custAcctTransNum"),
                    rs.getDouble("custAcctTransAmt"),  
                    rs.getString("custAcctTransType"), 
                    rs.getString("custAcctTransDesc"), 
                    rs.getString("CreateDate")
            );
        }
        return acct;
    }
    
    public static List <ABankCustAcctTrans> getCustomer2(String acctNum) throws Exception{
        Connection conn = ABankCustAcctTransDAO.initConn();
        List <ABankCustAcctTrans> acctList = new ArrayList<>();
        String qStmt = "Select * from world.abankcustaccttrans where custAcctTransNum = ? ";
        
        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, acctNum);
        ResultSet rs = pStmt.executeQuery();
        while(rs.next()){
            acctList.add(new ABankCustAcctTrans(rs.getString("custAcctTransNum"),
                    rs.getDouble("custAcctTransAmt"),  
                    rs.getString("custAcctTransType"), 
                    rs.getString("custAcctTransDesc"), 
                    rs.getString("CreateDate")
            )
            );
        }
        return acctList;
    }
        
    public static boolean updateCustomer(ABankCustAcctTrans d) throws Exception{
        Statement stmt = ABankCustAcctTransDAO.init();
        String updStmt = "Update world.abankcustaccttrans set" +
                " custAcctTransAmt = " + d.getCustAcctTransAmt() + "," +
                " custAcctTransDesc = " + d.getCustAcctTransDesc() + 
                " where custAcctTransNum = " + "'" + d.getCustAcctTransNum() + "'" + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
}//- ends public class ABankCustAcctTransDAO
