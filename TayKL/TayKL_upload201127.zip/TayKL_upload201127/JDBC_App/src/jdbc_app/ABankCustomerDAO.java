
package jdbc_app;

import com.mysql.cj.jdbc.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
//import java.sql.Timestamp;
//import java.time.LocalDateTime;
//import java.time.LocalTime;

public class ABankCustomerDAO {

    public static Statement init() throws Exception {
        Connection conn = initConn();
        return conn.createStatement();
    }
    
    public static Connection initConn() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/world?useTimezone=true&serverTimezone=UTC&"
                + "user=root&password=mysql");
        /*
        Connection conn = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/bank?useTimezone=true&serverTimezone=UTC&"
                        + "user=root&password=mysql");
        */
        return conn;
    }
    
    /*
    public static int getNextID(){
        int nxtID = 0;
        try{
            Statement stmt = ABankCustomerDAO.init();
            String nxID = "select max(custUINum) from world.abankcustomer;";
            ResultSet rs = stmt.executeQuery(nxID);
            rs.next();
            nxtID = rs.getInt(1) + 1 ;        
        }catch(Exception e){
            System.out.println(" Exception from ABankCustomerDAO :: " + e.getMessage());
            //e.printStackTrace();
        }
        return nxtID;
    }
    */
    public static boolean insertCustomer(ABankCustomer c) throws Exception{
        Statement stmt = ABankCustomerDAO.init();

        String insStmt = "insert into world.abankcustomer (custUINum, custLastName, custGivenName, "
                + "custEmailAddr, custPhone, custStatus, LastUpdate, CreateDate) " + 
                " values(" + 
                "'" + c.getCustUINum() + "'" +
                "," + "'" + c.getCustLastName() + "'" + 
                "," + "'" + c.getCustGivenName() + "'" + 
                "," + "'" + c.getCustEmailAddr() + "'" + 
                "," + "'" + c.getCustPhone() + "'" +
                "," + c.getCustStatus() +
                "," + "'" + c.getLastUpdate() + "'" +
                "," + "'" + c.getCreateDate() + "'" +
                ");";
        
        int result = stmt.executeUpdate(insStmt);
        
        if(result > 0){
            System.out.println(" Insert Success ");
        }else {
            System.out.println(" Insert Fail ");
        }
        
        return true;
    }    
    
    public static boolean delCustomer(String cid) throws Exception{
        Statement stmt = ABankCustomerDAO.init();     
        String delStmt = "delete from world.abankcustomer where custUINum = " + 
                "'" + cid + "'" + ";";
        
        int result = stmt.executeUpdate(delStmt);
        if(result > 0){
            System.out.println(" Delete Success ");
        }else {
            System.out.println(" Delete  Fail ");
        }
        return true;
    }
    
    public static List <ABankCustomer> listCustomer() throws Exception{
        Statement stmt = ABankCustomerDAO.init();
        List <ABankCustomer> custList = new ArrayList<>();
        String qStmt = "Select * from world.abankcustomer;";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            custList.add(new ABankCustomer(rs.getString("custUINum"),
                    rs.getString("custLastName"), rs.getString("custGivenName"),
                    rs.getString("custEmailAddr"), rs.getString("custPhone"), 
                    rs.getBoolean("custStatus"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate") 
            )            
            );
        }
        return custList;
    }  
    
    //--- This method introduces execution of embedded Stored Procedures in a DBMS. 
    public static List <ABankCustomer> listCustomerOrderByDOB() throws Exception{
        Connection conn = ABankCustomerDAO.initConn();
        List <ABankCustomer> custList = new ArrayList<>();
        
        //--- GetABankCustomer() is a Stored Procedure in the mySQL dbms.
        String qStmt = "{CALL GetABankCustomer()}";
        
        CallableStatement cstmt = (CallableStatement)conn.prepareCall(qStmt);
        ResultSet rs = cstmt.executeQuery();
        while(rs.next()){
            ABankCustomer c = new ABankCustomer(rs.getString("custUINum"),                    
                    rs.getString("custLastName"), rs.getString("custGivenName"),
                    rs.getString("custEmailAddr"), rs.getString("custPhone"), 
                    rs.getBoolean("custStatus"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate")
            );
            custList.add(c);
        }
        return custList;
    }
    
    public static ABankCustomer getCustomer(String UINum) throws Exception{
        Statement stmt = ABankCustomerDAO.init();
        ABankCustomer cust = null;
        String qStmt = "Select * from world.abankcustomer where " + 
                "custUINum = " + "'" + UINum + "'" + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            cust = new ABankCustomer(rs.getString("custUINum"),
                    rs.getString("custLastName"), rs.getString("custGivenName"),
                    rs.getString("custEmailAddr"), rs.getString("custPhone"), 
                    rs.getBoolean("custStatus"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate")
            );
        }
        return cust;
    }
    
    public static List <ABankCustomer> getCustomer2(String custPhone) throws Exception{
        Connection conn = ABankCustomerDAO.initConn();
        List <ABankCustomer> custList = new ArrayList<>();
        String qStmt = "Select * from world.abankcustomer where custPhone = ? ";
        
        PreparedStatement pStmt = conn.prepareStatement(qStmt);
        pStmt.setString(1, custPhone);
        ResultSet rs = pStmt.executeQuery();
        while(rs.next()){
            custList.add(new ABankCustomer(rs.getString("custUINum"),
                    rs.getString("custLastName"), rs.getString("custGivenName"),
                    rs.getString("custEmailAddr"), rs.getString("custPhone"), 
                    rs.getBoolean("custStatus"), 
                    rs.getString("LastUpdate"), rs.getString("CreateDate")
            )
            );
        }
        return custList;
    }
    
    public static ABankCustomer findCustomerByUINum(String UINum) throws Exception{
        Statement stmt = ABankCustomerDAO.init();
        ABankCustomer cust = null;
        String qStmt = "Select custUINum, custLastName from world.abankcustomer where " + 
                "custUINum = " + "'" + UINum + "'" + ";";
        
        ResultSet rs = stmt.executeQuery(qStmt);
        while(rs.next()){
            cust = new ABankCustomer(rs.getString("custUINum"),
                    rs.getString("custLastName")
            );
        }
        return cust;
    }
        
    public static boolean updateCustomer(ABankCustomer c) throws Exception{
        Statement stmt = ABankCustomerDAO.init();
        String updStmt = "Update world.abankcustomer set " +
                "custEmailAddr = " + "'" + c.getCustEmailAddr() + "'" +
                ", custPhone = " + "'" + c.getCustPhone() + "'" + 
                " where custUINum = " + "'" + c.getCustUINum() + "'" + ";";
        
        if(stmt.executeUpdate(updStmt) > 0){
           System.out.println(" Update Success ");
        }else {
            System.out.println(" Update Failed ");
        }
        return true;
    }
    
}//- ends public class ABankCustomerDAO
