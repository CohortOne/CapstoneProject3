
package jdbc_app;

public class ABankCustAcctTrans {

    String custAcctTransNum;
    double custAcctTransAmt;
    String custAcctTransType;
    String custAcctTransDesc;
    String CreateDate;
    
    public ABankCustAcctTrans(String custAcctTransNum, double custAcctTransAmt, 
            String custAcctTransType, String custAcctTransDesc, 
            String CreateDate) {
        this.custAcctTransNum = custAcctTransNum;
        this.custAcctTransAmt = custAcctTransAmt;
        this.custAcctTransType = custAcctTransType;
        this.custAcctTransDesc = custAcctTransDesc;
        this.CreateDate = CreateDate;
    }
    
        
/* do NOT remove. This is the printer data layout.
                                                                                                    1         1         1         1
          1         2         3         4         5         6         7         8         9         0         1         2         3
01234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
 AcctNum   TransAmt     TransType  TransDesc             CreateDate                  
 XXXXXXXX  999999.9999  X          XXXXXXXXXXXXXXXXXXXX  XXXXXXXXXXXXXXX  

*/    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i <= 130; i++) { sb.append(" "); }
        sb.insert(1,custAcctTransNum);
        sb.insert(11,custAcctTransAmt);
        sb.insert(24,custAcctTransType);
        sb.insert(35,custAcctTransDesc);
        sb.insert(57,CreateDate);
        return sb.toString().trim();
    }

/*   
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ABankCustAcctTrans{custAcctTransNum=").append(custAcctTransNum);
        sb.append(", custAcctTransAmt=").append(custAcctTransAmt);
        sb.append(", custAcctTransType=").append(custAcctTransType);
        sb.append(", custAcctTransDesc=").append(custAcctTransDesc);
        sb.append(", CreateDate=").append(CreateDate);
        sb.append('}');
        return sb.toString();
    }
*/    
    public String getCustAcctTransNum() {
        return custAcctTransNum;
    }

    public void setCustAcctTransNum(String custAcctTransNum) {
        this.custAcctTransNum = custAcctTransNum;
    }

    public double getCustAcctTransAmt() {
        return custAcctTransAmt;
    }

    public void setCustAcctTransAmt(double custAcctTransAmt) {
        this.custAcctTransAmt = custAcctTransAmt;
    }

    public String getCustAcctTransType() {
        return custAcctTransType;
    }

    public void setCustAcctTransType(String custAcctTransType) {
        this.custAcctTransType = custAcctTransType;
    }

    public String getCustAcctTransDesc() {
        return custAcctTransDesc;
    }

    public void setCustAcctTransDesc(String custAcctTransDesc) {
        this.custAcctTransDesc = custAcctTransDesc;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String CreateDate) {
        this.CreateDate = CreateDate;
    }

    
/*    
    public static boolean vetDigitsInStr(String s) {   
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= '0' && ch <= '9')) {
                    System.out.println("This does not looked like an acceptable initial deposit amount.");
                    return false;
                }
            }
            if(Integer.parseInt(s) > 9) { 
                return true;
            }
        } 
        System.out.println("This does not looked like an acceptable initial deposit amount.");
        return false;       
        
//        if (Pattern.matches("[0-9]",iDeposit) && Integer.parseInt(iDeposit) > 9) {
//            return true;
//        } else {
//            System.out.println("This does not looked like an acceptable initial deposit amount.");
//            return false;
//        }       
        
    }
       
    
    public static boolean vetLettersInStr(String s) { 
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= 'a' && ch <= 'z')) {
                    System.out.println("This does not looked like a good Last/Given Name.");
                    return false;
                }
            }
            return true;
        } 
        System.out.println("This does not looked like a good Last/Given Name.");
        return false;
        
//        if (lName.length() > 1 && Pattern.matches("[a-zA-Z]",lName)) {
//            //this.lastName = lName;
//            return true;
//            //throw new IllegalArgumentException();
//        } else {
//            System.out.println("This does not looked like a good Last Name.");
//            return false;
//        }       
        
    }

    
    static String genAcctNum(String s) {
        //String s is the 1st char [a-zA-Z] in lastName
        //convert s to its representative ascii value, which is also a positive integer;
        byte[] n = s.getBytes();
        int m = (int) (n[0] - 1) % 10;
        //auto-generate a random number between 0.0 and 1.0
        double r = Math.random();
        //calc an integer using values of n[0] and r above (between 0 and n-1), 
        //add 100 to get 3-digit number
        //then prefix the modulus of 10 on n[0]-1
        int i = (int) (r * n[0]) + 100;
        return (s + String.valueOf(m) + String.valueOf(i)); 
    }
    
        
    static void clearScreen() throws IOException {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (InterruptedException ex) {
            Logger.getLogger(ABankAcct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/world?useTimezone=true&serverTimezone=UTC&"
                + "user=root&password=mysql");

            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("select * from emp");
            
            while(rs.next()){
                System.out.println(" ID : " + rs.getInt("empID") + 
                        "   Name : " + rs.getString("empName"));
            }
        } catch (Exception e) {
            System.out.println(" Exception here ....  " + e.getMessage());
        }        
        // TODO code application logic here
        System.out.println("from package jdbc_app, class ABankCustomer, main...");
        
    }//- ends public static void main    
*/
    
    
}//- ends public class ABankCustAcctTrans

//=============================================================================
/* do NOT remove. This is the mySQL table abankcustaccttrans.
CREATE TABLE `ABankCustAcctTrans` (
  `custAcctTransNum` varchar(8) NOT NULL,
  `custAcctTransAmt` decimal(10,4) DEFAULT 0,
  `custAcctTransType` varchar(1) NOT NULL,
  `custAcctTransDesc` varchar(20) DEFAULT NULL,
  `CreateDate` varchar(15) DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci


//Stored Procedure
DELIMITER $$

CREATE procedure GetABankCustAcctTrans()
BEGIN
	select custAcctTransNum, custAcctTransAmt, custAcctTransType,
	custAcctTransDesc, CreateDate   
	from world.abankcustaccttrans
	order by custAcctTransNum, CreateDate;
END$$
DELIMITER ;

//To verify, run:
call GetABankCustAcctTrans();
*/

