
package jdbc_app;

public class ABankCustomer {
    private String custUINum;
    private String custLastName;
    private String custGivenName;
    private String custEmailAddr;
    private String custPhone;
    private Boolean custStatus;
    private String LastUpdate;
    private String CreateDate;
    
    public ABankCustomer(String custUINum, String custLastName, String custGivenName, 
            String custEmailAddr, String custPhone, Boolean custStatus, 
            String LastUpdate, String CreateDate) {
        this.custUINum = custUINum;
        this.custLastName = custLastName;
        this.custGivenName = custGivenName;
        this.custEmailAddr = custEmailAddr;
        this.custPhone = custPhone;
        this.custStatus = custStatus;
        this.LastUpdate = LastUpdate;
        this.CreateDate = CreateDate;
    }
    /*
    public ABankCustomer (String uiN, String lName, String gName, 
            String eAddr, String cPhone, Boolean cStatus,
            String LastUpdateDateTime, String CreateDateTime) {
        this.custUINum = uiN;
        this.custLastName = lName;
        this.custGivenName = gName;
        this.custEmailAddr = eAddr;
        this.custPhone = cPhone;
        this.custStatus = cStatus;
        this.LastUpdateDateTime = LastUpdateDateTime;
        this.CreateDateTime = CreateDateTime;
    }
    */
    public ABankCustomer (String custUINum, String custLastName) {
        this.custUINum = custUINum;
        this.custLastName = custLastName;
    }

    public ABankCustomer(String custUINum, String custLastName, String custGivenName, 
            String custEmailAddr, String custPhone) {
        this.custUINum = custUINum;
        this.custLastName = custLastName;
        this.custGivenName = custGivenName;
        this.custEmailAddr = custEmailAddr;
        this.custPhone = custPhone;
    }
    
/* do NOT remove. This is the printer data layout.
                                                                                                    1         1         1         1
          1         2         3         4         5         6         7         8         9         0         1         2         3
01234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
 UINum       Lastname         GivenName        EmailAddr             custPhone        Status  LastUpdate       CreationDate                  
 XXXXXXXXXX  XXXXXXXXXXXXXXX  XXXXXXXXXXXXXXX  XXXXXXXXXXXXXXXXXXXX  XXXXXXXXXXXXXXX  XXXXX   XXXXXXXXXXXXXXX  XXXXXXXXXXXXXXX  

*/
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i <= 130; i++) { sb.append(" "); }
        sb.insert(1,custUINum);
        sb.insert(13,custLastName);
        sb.insert(30,custGivenName);
        sb.insert(47,custEmailAddr);
        sb.insert(69,custPhone);
        sb.insert(86,custStatus);
        sb.insert(94,LastUpdate);
        sb.insert(111,CreateDate);
        return sb.toString().trim();
    }

    public String getCustUINum() {
        return custUINum;
    }

    public void setCustUINum(String custUINum) {
        this.custUINum = custUINum;
    }

    public String getCustLastName() {
        return custLastName;
    }

    public void setCustLastName(String custLastName) {
        this.custLastName = custLastName;
    }

    public String getCustGivenName() {
        return custGivenName;
    }

    public void setCustGivenName(String custGivenName) {
        this.custGivenName = custGivenName;
    }

    public String getCustEmailAddr() {
        return custEmailAddr;
    }

    public void setCustEmailAddr(String custEmailAddr) {
        this.custEmailAddr = custEmailAddr;
    }

    public String getCustPhone() {
        return custPhone;
    }

    public void setCustPhone(String custPhone) {
        this.custPhone = custPhone;
    }

    public Boolean getCustStatus() {
        return custStatus;
    }

    public void setCustStatus(Boolean custStatus) {
        this.custStatus = custStatus;
    }

    public String getLastUpdate() {
        return LastUpdate;
    }

    public void setLastUpdate(String LastUpdate) {
        this.LastUpdate = LastUpdate;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String CreateDate) {
        this.CreateDate = CreateDate;
    }

    
/*    
    public static boolean vetDigitsInStr(String s) {   
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= '0' && ch <= '9')) {
                    System.out.println("This does not looked like an acceptable initial deposit amount.");
                    return false;
                }
            }
            if(Integer.parseInt(s) > 9) { 
                return true;
            }
        } 
        System.out.println("This does not looked like an acceptable initial deposit amount.");
        return false;       
        
//        if (Pattern.matches("[0-9]",iDeposit) && Integer.parseInt(iDeposit) > 9) {
//            return true;
//        } else {
//            System.out.println("This does not looked like an acceptable initial deposit amount.");
//            return false;
//        }       
        
    }
       
    
    public static boolean vetLettersInStr(String s) { 
        if (s.length() > 1) {
            s = s.toLowerCase();
            char[] charArray = s.toCharArray();
            for (int i = 0; i < charArray.length; i++) {
                char ch = charArray[i];
                if (!(ch >= 'a' && ch <= 'z')) {
                    System.out.println("This does not looked like a good Last/Given Name.");
                    return false;
                }
            }
            return true;
        } 
        System.out.println("This does not looked like a good Last/Given Name.");
        return false;
        
//        if (lName.length() > 1 && Pattern.matches("[a-zA-Z]",lName)) {
//            //this.lastName = lName;
//            return true;
//            //throw new IllegalArgumentException();
//        } else {
//            System.out.println("This does not looked like a good Last Name.");
//            return false;
//        }       
        
    }

    
    static String genAcctNum(String s) {
        //String s is the 1st char [a-zA-Z] in lastName
        //convert s to its representative ascii value, which is also a positive integer;
        byte[] n = s.getBytes();
        int m = (int) (n[0] - 1) % 10;
        //auto-generate a random number between 0.0 and 1.0
        double r = Math.random();
        //calc an integer using values of n[0] and r above (between 0 and n-1), 
        //add 100 to get 3-digit number
        //then prefix the modulus of 10 on n[0]-1
        int i = (int) (r * n[0]) + 100;
        return (s + String.valueOf(m) + String.valueOf(i)); 
    }
    
        
    static void clearScreen() throws IOException {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (InterruptedException ex) {
            Logger.getLogger(ABankAcct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/world?useTimezone=true&serverTimezone=UTC&"
                + "user=root&password=mysql");

            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("select * from emp");
            
            while(rs.next()){
                System.out.println(" ID : " + rs.getInt("empID") + 
                        "   Name : " + rs.getString("empName"));
            }
        } catch (Exception e) {
            System.out.println(" Exception here ....  " + e.getMessage());
        }        
        // TODO code application logic here
        System.out.println("from package jdbc_app, class ABankCustomer, main...");
        
    }//- ends public static void main    
*/
    
}//- ends public class ABankCustomer

//=============================================================================
/* do NOT remove. This is the mySQL table abankcustomer.
CREATE TABLE `ABankCustomer` (
  `custUINum` varchar(10) NOT NULL,
  `custLastName` varchar(15) NOT NULL,
  `custGivenName` varchar(15) NOT NULL,
  `custEmailAddr` varchar(20) DEFAULT NULL,
  `custPhone` varchar(15) NOT NULL,
  `custStatus` BIT(1) DEFAULT 0,
  `LastUpdate` varchar(15) DEFAULT NULL,
  `CreateDate` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`custUINum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
*/