// declare global variable to store keystrokes and mouse clicks on the web keypad
x = "";

//========================= start of new code block ==========================

function printinputlog(num) {
	document.getElementById("garbage").innerHTML = num;
	var tArea = document.getElementById("garbage");
	tArea.scrollTop = tArea.scrollHeight;
}

function printHistLog(num) {
	document.getElementById("histLog").innerHTML = num;
	//var tArea = document.getElementById("histLog");
	//tArea.scrollTop = tArea.scrollHeight;
}

function printResult(num) {
	document.getElementById("result").value = num;
}

function printMemory(num) {
	document.getElementById("memStore").value = num;
}

// invoked by mouse click on the web keypad 
function f_eval(opSign) {
	x = x + opSign + "\n";
	printinputlog(x);
	var lastVal = document.getElementById("histLog").innerHTML;
	printHistLog(lastVal + opSign + "\n");

	if (lastVal.indexOf("%") > 0) {
		var result = parseFloat(eval(lastVal.replace("%", "/") + ";")) * 100.0;
	}
	else if (opSign === "I") {
		if (lastVal !== "0") {		//deny divide by 0
			var result = 1.0 / parseFloat(eval(lastVal.replace("I", "") + ";"));
		}
		else { result = ""; lastVal = ""; }
	}
	else if (opSign === "R") {
		var result = Math.sqrt(parseFloat(eval(lastVal.replace("R", "") + ";")));
	}
	else if (opSign === "F") {
		var result = parseFloat(eval(lastVal.replace("F", "") + ";")) ** 2.0;
	}
	else {
		var result = parseFloat(eval(lastVal + ";")); //The javascript eval() function that gives the computed result
	}
	// Store the final calc result to session Storage.
	window.sessionStorage.setItem("finalResult", result); // Store to session storage
	var sstore = window.sessionStorage.getItem("finalResult"); // retrieve from session storage for assurance
	printHistLog(sstore + "\n");
	printResult(sstore);
}

// invoked by mouse click on the web keypad 
function f_concat(num) {
	x = x + num;
	printinputlog(x);
	var lastVal = document.getElementById("histLog").innerHTML + num;
	numOK = AssureNumbers(lastVal);
	//alert("Parse thro AssureNumbers. The check returned " + numOK);
	if (numOK) {
		printHistLog(lastVal);
		printResult(lastVal);
	}
}

// invoked by mouse click on the web keypad 
function f_opSign(opSign) {
	x = x + opSign;
	printinputlog(x);
	var lastVal = document.getElementById("histLog").innerHTML + opSign;
	signOK = EnsureOnlyOneOpSign(lastVal);
	//alert("Parse thro EnsureOnlyOneOpSign. The check returned " + signOK);
	if (signOK) {
		printHistLog(lastVal);
		printResult(lastVal);
	}
}

// Verify operand1 and operand2 are valid (decimal) numbers.
function AssureNumbers(lastVal) {
	var operand1 = "NaN";
	var operand2 = "";
	var i = 0;
	var len = lastVal.length;

	// Extract operand1 and operand2 using the operator as the delimiter.
	var tempVal = lastVal;
	if (lastVal[0] == "-") { tempVal = lastVal.substr(1, len - 1); } // allow negative number in operand1
	if (tempVal.indexOf("*") >= 0 && tempVal.lastIndexOf("*") == tempVal.indexOf("*")) {
		//alert("AssureNumbers: inside '*' check");
		i = lastVal.lastIndexOf("*");
		operand1 = lastVal.substr(0, i);
		if (i < len) { operand2 = lastVal.substr((i + 1), len - 1); }
	}
	else if (tempVal.indexOf("+") >= 0 && tempVal.lastIndexOf("+") == tempVal.indexOf("+")) {
		//alert("AssureNumbers: inside '+' check");
		i = lastVal.lastIndexOf("+");
		operand1 = lastVal.substr(0, i);
		if (i < len) { operand2 = lastVal.substr((i + 1), len - 1); }
	}
	else if (tempVal.indexOf("-") >= 0 && tempVal.lastIndexOf("-") == tempVal.indexOf("-")) {
		//alert("AssureNumbers: inside '-' check");
		i = lastVal.lastIndexOf("-");
		operand1 = lastVal.substr(0, i);
		if (i < len) { operand2 = lastVal.substr((i + 1), len - 1); }
	}
	else if (tempVal.indexOf("/") >= 0 && tempVal.lastIndexOf("/") == tempVal.indexOf("/")) {
		//alert("AssureNumbers: inside '/' check");
		i = lastVal.lastIndexOf("/");
		operand1 = lastVal.substr(0, i);
		if (i < len) { operand2 = lastVal.substr((i + 1), len - 1); }
		if (operand2 == "0") { return false; }	//deny divide by 0
	}
	else if (tempVal.indexOf("%") >= 0 && tempVal.lastIndexOf("%") == tempVal.indexOf("%")) {
		//alert("AssureNumbers: inside '%' check");
		i = lastVal.lastIndexOf("%");
		operand1 = lastVal.substr(0, i);
		if (i < len) { operand2 = lastVal.substr((i + 1), len - 1); }
		if (operand2 == "0") { return false; }	//deny divide by 0
	}
	else {
		//alert("AssureNumbers: inside default check");
		operand1 = lastVal;
	}

	// Ensure operand1 and operand2 do not have more than 1 decimal point.
	// operand2 is not entered yet, check operand1 only
	if (operand2 == "") {
		//alert("AssureNumbers: inside operand1 check");
		if (operand1.lastIndexOf(".") !== operand1.indexOf(".")) {
			return false;	// process invalid operand1
		}
		else return true;  //process valid operand1
	}
	else { //check operand2. Assume Operand1 is already checked and Ok'ed
		//alert("AssureNumbers: inside operand2 check");
		if (operand2.lastIndexOf(".") !== operand2.indexOf(".")) {
			return false;	// process invalid operand2
		}
		else return true;  //process valid operand2
    }
}

// Count the number of operator(s) in the input string.
function EnsureOnlyOneOpSign(lastVal) {
	var validString = '+/*%';
	var len = lastVal.length;
	var count = 0;
	var n = 0;
	for (var i = 0; i < len; i++) {
		n = validString.indexOf(lastVal[i]);
		if (n >= 0) { count = count + 1; }
	}
	if (count > 1) { return false; }	// There are 2 or more operators of '+/*%' which is not allowed
	// count is either 0 or 1
	if (count === 0) { 
		if (lastVal.lastIndexOf("-") == lastVal.indexOf("-")) return true;
	}
	else {
		// count is 1: There is 1 operator of type '+/*%'. Check for '-" as the subtraction sign.
		if (len > 1) {
			if (lastVal[len - 1] === "-") return false;
			else return true; // Allow 1 subtraction symbol '-'
		}
		if (lastVal[len - 1] === "-") return true; // Allow negative number in operand1
		else return false;
	}
}

function f_clear(num) {
	x = x + num + "\n";
	printinputlog(x);
	printHistLog("");
	printResult("");
	window.sessionStorage.clear();
}

function f_backspace(num) {
	x = x + num + "\n";
	printinputlog(x);
	var lastVal = document.getElementById("histLog").innerHTML;
	var len = lastVal.length;
	if (len>0) {//if output (still) has a value
		lastVal = lastVal.substr(0, len - 1);//remove the last input char since backspace is pressed
		printHistLog(lastVal);
		printResult(lastVal);
	}
}

function f_clearGarbage() {
	x = "";
	printinputlog(x);
}

function f_memRecall(num) {
	if (typeof (Storage) !== "undefined") {
		var sstore = parseFloat(window.localStorage.getItem("memVal"));

		x = x + num + sstore + "\n";
		printinputlog(x);
		printHistLog(sstore);
		printResult(sstore);
	}
}

function f_memAdd(num) {
	if (typeof (Storage) !== "undefined") {
		var sstore = "";
		sstore = parseFloat(window.localStorage.getItem("memVal"));
		if (isNaN(sstore)) { sstore = ""; }
		var currVal = parseFloat(document.getElementById("histLog").innerHTML); 
		var result = eval((sstore + currVal + ";"));
		window.localStorage.setItem("memVal", result); // Store to local storage
		var sstore = window.localStorage.getItem("memVal"); // retrieve from local storage for assurance
		
		x = x + num + result + "\n";
		printinputlog(x);
		printHistLog(sstore);
		printResult(sstore);
		printMemory(sstore);
	}
}

function f_memSubtract(num) {
	if (typeof (Storage) !== "undefined") {
		var sstore = "";
		sstore = parseFloat(window.localStorage.getItem("memVal"));
		if (isNaN(sstore)) { sstore = ""; }
		var currVal = parseFloat(document.getElementById("histLog").innerHTML);
		var result = eval((sstore - currVal + ";"));
		window.localStorage.setItem("memVal", result); // Store to local storage
		var sstore = window.localStorage.getItem("memVal"); // retrieve from local storage for assurance

		x = x + num + result + "\n";
		printinputlog(x);
		printHistLog(sstore);
		printResult(sstore);
		printMemory(sstore);
	}
}

function f_memClear(num) {
	if (typeof (Storage) !== "undefined") {
		printMemory("");
		window.localStorage.clear();
		//window.localStorage.removeItem("memVal");

		x = x + num + "\n";
		printinputlog(x);
	}
}


//------------ Validate Keyboard inputs ---------------------------
// Invoked by keyboard inputs
function f_KeyPress(event) {
	var y = event.key;
	//x = x + y;
	//printinputlog(x);
	
	var validString = "0123456789.";
	var n = validString.indexOf(y);
	if (n >= 0) { f_concat(y); }
	else {
		validString = "*-/+%";
		n = validString.indexOf(y);
		if (n >= 0) { f_opSign(y); }
		else if (y === "=") { f_eval(y); }
		//else if (y === "i") { f_eval(y.toUpperCase()); } // inverse of x
		//else if (y === "f") { f_eval(y.toUpperCase()); } // square of x
		//else if (y === "r") { f_eval(y.toUpperCase()); } // square root of x
		// Backspace (remove the most recent keyboard input character )
		else if (y === "Backspace") { f_backspace(y); }
		// Delete (act like Clear key)
		else if (y === "Delete") { f_clear(y); }
		else {
			// print to garbage store so we can see the equivalent keypress values.
			x = x + y + "\n";
			printinputlog(x);
			// ControlCapsLock
			// Activate a different HTML page with <Control><CapsLock> keypresses.
			var kcontrol = "";
			if (y === "Control") { kcontrol = y; }
			else if (y === "CapsLock" && kcontrol === "Control") { window.location.href = "https://localhost:44390/SnakeGame.html"; }
			//else if (y !== "Shift") {
			//	alert("Keypress value is " + y + " which is not accepted. Clear the web cache and refresh the page to start again.");
			//}
		}
	}
}



//========================== end of new code block =======================
